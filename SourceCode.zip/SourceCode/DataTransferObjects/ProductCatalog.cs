﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 11-Mar-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
#endregion

namespace CLB.DTO
{   
    [Serializable]
    public class ProductCatalog
    {
        public long ProductID { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// Max length 200
        /// </summary>
        public string AliasNames { get; set; }
        public SubCategory SubCategory { get; set; }
        public Category Category { get; set; }
        /// <summary>
        /// Product Main Category. Property is added for UI flexibility
        /// </summary>
        public MainCategory MainCategory { get; set; }
        public Country Country { get; set; }        
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
