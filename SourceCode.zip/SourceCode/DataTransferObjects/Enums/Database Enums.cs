﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CLB.Enums.Database
{
    /// <summary>
    /// Determines the database custom messages
    /// </summary>
    public enum DbMessage
    {
        Unauthorized,
        CredentialsIncorrect,
        Duplicate,
        InActive,
        Locked,
        NotFound,
        Configurations,
        OldPasswordIncorrect,
        PasswordChanged,
        Success,
        Created,
        Sent,
        Delete,
        Failed,
        ForeignKeyRelationship,
        AlreadyLoggedIn,
        CustomMessage
    }

    /// <summary>
    /// Determines Database stored procedures
    /// </summary>
    public class StoredProcedures
    {
        public const string SpSendEnquirytoVendors = "uspSendEnquirytoVendors";
        public const string SpAuthenticateUser = "uspSTDAuthenticateUser";
        public const string SpChangePassword = "uspSTDChangePassword";
        public const string SpDeleteData = "uspSTDDeleteData";
        public const string SpGetData = "uspSTDGetData";
        public const string SpGetDataFromMultipleTables = "uspSTDGetDataFromMultipleTables";
        public const string SpInsertData = "uspSTDInsertData";
        public const string SpInsertMultipleRows = "uspSTDInsertMultipleRows";
        public const string SpSaveErrorLog = "uspSTDLogError";
        public const string SpUpdateData = "uspSTDUpdateData";
        public const string SpUpdateField = "uspSTDUpdateField";
        public const string SpUpdateMultipleRows = "uspSTDUpdateMultipleRows";
        public const string SpUsers = "uspSTDUsers";
        public const string SpSearchProducts = "uspSearchProducts";
        public const string spGetMenuData = "spGetMenuData";
    }

    /// <summary>
    /// Determines Database table names
    /// </summary>
    public enum Tables
    {
        BannerAd,
        BusinessBranchDetails,
        BusinessDetails,
        Category,
        City,
        Country,
        DbErrorLog,
        DynamicPages,
        EmailLog,
        EmailQueries,
        Enquiry,
        EnquiryLog,
        EnquiryStatus,
        ErrorLog,
        LoginLog,
        MainCategory,
        PlanFeature,
        PriceManagement,
        PricePlan,
        ProductCatalog,
        Quotation,
        Roles,
        Screens,
        SMSLog,
        SubCategory,
        Subscription,
        UnitofMeasurement,
        UserDetails,
        Users,
        VendorInventory
    }

    /// <summary>
    /// Determines the tables which involves credit/debit user balances
    /// Used in UserBalanceLog table
    /// </summary>
    public enum TransactionTables
    {
        BinaryPayout = 1,
        RankPayout = 2,
        ReorderPayout = 3,
        Bookings = 4,
        Cancellations = 5,
        WalletRecharge = 6
    }

    /// <summary>
    /// Determines the Type of Transaction being performed
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// Indicates as insertion
        /// </summary>
        Insert,
        /// <summary>
        /// Indicates as updating
        /// </summary>
        Update,
        /// <summary>
        /// Indicates as deletion
        /// </summary>
        Delete
    }
}
