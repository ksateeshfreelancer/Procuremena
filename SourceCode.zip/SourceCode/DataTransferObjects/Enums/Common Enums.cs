﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CLB.Enums
{
    /** ADD IN ALPHABETICAL ORDER **/


    /// <summary>
    /// Indicates different business types
    /// </summary>
    public enum BusinessType
    {
        NotSet = 0,
        Manufacturer = 1,
        Wholesaler = 2,
        Exporter = 3,
        Retailer = 4
    }

    /// <summary>
    /// Indicates different banner positions
    /// </summary>
    public enum BannerPosition
    {
        NotSet = 0,
        TopLeft = 1,
        BottomLeft = 2,
        TopRight = 3,
        BottomRight = 4
    }

    /// <summary>
    /// Determines the additional client information
    /// </summary>
    public enum ClientInfo
    {
        GoogleMapType = ControlType.HyperLink,
        FacebookType = ControlType.HyperLink,
        FacebookAppIdType = ControlType.HyperLink,
        TwitterType = ControlType.HyperLink,
        GooglePlusType = ControlType.HyperLink,
        MetaTagsType = ControlType.TextArea,
        ShowBrandImageType = ControlType.CheckBox,
        PSALoginUrlType = ControlType.HyperLink,
        CustomTemplateUrlType = ControlType.HyperLink,
        GoogleMap = 5,
        Facebook = 6,
        Twitter = 7,
        GooglePlus = 8,
        MetaTags = 9,
        ShowBrandImage = 10,
        PSALoginUrl = 11,
        CustomTemplateUrl = 12,
        FacebookAppId = 13
    }

    /// <summary>
    /// Indicates  control types for dynamic controls rendered at runtime
    /// </summary>
    public enum ControlType
    {
        TextBox = 1,
        TextArea = 2,
        CheckBox = 3,
        HyperLink = 4
    }

    /// <summary>
    /// Email Templates used to send to mail
    /// </summary>
    public enum EmailTemplates
    {
        UserRegistration = 1,
        ForgotPassword = 2,
        StatusUpdate = 3,
        DepositUpdate = 4,
        /// <summary>
        /// "pax"-passenger name(s),
        /// "domain"-Client Domain Name,
        /// "route"-route details,
        /// "doj"-date of journey,
        /// "travel"-travel name,
        /// "ticketnumber"-Ticket Numbar to be display,
        /// "bustype"-bus type,
        /// "refundamount"-refund amount after cancellation,
        /// "domain"-Client Domain Name,
        /// "domainurl"-Client Domain Url,
        /// "supportemail"-support email id(eg:-info@domainname.com)
        /// </summary>
        CancelTicket = 5,

        DepositRequest = 6,
        /// <summary>
        /// bus ticket to print
        /// "ticketno" - PNR TicketID
        /// "pnrno" - PNR Number
        /// "refno" - Referenceno
        /// "travelname" - travel operator name
        /// "reptime" - reporting time
        /// "deptime" - departure time
        /// "seatnos"-seat numbers
        /// "bplocation" - boarding point location
        /// "bplandmark"-boarding point landmark
        /// "boardingaddress"-boarding point address
        /// "passengerdetails" -Passenger Details
        /// "fare"-ticket fare
        /// "clientname" - client domain name
        /// "clientemail"  - client email
        /// "sourcename"  - source name
        /// "destinationname" - destination name
        /// </summary>
        PrintTicket = 7,
        ServiceUpdate = 8,
        AddAmount = 9,
        RevokeAmount = 10,
        ChangePassword = 11,
        ZeroBalanceAlert = 12,
        LowBalanceAlert = 13,
        SiteAdminRegistration = 14,
        Invoice = 15,
        FlightTicket = 16,
        HotelRoomBooking = 17,
        DepositReject = 18,
        AgentDistWlRegRequest = 19,
        ChangeTxnPassword = 20,
        CabTicket = 21
    }

    /// <summary>
    /// Indicates frequency of a service
    /// </summary>
    public enum Frequency
    {
        NotSet = 0,
        Daily = 1,
        Weekly = 2,
        Monthly = 3,
        Quarterly = 4,
        Halfyearly = 5,
        Yearly = 6,
        Regular = 7,
        Onetime = 8,
        Others = 9,
    }

    /// <summary>
    /// Determines user gender
    /// </summary>
    public enum Gender
    {
        Male = 1,
        Female = 0
    }

    /// <summary>
    /// Determines categories under which menu items fall
    /// </summary>
    public enum MenuCategory
    {
        Others = 0,
        /// <summary>
        /// Indicates report screens, logs, meetings, notifications, rankings folders screens
        /// </summary>
        Administration = 1,
        /// <summary>
        /// Indicates users, roles folders screens
        /// </summary>
        Accounts = 2,        
        /// <summary>
        /// Indicates profile
        /// </summary>
        Profile = 3,
        /// <summary>
        /// Indicates email queries
        /// </summary>
        EmailQueries = 4,
        /// <summary>
        /// Indicates dynamic pages
        /// </summary>
        DynamicPages = 5,
        /// <summary>
        /// Indicates Reports
        /// </summary>
        Reports = 6
    }
    /// <summary>
    /// Determines message type
    /// </summary>
    public enum MessageType
    {
        Success,
        Error,
        Info,
        Warning
    }

    /// <summary>
    /// Indicates the category - requried when users send emails to committe
    /// </summary>
    public enum QueryCategory
    {
        NotSet = 0,
        Support = 1,
        Account = 2,
        Finance = 3,
        Subscription = 4,
        Others = 5
    }

    /// <summary>
    /// SMS Formats used to send sms
    /// SMSTemplates CLASS IS ALREDY PRESENT. DO NOT CHANGE IT TO SMSTEMPLATES
    /// </summary>
    public enum SMSFormats
    {
        AddBalance = 1,
        RevokBalance = 2,
        DepositRequest = 3,
        AcceptOfDepositRequest = 4,
        RejectOfDepositRequest = 5
    }

    /// <summary>
    /// Static Pages used to Display content for Client's whitelabel pages
    /// </summary>
    public enum StaticPages
    {
        /// <summary>
        /// About Client
        /// </summary>
        Aboutus = 1,
        /*/// <summary>
        /// Contact information of Client
        /// </summary>
        Contactus = 2*/
    }

    /// <summary>
    /// Determines the Status of User
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Indicates as Active state
        /// </summary>
        Active = 1,
        /// <summary>
        /// Indicates as InActive state
        /// </summary>
        InActive = 0,
        /// <summary>
        /// Indicates as Deleted state
        /// </summary>
        Deleted = 2,
        /// <summary>
        /// Indicates as Locked state
        /// </summary>
        Locked = 3,
        /// <summary>
        /// Indicates as Failed state
        /// </summary>
        Failed = 4,
        /// <summary>
        /// Indicates as awaiting for admin approval
        /// </summary>
        AdminApproval = 5,
        /// <summary>
        /// Indicates an unidentified value
        /// </summary>
        NotSet = -1
    }

    // <summary>
    /// Determines the Role of User
    /// </summary>
    public enum UserRole
    {
        NotSet = 0,
        /// <summary>
        /// Indicates as administrator
        /// </summary>
        Administrator = 1,
        /// <summary>
        /// Indicates as seller
        /// </summary>
        Vendor = 2,
        /// <summary>
        /// Indicates as user
        /// </summary>
        Customer = 3,
        /// <summary>
        /// Indicates as dynamic user
        /// </summary>
        DynamicUser,
    }
}