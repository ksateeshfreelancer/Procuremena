﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Net.Mail;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.DTO;
using System.Xml.Linq;

#endregion


namespace CLB.Util
{
    /// <summary>
    /// Constants Class contains the general methods used in all pages
    /// </summary>
    public class DataConstants
    {
        private static string appdatafolder =
            HttpContext.Current == null ?
            Path.Combine(System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath, "App_Data") :
            Path.Combine(HttpContext.Current.Request.PhysicalApplicationPath, "App_Data");
        
        /*public static ListItem[] LoadSiteFeatures(Control controlId = null, bool includeDefaultAndAdminScreens = false)
        {
            var items = new[]
                {   
                    new ListItem("DefaultScreens", "0"),
                    new ListItem("AdminScreens", "100"),
                    new ListItem("Accounting", "1"),
                    new ListItem("Online Payments", "2"),
                    new ListItem("Ballot Voting", "3"),
                    new ListItem("Circulars", "4"),
                    new ListItem("Discussion Forum", "5"),
                    new ListItem("Email Messaging", "6"),
                    new ListItem("In-Out Visitor Track", "7"),
                    new ListItem("Events", "9"),
                    new ListItem("Assets", "8"),
                    new ListItem("Maintenance Requests", "10"),
                    new ListItem("Meetings", "11"),
                    new ListItem("Parking", "12"),
                    new ListItem("Polling", "13"),
                    new ListItem("Staff Management", "14"),
                    new ListItem("Vendors", "15"),
                    new ListItem("Admin Files", "16"),
                    new ListItem("Dynamic pages", "17"),
                    new ListItem("Landing Page", "18"),
                    new ListItem("Attendance Track", "19"),
                    new ListItem("Admin Forum", "20"),
                    new ListItem("Advertisements", "21"),
                    new ListItem("Photo Gallery", "22"),
                    new ListItem("Manage Users", "23"),
                    new ListItem("Manage Facilities", "25"),
                    //new ListItem("", "25"),
                    //new ListItem("", "26"),
                };

            if (controlId != null)
            {
                //do not bind default screens listitem to control..
                Utilities.BindControl(items.Where(x => int.Parse(x.Value) > 0 && int.Parse(x.Value) != 100).ToList(), "Text", "Value", controlId);
            }
            if (includeDefaultAndAdminScreens)
                return items;
            else
                return items.Where(x => int.Parse(x.Value) > 0 && int.Parse(x.Value) != 100).ToArray();
        }*/

        public static ListItem[] LoadAdCategories(DropDownList controlId = null)
        {
            var items = new[]
                {
                    new ListItem("Mobiles & Tables", "1"),
                    new ListItem("Electronics and Computers", "2"),
                    new ListItem("Vehicles", "3"),
                    new ListItem("Home and Furniture", "4"),
                    new ListItem("Pets", "5"),
                    new ListItem("Books, CDs & Magazines", "6"),
                    new ListItem("Hobbies, Coints, Handicrafts, Coins & Collectibles, Musical Instruments", "7"),
                    new ListItem("Clothing and Accessories", "8"),
                    new ListItem("Footwear, Watches, Bags & Luggage", "9"),
                    new ListItem("Jewellery", "10"),
                    new ListItem("Baby Products & Furniture, Toys & Games, Kids Clothing", "11"),
                    new ListItem("Sports & Health, Gym & Fitness", "12"),
                    new ListItem("Health & Beauty", "13"),
                    new ListItem("Education & Classes", "14"),
                    new ListItem("Maids & Domestic Help", "15"),
                    new ListItem("Education & Classes", "16"),
                    new ListItem("Home Improvements & Repairs", "17"),
                    new ListItem("Packers & Movers", "18"),
                    new ListItem("Drivers - Taxi Services", "19"),
                    new ListItem("Car Wash & Repair", "20"),
                    new ListItem("Job Offers", "21"),
                    new ListItem("Houses - Apartments for Sale/Rent", "22"),
                    new ListItem("Land - Plots for Sale", "23"),
                    new ListItem("Office - Commercial Space", "24"),
                    new ListItem("Job Offers", "25"),
                    new ListItem("Other Services", "26"),
                };

            if (controlId != null)
            {
                controlId.Items.AddRange(items);

                controlId.Items.Insert(0, new ListItem("Please Select", ""));
                controlId.SelectedIndex = 0;
            }
            return items;
        }

        /// <summary>
        /// Method to load list of banks
        /// </summary>
        /// <param name="controlId"></param>
        /// <returns></returns>
        public static ListItem[] LoadBanks(DropDownList controlId = null)
        {
            var items = new[]
                {
                    new ListItem("State Bank of India", "1"),
                    new ListItem("ICICI Bank", "2"),
                    new ListItem("Punjab National Bank", "3"),
                    new ListItem("Bank of Baroda", "4"),
                    new ListItem("HDFC Bank", "5"),
                    new ListItem("Canara Bank", "6"),
                    new ListItem("Axis Bank", "7"),
                    new ListItem("Bank of India", "8"),
                    new ListItem("IDBI Bank", "9"),
                    new ListItem("Union Bank of India", "10"),
                };

            if (controlId != null)
            {
                controlId.Items.AddRange(items);

                controlId.Items.Insert(0, new ListItem("Please Select", ""));
                controlId.SelectedIndex = 0;
            }
            return items;
        }
        public static ListItem[] LoadSortList(DropDownList controlId = null)
        {
            var items = new[]
                {
                    new ListItem("Name : Asc", "PRODUCTNAME_0"),
                    new ListItem("Name : Desc", "PRODUCTNAME_1"),
                    new ListItem("Price : Asc", "MRP_0"),
                    new ListItem("Price : Max", "MRP_1"),
                    new ListItem("Popularity", "RATINGCOUNT"),
                    new ListItem("Rating", "RATING")
                };

            if (controlId != null)
            {
                controlId.Items.AddRange(items);
                ((DropDownList)controlId).Items.Insert(0, new ListItem("Please Select", ""));
                ((DropDownList)controlId).SelectedIndex = 0;
            }
            return items;
        }        
    }
}
