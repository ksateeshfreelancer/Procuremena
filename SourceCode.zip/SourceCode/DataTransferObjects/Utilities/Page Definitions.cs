﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System.Collections.Generic;
using System.Configuration;

#endregion

namespace CLB.Util
{
    public class RedirectPage
    {
        public KeyValuePair<string, string> Home = new KeyValuePair<string, string>("Index", "~/Default.aspx");
        public KeyValuePair<string, string> ViewMoreProducts = new KeyValuePair<string, string>("AllProductCategories", "~/AllProductCategories.aspx");

        //Account
        public KeyValuePair<string, string> ForgotPassword = new KeyValuePair<string, string>("ForgotPassword", "~/Account/ForgotPassword.aspx");
        public KeyValuePair<string, string> Login = new KeyValuePair<string, string>("Login", "~/Account/Login.aspx");
        public KeyValuePair<string, string> Logout = new KeyValuePair<string, string>("Logout", "~/Account/Logout.aspx");
        public KeyValuePair<string, string> ResetPassword = new KeyValuePair<string, string>("ResetPassword", "~/Account/ResetPassword.aspx");
        public KeyValuePair<string, string> SessionExpired = new KeyValuePair<string, string>("SessionExpired", "~/Account/SessionExpired.aspx");
        public KeyValuePair<string, string> Unauthorized = new KeyValuePair<string, string>("Unauthorized", "~/Account/Unauthorized.aspx");

        //Admin
        public KeyValuePair<string, string> ManageProduct = new KeyValuePair<string, string>("ManageProduct", "~/Admin/ManageProduct.aspx");
        public KeyValuePair<string, string> MapPlanFeatures = new KeyValuePair<string, string>("MapPlanFeatures", "~/Admin/MapPlanFeatures.aspx");
        public KeyValuePair<string, string> ViewCategories = new KeyValuePair<string, string>("ViewCategories", "~/Admin/ViewCategories.aspx");
        public KeyValuePair<string, string> ViewCities = new KeyValuePair<string, string>("ViewCities", "~/Admin/ViewCities.aspx");
        public KeyValuePair<string, string> ViewCountries = new KeyValuePair<string, string>("ViewCountries", "~/Admin/ViewCountries.aspx");
        public KeyValuePair<string, string> ViewEnquiries = new KeyValuePair<string, string>("ViewEnquiries", "~/Admin/ViewEnquiries.aspx");
        public KeyValuePair<string, string> ViewEnquiryLog = new KeyValuePair<string, string>("ViewEnquiryDetails", "~/Admin/ViewEnquiryLog.aspx");
        public KeyValuePair<string, string> ViewPlanFeatures = new KeyValuePair<string, string>("ViewPlanFeatures", "~/Admin/ViewPlanFeatures.aspx");
        public KeyValuePair<string, string> ViewPricePlans = new KeyValuePair<string, string>("ViewPricePlans", "~/Admin/ViewPricePlans.aspx");
        public KeyValuePair<string, string> ViewProducts = new KeyValuePair<string, string>("ViewProducts", "~/Admin/ViewProducts.aspx");
        public KeyValuePair<string, string> ViewSubCategories = new KeyValuePair<string, string>("ViewSubCategories", "~/Admin/ViewSubCategories.aspx");
        public KeyValuePair<string, string> ViewUnitofMeasurements = new KeyValuePair<string, string>("ViewUnitofMeasurements", "~/Admin/ViewUnitofMeasurements.aspx");

        //Banner Ads
        public KeyValuePair<string, string> AdRouter = new KeyValuePair<string, string>("AdRouter", "~/BannerAds/BannerAdRedirect.aspx");        
        public KeyValuePair<string, string> ManageBannerAd = new KeyValuePair<string, string>("ManageBannerAd", "~/BannerAds/ManageBannerAd.aspx");
        public KeyValuePair<string, string> ViewBannerAds = new KeyValuePair<string, string>("ViewBannerAds", "~/BannerAds/ViewBannerAds.aspx");

        //Dashboards
        public KeyValuePair<string, string> AdminDashboard = new KeyValuePair<string, string>("ADashboard","~/Dashboards/AdminDashboard.aspx");
        public KeyValuePair<string, string> VendorDashboard = new KeyValuePair<string, string>("VDashboard", "~/Dashboards/VendorDashboard.aspx");
        public KeyValuePair<string, string> CustomerDashboard = new KeyValuePair<string, string>("CDashboard", "~/Dashboards/CustomerDashboard.aspx");

        //Dynamic Pages
        public KeyValuePair<string, string> ViewDynamicPages = new KeyValuePair<string, string>("ViewDynamicPages", "~/DynamicPages/ViewDynamicPages.aspx");
        public KeyValuePair<string, string> ManageLandingPage = new KeyValuePair<string, string>("ManageLandingPage", "~/DynamicPages/ManageLandingPage.aspx");

        //Email Queries
        public KeyValuePair<string, string> EmailContent = new KeyValuePair<string, string>("EmailContent", "~/EmailQueries/EmailContent.aspx");
        public KeyValuePair<string, string> ViewEmailQueries = new KeyValuePair<string, string>("ViewEmailQueries", "~/EmailQueries/ViewEmailQueries.aspx");

        //Enquiry
        public KeyValuePair<string, string> SearchResults = new KeyValuePair<string, string>("Search", "~/Enquiry/SearchResults.aspx");
        public KeyValuePair<string, string> SendEnquiry = new KeyValuePair<string, string>("SendEnquiry", "~/Enquiry/SendGeneralEnquiry.aspx");
        public KeyValuePair<string, string> SendMultiItemEnquiry = new KeyValuePair<string, string>("SendMultiItemEnquiry", "~/Enquiry/SendMultiItemEnquiry.aspx");
        public KeyValuePair<string, string> SendProductEnquiry = new KeyValuePair<string, string>("GetQuote", "~/Enquiry/SendProductEnquiry.aspx");
        public KeyValuePair<string, string> ViewCustomerEnquiries = new KeyValuePair<string, string>("ViewCustomerEnquiries", "~/Enquiry/ViewCustomerEnquiries.aspx");
        public KeyValuePair<string, string> ViewEnquiryInfo = new KeyValuePair<string, string>("ViewEnquiryInfo", "~/Enquiry/ViewEnquiryDetails.aspx");
        public KeyValuePair<string, string> ViewQuotationHistory = new KeyValuePair<string, string>("ViewQuotationHistory", "~/Enquiry/ViewQuotationHistory.aspx");
        public KeyValuePair<string, string> ViewQuotations = new KeyValuePair<string, string>("ViewQuotations", "~/Enquiry/ViewQuotations.aspx");
        public KeyValuePair<string, string> ViewVendorDetails = new KeyValuePair<string, string>("ViewVendorDetails", "~/Enquiry/ViewVendorDetails.aspx");

        //Misc
        public KeyValuePair<string, string> Pagenotfound = new KeyValuePair<string, string>("Pagenotfound", "~/Misc/PageNotFound.aspx");
        public KeyValuePair<string, string> Error = new KeyValuePair<string, string>("Error", "~/Misc/Error.aspx");

        //Notifications        
        public KeyValuePair<string, string> SendEmail = new KeyValuePair<string, string>("SendEmail", "~/Notifications/SendEmail.aspx");
        public KeyValuePair<string, string> SendSMS = new KeyValuePair<string, string>("SendSMS", "~/Notifications/SendSMS.aspx");

        //Payments
        public KeyValuePair<string, string> SecurePay = new KeyValuePair<string, string>("SecurePay", "~/Payment/SecurePay.aspx");
        public KeyValuePair<string, string> PaymentResponse = new KeyValuePair<string, string>("Response", "~/Payment/PaymentResponse.aspx");
        
        //Profile
        public KeyValuePair<string, string> ChangePassword = new KeyValuePair<string, string>("ChangePassword", "~/Profile/ChangePassword.aspx");
        public KeyValuePair<string, string> CustomerProfile = new KeyValuePair<string, string>("CustomerProfile", "~/Profile/CustomerProfile.aspx");
        public KeyValuePair<string, string> VendorProfile = new KeyValuePair<string, string>("VendorProfile", "~/Profile/VendorProfile.aspx");        
        
        //Registration        
        //public KeyValuePair<string, string> AgentActivation = new KeyValuePair<string, string>("AgentActivation", "~/Registration/AgentActivation.aspx");        
        public KeyValuePair<string, string> UserRegistration = new KeyValuePair<string, string>("UserRegistration", "~/Registration/UserRegistration.aspx");
        public KeyValuePair<string, string> UserRegistrationSuccess = new KeyValuePair<string, string>("UserRegistrationSuccess", "~/Registration/UserRegistrationSuccess.aspx");
        public KeyValuePair<string, string> VendorRegistration = new KeyValuePair<string, string>("VendorRegistration", "~/Registration/VendorRegistration.aspx");
        public KeyValuePair<string, string> VendorRegistrationSuccess = new KeyValuePair<string, string>("VendorRegistrationSuccess", "~/Registration/VendorRegistrationSuccess.aspx");        

        //Reports
        //public KeyValuePair<string, string> DynamicReport = new KeyValuePair<string, string>("AdminReports", "~/Reports/DynamicReport.aspx");

        //Roles        
        public KeyValuePair<string, string> ManageRoleAccess = new KeyValuePair<string, string>("ManageRoleAccess", "~/Roles/ManageRoleAccess.aspx");        
        public KeyValuePair<string, string> ViewRolesAccess = new KeyValuePair<string, string>("ViewRolesAccess", "~/Roles/ViewRolesAccess.aspx");

        //Subscriptions
        public KeyValuePair<string, string> ManageSubscription = new KeyValuePair<string, string>("ManageSubscription", "~/Subscriptions/ManageSubscription.aspx");
        public KeyValuePair<string, string> ViewSubscriptions = new KeyValuePair<string, string>("ViewSubscriptions", "~/Subscriptions/ViewSubscriptions.aspx");

        //User
        public KeyValuePair<string, string> ManageVendor = new KeyValuePair<string, string>("ManageVendor", "~/Users/ManageUser.aspx");
        public KeyValuePair<string, string> ManageVendors = new KeyValuePair<string, string>("ManageVendors", "~/Users/ManageUsers.aspx");
        public KeyValuePair<string, string> ViewVendors = new KeyValuePair<string, string>("ViewVendors", "~/Users/ViewUsers.aspx");

        public KeyValuePair<string, string> ManageCustomer = new KeyValuePair<string, string>("ManageCustomer", "~/Users/ManageUser.aspx");
        public KeyValuePair<string, string> ManageCustomers = new KeyValuePair<string, string>("ManageCustomers", "~/Users/ManageUsers.aspx");
        public KeyValuePair<string, string> ViewCustomers = new KeyValuePair<string, string>("ViewCustomers", "~/Users/ViewUsers.aspx");

        public KeyValuePair<string, string> ManageStaff = new KeyValuePair<string, string>("ManageStaff", "~/Users/ManageUser.aspx");
        public KeyValuePair<string, string> ViewStaff = new KeyValuePair<string, string>("ViewStaff", "~/Users/ViewUsers.aspx");

        //Vendor
        public KeyValuePair<string, string> ManageBusinessBranch = new KeyValuePair<string, string>("ManageBusinessBranch", "~/Vendor/ManageBusinessBranch.aspx");
        public KeyValuePair<string, string> ManageEnquiry = new KeyValuePair<string, string>("ManageEnquiry", "~/Vendor/ManageEnquiry.aspx");
        public KeyValuePair<string, string> ManageInventory = new KeyValuePair<string, string>("ManageInventory", "~/Vendor/ManageInventory.aspx");
        public KeyValuePair<string, string> ManageMultiItemEnquiry = new KeyValuePair<string, string>("ManageMultiItemEnquiry", "~/Vendor/ManageMultiItemEnquiry.aspx");
        public KeyValuePair<string, string> ViewBusinessBranches = new KeyValuePair<string, string>("ViewBusinessBranches", "~/Vendor/ViewBusinessBranches.aspx");
        public KeyValuePair<string, string> ViewInventory = new KeyValuePair<string, string>("ViewInventory", "~/Vendor/ViewInventory.aspx");
        public KeyValuePair<string, string> ViewVendorEnquiries = new KeyValuePair<string, string>("VendorEnquiries", "~/Vendor/ViewVendorEnquiries.aspx");

        public KeyValuePair<string, string> FooterAbouts = new KeyValuePair<string, string>("abouutus", "~/Footer/AboutUs.aspx");

        //Files
        //public KeyValuePair<string, string> ManageFiles = new KeyValuePair<string, string>("ManageFiles";
        //public KeyValuePair<string, string> ViewFiles = new KeyValuePair<string, string>("ViewFiles";
    }
}
