﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Net.Mail;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.DTO;
//using Newtonsoft.Json;
#endregion


namespace CLB.Util
{
    /// <summary>
    /// Utilities Class contains the general methods used in all pages
    /// </summary>
    public class Utilities
    {
        #region Public Variables

        //The string to used for making the key. The same string should be used for making the decrpt key
        public static string SharedSecret = "#@&&G@TEDCLUB!@#";
        public static string WebApiErrorPrefix = "Failed to process : ";        

        #endregion

        #region Private Variables

        private static readonly Byte[] Salt = Encoding.ASCII.GetBytes(SharedSecret.Length.ToString());

        #endregion

        #region Public Static Methods

        /// <summary>
        /// binds dropdownlist, checkboxlist or radiobutton list
        /// </summary>
        /// <param name="data"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="control"></param>
        public static void BindControl(Object data, String dataTextField, String dataValueField, Control control)
        {

            switch (control.GetType().Name)
            {
                case "DropDownList":
                    ((DropDownList)control).DataSource = data;
                    ((DropDownList)control).DataTextField = dataTextField;
                    ((DropDownList)control).DataValueField = dataValueField;
                    control.DataBind();
                    ((DropDownList)control).Items.Insert(0, new ListItem("Please Select", ""));
                    ((DropDownList)control).SelectedIndex = 0;
                    break;
                case "CheckBoxList":
                    ((CheckBoxList)control).DataSource = data;
                    ((CheckBoxList)control).DataTextField = dataTextField;
                    ((CheckBoxList)control).DataValueField = dataValueField;
                    control.DataBind();
                    break;
                case "RadioButtonList":
                    ((RadioButtonList)control).DataSource = data;
                    ((RadioButtonList)control).DataTextField = dataTextField;
                    ((RadioButtonList)control).DataValueField = dataValueField;
                    control.DataBind();
                    break;
            }
        }

        /// <summary>
        /// binds listbox, dropdownlist, checkboxlist or radiobutton list from enum
        /// </summary>
        /// <param name="control"></param>
        /// <param name="propertiesToSkip"></param>
        public static void BindControl<T>(Control control, string[] propertiesToSkip = null, int selectedIndex = 0)
        {
            switch (control.GetType().Name)
            {
                case "ListBox":
                    ((ListBox)control).Items.Clear();
                    foreach (var value in Enum.GetValues(typeof(T)).Cast<int>().
                        Where(value => value > 0 && (propertiesToSkip == null ||
                            !propertiesToSkip.Contains(Enum.GetName(typeof(T), value)))))
                        ((ListBox)control).Items.Add(new ListItem(Enum.GetName(typeof(T), value), value.ToString()));
                    break;
                case "DropDownList":
                    ((DropDownList)control).Items.Clear();
                    foreach (var value in Enum.GetValues(typeof(T)).Cast<int>().
                        Where(value => value > 0 && (propertiesToSkip == null || 
                            !propertiesToSkip.Contains(Enum.GetName(typeof(T), value)))))
                        ((DropDownList)control).Items.Add(new ListItem(Enum.GetName(typeof(T), value),
                                                                        value.ToString()));
                    ((DropDownList)control).Items.Insert(0, new ListItem("Please Select", ""));
                    ((DropDownList)control).SelectedIndex = selectedIndex;
                    break;
                case "CheckBoxList":
                    ((CheckBoxList)control).Items.Clear();
                    foreach (var value in Enum.GetValues(typeof(T)).Cast<int>().
                        Where(value => value > 0 && (propertiesToSkip == null || 
                            !propertiesToSkip.Contains(Enum.GetName(typeof(T), value)))))
                        ((CheckBoxList)control).Items.Add(new ListItem(Enum.GetName(typeof(T), value),
                                                                        value.ToString()));
                    break;
                case "RadioButtonList":
                    ((RadioButtonList)control).Items.Clear();
                    foreach (var value in Enum.GetValues(typeof(T)).Cast<int>().
                        Where(value => value > 0 && (propertiesToSkip == null || !propertiesToSkip.Contains(Enum.GetName(typeof(T), value)))))
                        ((RadioButtonList)control).Items.Add(new ListItem(Enum.GetName(typeof(T), value),
                                                                           value.ToString()));
                    ((RadioButtonList)control).SelectedIndex = selectedIndex;
                    break;
            }
        }

        /// <summary>
        /// Check if image exists in the respective path
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static bool CheckIfImageExists(string url)
        {
            bool exists;
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "HEAD";

            try
            {
                request.GetResponse();
                exists = true;
            }
            catch
            {
                exists = false;
            }
            return exists;
        }

        /// <summary>
        /// Method to return message in html format for specified message type
        /// </summary>
        /// <param name="message"></param>
        /// <param name="messageType"></param>
        /// <returns></returns>
        public static string CustomMessage(string message, MessageType messageType)
        {
            //don't show red color error to user
            if (messageType == MessageType.Error)
                messageType = MessageType.Info;

            return "<div class='" + messageType.ToString().ToLower() + "'>" +
                    "<img src='images/close_icon.gif' alt='close' style='float:right; cursor: pointer;' onclick='$(this).parent().remove();'/>" +
                    message + "</div>";
        }

        /// <summary>
        /// Method which does the encryption using Rijndeal algorithm.This is for decrypting the data
        /// which has orginally being encrypted using the above method
        /// </summary>
        /// <param name="inputText">The encrypted data which has to be decrypted</param>
        /// <returns>Decrypted Data</returns>
        public static string Decrypt(string inputText)
        {
            RijndaelManaged RijndaelCipher = null;
            try
            {
                if (inputText != string.Empty)
                {
                    //+ character is replaced with ' ' in url
                    inputText = inputText.Replace(' ', '+');
                    RijndaelCipher = new RijndaelManaged();
                    Byte[] encryptedData = Convert.FromBase64String(inputText);
                    //Making of the key for decryption
                    PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(SharedSecret, Salt);
                    //Creates a symmetric Rijndael decryptor object.
                    ICryptoTransform Decryptor = RijndaelCipher.CreateDecryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));
                    MemoryStream memoryStream = new MemoryStream(encryptedData);
                    //Defines the cryptographics stream for decryption.THe stream contains decrpted data
                    CryptoStream cryptoStream = new CryptoStream(memoryStream, Decryptor, CryptoStreamMode.Read);
                    Byte[] PlainText = new byte[encryptedData.Length];
                    Int32 DecryptedCount = cryptoStream.Read(PlainText, 0, PlainText.Length);
                    memoryStream.Close();
                    cryptoStream.Close();
                    //Converting to string
                    string decryptedData = Encoding.Unicode.GetString(PlainText, 0, DecryptedCount);
                    return decryptedData;
                }
                return string.Empty;
            }
            catch (Exception)
            {
                //throw ex;
                return string.Empty;
            }
            finally
            {
                // Clear the RijndaelManaged object. 
                if (RijndaelCipher != null)
                    RijndaelCipher.Clear();
            }
        }

        /// <summary>
        /// Override Decrypt method
        /// </summary>
        /// <param name="inputText">The encrypted data which has to be decrypted</param>
        /// <returns>Decrypted Data</returns>
        public static string Decrypt(object inputText)
        {
            if (inputText == null) return "";
            return Decrypt(inputText.ToString());
        }

        /// <summary>
        /// Method which does the encryption using Rijndeal algorithm
        /// </summary>
        /// <param name="inputText">Data to be encrypted</param>
        /// <returns>Encrypted Data</returns>
        public static string Encrypt(string inputText)
        {
            RijndaelManaged rijndaelCipher = null;
            try
            {
                rijndaelCipher = new RijndaelManaged();

                Byte[] PlainText = Encoding.Unicode.GetBytes(inputText);

                //This class uses an extension of the PBKDF1 algorithm defined in the PKCS#5 v2.0 
                //standard to derive bytes suitable for use as key material from a password. 
                //The standard is documented in IETF RRC 2898.

                PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(SharedSecret, Salt);
                //Creates a symmetric encryptor object. 
                ICryptoTransform Encryptor = rijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));
                MemoryStream memoryStream = new MemoryStream();
                //Defines a stream that links data streams to cryptographic transformations
                CryptoStream cryptoStream = new CryptoStream(memoryStream, Encryptor, CryptoStreamMode.Write);
                cryptoStream.Write(PlainText, 0, PlainText.Length);
                //Writes the final state and clears the buffer
                cryptoStream.FlushFinalBlock();
                Byte[] CipherBytes = memoryStream.ToArray();
                memoryStream.Close();
                cryptoStream.Close();
                string encryptedData = Convert.ToBase64String(CipherBytes);
                return encryptedData;
            }
            catch (Exception)
            {
                return string.Empty;
                //throw ex;
            }
            finally
            {
                // Clear the RijndaelManaged object. 
                if (rijndaelCipher != null)
                    rijndaelCipher.Clear();
            }

        }

        /// <summary>
        /// Override Encrypt methd
        /// </summary>
        /// <param name="inputText">Data to be encrypted</param>
        /// <returns>Encrypted Data</returns>
        public static string Encrypt(object inputText)
        {
            if (inputText == null) return "";
            return Encrypt(inputText.ToString());
        }

        /// <summary>
        /// Method to generate the encrypted password
        /// </summary>        
        public static String GetEncryptedPassword(String username, String password)
        {
            var strPassword = "¶¾±";
            strPassword += password.Trim();
            strPassword += "¶¾±";
            strPassword += username.Trim().ToLower();
            strPassword += "¶¾±";
            return FormsAuthentication.HashPasswordForStoringInConfigFile(strPassword, "md5");
        }

        public static string IPAddress = (HttpContext.Current == null) ? null : (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ??
            HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]);

        /// <summary>
        /// Generic method to remove special characters in given string
        /// </summary>
        /// <param name="content"></param>
        /// <param name="specialCharacters"></param>
        /// <returns></returns>
        public static string RemoveSpecialCharacters(string content, string[] specialCharacters)
        {
            return specialCharacters.Aggregate(content, (current, character) => current.Replace(character, string.Empty));
        }

        public static bool SendAdminEmail(string pSubject, string pBody)
        {
            try
            {
                string text = System.IO.File.ReadAllText(HttpContext.Current.Server.MapPath("~/App_Data/email.html"));
                //when email is to be sent form email server
                var smtpHost = ConfigurationManager.AppSettings["smtpHost"];
                var smtpPort = ConfigurationManager.AppSettings["smtpPort"];
                var emailId = ConfigurationManager.AppSettings["EmailId"];
                var password = Decrypt(ConfigurationManager.AppSettings["Password"]);
                var supportEmail = ConfigurationManager.AppSettings["SupportEmail"];

                var smtpClient = new SmtpClient();
                var message = new MailMessage();
                var fromAddress = new MailAddress(emailId, "");
                var toAddress = new MailAddress(supportEmail, "");
                message.From = fromAddress;
                message.To.Add(toAddress);
                message.Subject = pSubject;

                message.Body = text.Replace("##SUBJECT", pSubject).Replace("##CONTENT", pBody).Replace("##SITELINK", "http://" + smtpHost.Replace("mail.", ""));
                message.IsBodyHtml = true;

                smtpClient.Host = smtpHost;
                smtpClient.Port = Convert.ToInt32(smtpPort);
                smtpClient.Credentials = new NetworkCredential(emailId, password);
                //smtpClient.EnableSsl = true;
                smtpClient.Send(message);
                return true;
            }
            catch (Exception)
            {   
                //do nothing...
                //LogException(ex);
                return false;
            }
        }

        /// <summary>
        /// Method to Send Email
        /// </summary>
        /// <returns></returns>
        public static bool SendEmail(string pTo, string pSubject, string pBody, string attachmentPath = null, string pCc = null, string pBCc = null, 
            bool isHtmlBody = true)
        {
            try
            {
                if (bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"])) return true;

                string text = System.IO.File.ReadAllText(HttpContext.Current.Server.MapPath("~/App_Data/email.html"));
                //when email is to be sent form email server
                var smtpHost = ConfigurationManager.AppSettings["smtpHost"];
                var smtpPort = ConfigurationManager.AppSettings["smtpPort"];
                var emailId = ConfigurationManager.AppSettings["EmailId"];
                var password = Decrypt(ConfigurationManager.AppSettings["Password"]);
                var supportEmail = ConfigurationManager.AppSettings["SupportEmail"];
                
                var smtpClient = new SmtpClient();
                var message = new MailMessage();
                var fromAddress = new MailAddress(emailId, "");
                var toAddress = new MailAddress(pTo, "");
                message.From = fromAddress;
                message.To.Add(toAddress);
                message.Subject = pSubject;

                message.Body = text.Replace("##SUBJECT", pSubject).Replace("##CONTENT", pBody).Replace("##SITELINK", "http://" + smtpHost.Replace("mail.", ""));
                message.IsBodyHtml = isHtmlBody;
                if (!string.IsNullOrEmpty(attachmentPath))
                {
                    Attachment MyAttachment = new Attachment(attachmentPath);
                    message.Attachments.Add(MyAttachment);
                    message.Priority = MailPriority.High;
                }

                if (!string.IsNullOrEmpty(pBCc))
                {
                    foreach (
                        var bcc in
                            pBCc.Split(',').Where(x => !string.IsNullOrEmpty(x)).Select(x => new MailAddress(x))
                        )
                        message.Bcc.Add(bcc);

                    if (HttpContext.Current != null && HttpContext.Current.Session != null)
                    {
                        if (HttpContext.Current.Session[SessionVariables.CurrentUser] != null)
                        {
                            //comment this if client email is not intended to receive emails
                            //message.Bcc.Add(((User)HttpContext.Current.Session[SessionVariables.CurrentUser]).Role !=
                            //                (int)Role.SuperAdmin
                            //    ? clientDetails.Email
                            //    : emailId);
                        }
                        else
                            message.Bcc.Add(pBCc);
                    }
                }
                if (supportEmail != null)
                    message.Bcc.Add(supportEmail);

                if (!string.IsNullOrEmpty(pCc))
                {
                    var ccAddress = new MailAddress(pCc);
                    message.CC.Add(ccAddress);
                }

                smtpClient.Host = smtpHost;
                smtpClient.Port = Convert.ToInt32(smtpPort);
                smtpClient.Credentials = new NetworkCredential(emailId, password);
                //smtpClient.EnableSsl = true;
                smtpClient.Send(message);
                return true;
            }
            catch (Exception ex)
            {
                ResendFromAdminMail(ex, pTo, pSubject, pBody, pCc, pBCc, null, isHtmlBody);
                // LogException(ex);
                return false;
            }
        }

        //public static Boolean SendGmail(String pGmailEmail, String pGmailPassword, String bCC, String pSubject, String pBody, System.Web.Mail.MailFormat pFormat, String pAttachmentPath)
        //{
        //    try
        //    {
        //        System.Web.Mail.MailMessage myMail = new System.Web.Mail.MailMessage();
        //        myMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpserver", "smtp.gmail.com");
        //        myMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpserverport", "465");
        //        myMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusing", "2");
        //        //sendusing: cdoSendUsingPort, value 2, for sending the message using 
        //        //the network.

        //        //smtpauthenticate: Specifies the mechanism used when authenticating 
        //        //to an SMTP 
        //        //service over the network. Possible values are:
        //        //- cdoAnonymous, value 0. Do not authenticate.
        //        //- cdoBasic, value 1. Use basic clear-text authentication. 
        //        //When using this option you have to provide the user name and password 
        //        //through the sendusername and sendpassword fields.
        //        //- cdoNTLM, value 2. The current process security context is used to 
        //        // authenticate with the service.
        //        myMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", "1");
        //        //Use 0 for anonymous
        //        myMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", pGmailEmail);
        //        myMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", pGmailPassword);
        //        myMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpusessl", "true");
        //        myMail.From = pGmailEmail;
        //        if (!string.IsNullOrEmpty(bCC))
        //            myMail.Bcc = string.Join(";", bCC.Split(','));
        //        myMail.Subject = pSubject;
        //        myMail.BodyFormat = pFormat;
        //        myMail.Body = pBody;
        //        if (pAttachmentPath.Trim() != "")
        //        {
        //            System.Web.Mail.MailAttachment MyAttachment = new System.Web.Mail.MailAttachment(pAttachmentPath);
        //            myMail.Attachments.Add(MyAttachment);
        //            myMail.Priority = System.Web.Mail.MailPriority.High;
        //        }

        //        System.Web.Mail.SmtpMail.SmtpServer = "smtp.gmail.com:465";
        //        System.Web.Mail.SmtpMail.Send(myMail);
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //    }
        //}


        /// <summary>
        /// Method to Send SMS
        /// </summary>
        /// <param name="contactNumber"></param>
        /// <param name="message"></param>
        /// <param name="consumerKey"></param>
        /// <returns></returns>
        public static string SendSMS(string contactNumber, string message)
        {
            try
            {
                var userName = ConfigurationManager.AppSettings["SMSUsername"];
                var password = Decrypt(ConfigurationManager.AppSettings["SMSPassword"]);
                var senderName = ConfigurationManager.AppSettings["SMSSenderName"];
                var SMSUrl = ConfigurationManager.AppSettings["SMSUrl"];
                var url = SMSUrl + "?username=" + userName + "&password=" + password + "&sendername=" + senderName +
                          "&mobileno=91" + contactNumber + "&message=" + message;
                var request = (HttpWebRequest)WebRequest.Create(url);
                var response = (HttpWebResponse)request.GetResponse();
                var responseStream = response.GetResponseStream();
                var readStream = new StreamReader(responseStream, Encoding.UTF8);
                return readStream.ReadToEnd();
            }
            catch (Exception ex)
            {
                var adminEmail = ConfigurationManager.AppSettings["AdminEmail"];
                var supportEmail = ConfigurationManager.AppSettings["SupportEmail"];
                //send email notification to admin / support on sms failure
                SendEmail(supportEmail, "SMS Failure Notification",
                    "Failed to send SMS - Contact No: " + contactNumber +
                    "<br/><br/>Message:" + ex.Message + "<br/><br/>StackTrace" + ex.StackTrace,
                    null, adminEmail);
                return "";
            }
        }

        #endregion

        #region Private Methods

        //private bool SkipLoop(List<CommissionMarkup> commissionMarkups, CommissionMarkup commissionMarkup, string travelOperator, int? serviceSubType)
        //{
        //    //check if multiple commissionmarkups are set by user
        //    if (commissionMarkups.Count(x => x.Role == commissionMarkup.Role) <= 1) return false;

        //    var commissionMarkupList = commissionMarkups.Where(x => x.UserId == commissionMarkup.UserId).ToList();

        //    //do not skip the loop as user has set single commissionmarkup
        //    if (commissionMarkupList.Count == 1) return false;

        //    if (serviceSubType.HasValue)
        //    {
        //        //check if markup is set on service sub-type and operator 
        //        if (commissionMarkupList.Count(x => x.OperatorName == travelOperator &&
        //                                         x.ServiceSubType == serviceSubType) > 0)
        //        {
        //            if (commissionMarkup.OperatorName != travelOperator ||
        //                commissionMarkup.ServiceSubType != serviceSubType) return true;
        //        }

        //        else if (commissionMarkupList.Count(x => x.OperatorId == null && x.ServiceSubType == serviceSubType) > 0)
        //        {
        //            if (commissionMarkup.OperatorId != null || commissionMarkup.ServiceSubType != serviceSubType) return true;
        //        }
        //        else if (commissionMarkupList.Count(
        //            x => x.ServiceSubType == null && x.OperatorName == travelOperator) > 0)
        //        {
        //            if (commissionMarkup.OperatorName != travelOperator ||
        //                commissionMarkup.ServiceSubType != null) return true;
        //        }
        //        //indicates no commission/markup is set on specific service sub-type
        //        //check if any commission/markup is set on all service sub-types
        //        else if (commissionMarkupList.Count(x => x.ServiceSubType == null && x.OperatorId == null) > 0)
        //        {
        //            if (commissionMarkup.OperatorId != null ||
        //                commissionMarkup.ServiceSubType != null) return true;
        //        }
        //        //indicates no commission/markup is set on all service sub-types
        //        //set 0 values of commission and markups as user has not set any commission
        //        else
        //        {
        //            //if (commissionMarkupList.IndexOf(commissionMarkup) == 0)
        //            //{
        //            //    commissionMarkup.Markup = 0;
        //            //    commissionMarkup.Commission = 0;
        //            //}
        //            //else
        //                return true;
        //        }
        //    }
        //    else
        //    {
        //        if (commissionMarkupList.Count(x => x.OperatorName == travelOperator) <= 0) return false;
        //        if (commissionMarkup.OperatorName != travelOperator) return true;
        //    }
        //    return false;
        //}

        /// <summary>
        /// Method to send email notification to support team when email sending fails
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="pTo"></param>
        /// <param name="pSubject"></param>
        /// <param name="pBody"></param>
        /// <param name="isHtmlBody"></param>
        private static void SendEmailFailuteNotification(Exception ex, string pTo, string pSubject, string pBody, bool isHtmlBody = true)
        {
            try
            {
                //when email is to be sent form email server
                var smtpHost = ConfigurationManager.AppSettings["smtpHost"];
                var smtpPort = ConfigurationManager.AppSettings["smtpPort"];
                var emailId = ConfigurationManager.AppSettings["EmailId"];
                var password = Decrypt(ConfigurationManager.AppSettings["Password"]);
                var supportEmail = ConfigurationManager.AppSettings["SupportEmail"];
                var adminEmail = ConfigurationManager.AppSettings["AdminEmail"];

                var smtpClient = new SmtpClient();
                var message = new MailMessage();
                var fromAddress = new MailAddress(emailId, "");
                var toAddress = new MailAddress(supportEmail, "");
                message.From = fromAddress;
                message.To.Add(toAddress);
                message.Subject = "Email sending failure notification";
                message.Body = "Email details <br/><br/> To: " + pTo + "<br/>Subject: " + pSubject + "<br/>Body: " +
                               pBody +
                               "<br/><br/><br/><br/> <b>Exception Details<b/><br/><br/>" + ex.Message;
                message.IsBodyHtml = isHtmlBody;

                var ccAddress = new MailAddress(adminEmail);
                message.CC.Add(ccAddress);

                smtpClient.Host = smtpHost;
                smtpClient.Port = Convert.ToInt32(smtpPort);
                smtpClient.Credentials = new NetworkCredential(emailId, password);
                //smtpClient.EnableSsl = true;
                smtpClient.Send(message);
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Method to send email from admin email when mail sending fails from client's smtp
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="pTo"></param>
        /// <param name="pSubject"></param>
        /// <param name="pBody"></param>
        /// <param name="pCc"></param>
        /// <param name="pBCc"></param>
        /// <param name="consumerKey"></param>
        /// <param name="isHtmlBody"></param>
        private static void ResendFromAdminMail(Exception ex, string pTo, string pSubject, string pBody,
            string pCc = null, string pBCc = null, string consumerKey = null, bool isHtmlBody = true)
        {
            try
            {
                //when email is to be sent form email server
                var smtpHost = ConfigurationManager.AppSettings["smtpHost"];
                var smtpPort = ConfigurationManager.AppSettings["smtpPort"];
                var emailId = ConfigurationManager.AppSettings["EmailId"];
                var password = Decrypt(ConfigurationManager.AppSettings["Password"]);
                var supportEmail = ConfigurationManager.AppSettings["SupportEmail"];

                var smtpClient = new SmtpClient();
                var message = new MailMessage();
                var fromAddress = new MailAddress(emailId, "");
                var toAddress = new MailAddress(pTo, "");
                message.From = fromAddress;
                message.To.Add(toAddress);
                message.Subject = pSubject;
                message.Body = pBody;
                message.IsBodyHtml = true;

                if (!string.IsNullOrEmpty(pBCc))
                {
                    var bccAddress = new MailAddress(pBCc);
                    message.Bcc.Add(bccAddress);
                }
                if (supportEmail != null)
                    message.Bcc.Add(supportEmail);

                if (!string.IsNullOrEmpty(pCc))
                {
                    var ccAddress = new MailAddress(pCc);
                    message.CC.Add(ccAddress);
                }

                smtpClient.Host = smtpHost;
                smtpClient.Port = Convert.ToInt32(smtpPort);
                smtpClient.Credentials = new NetworkCredential(emailId, password);
                //smtpClient.EnableSsl = true;
                smtpClient.Send(message);

                //intimate admin about mail sending failure from client mail
                if (!string.IsNullOrEmpty(consumerKey) && HttpRuntime.Cache["ClientDetails-" + consumerKey] != null &&
                    supportEmail != null)
                {
                    //var clientDetails = (Client)HttpRuntime.Cache["ClientDetails-" + consumerKey];
                    ////smtpHost = clientDetails.SmtpHost;
                    ////smtpPort = clientDetails.SmtpPort;
                    ////emailId = clientDetails.Email;
                    ////password = Decrypt(clientDetails.EmailPassword);

                    //var smtClient = new SmtpClient();
                    //var supportmessage = new MailMessage
                    //{
                    //    From = new MailAddress(emailId, ""),
                    //    Subject =
                    //        "Failed to send email notification to " + pTo + " from " + clientDetails.Email +
                    //        " Client mail",
                    //    Body =
                    //        "Dear Admin, <br/><br/> This is to inform you that following email notification was failed to send from " +
                    //        clientDetails.Email +
                    //        " to " + pTo + " <br/><br/><br/> " + pBody +
                    //        " <br/><br/> Regards,<br/>Support Team.",
                    //    IsBodyHtml = isHtmlBody
                    //};

                    //supportmessage.To.Add(new MailAddress(supportEmail, ""));

                    //smtClient.Host = smtpHost;
                    //smtClient.Port = Convert.ToInt32(smtpPort);
                    //smtClient.Credentials = new NetworkCredential(emailId, password);
                    ////smtpClient.EnableSsl = true;
                    //smtClient.Send(supportmessage);
                }

            }
            catch (Exception)
            {
                SendEmailFailuteNotification(ex, pTo, pSubject, pBody, isHtmlBody);
            }
        }

        #endregion

    }    
}
namespace CLB.DTO
{
    public class AutoComplete
    {
        public string label { get; set; }
        public string id { get; set; }
    }
}