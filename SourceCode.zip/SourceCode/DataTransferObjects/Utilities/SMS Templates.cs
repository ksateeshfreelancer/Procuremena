﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Web;

#endregion

namespace CLB.Util
{

    /// <summary>
    /// SMSTemplates contains general methods to retrieve sms template content
    /// </summary>
    public class SMSTemplates
    {
        #region Private Variables

        private static readonly string SMSTemplatesUrl =
            (bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]) ? "" : "http://") +
            ConfigurationManager.AppSettings["PSAUrl"] + "/ServerData/SMSTemplates/";

        private static readonly Dictionary<string, string> Dictionary = new Dictionary<string, string>
            {
                {SMSFormats.AddBalance.ToString(), SMSTemplatesUrl + "AddBalance.txt"},
                {SMSFormats.RevokBalance.ToString(), SMSTemplatesUrl + "RevokeBalance.txt"},
                {SMSFormats.DepositRequest.ToString(), SMSTemplatesUrl + "DepositRequest.txt"},
                {SMSFormats.AcceptOfDepositRequest.ToString(), SMSTemplatesUrl + "AcceptDepositRequest.txt"},
                {SMSFormats.RejectOfDepositRequest.ToString(), SMSTemplatesUrl + "RejectDepostRequest.txt"},
            };

        #endregion

        #region Public Methods

        public static string OutMessage(SMSTemplates smsFormats)
        {
            //request from local
            if (bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
            {
                var streamReader = new StreamReader(HttpContext.Current.Server.MapPath((Dictionary[smsFormats.ToString()])));
                return streamReader.ReadToEnd();
            }
            //request from server
            var webClient = new WebClient();
            var result = webClient.DownloadString(Dictionary[smsFormats.ToString()]);
            return result;
        }

        #endregion
    }

}
