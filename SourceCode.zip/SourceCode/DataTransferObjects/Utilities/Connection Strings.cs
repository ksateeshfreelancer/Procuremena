﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System.Configuration;

#endregion

namespace CLB.Util
{
    /// <summary>
    /// ConnectionStrings contains the list of all connections used in TravelPortal
    /// </summary>
    public static class ConnectionStrings
    {
        #region Public Constants

        public static string ConnectionString
        {
            get
            {
                return Util.Utilities.Decrypt(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            }
        }

        public const string CurrentUser = "4859SKEyn0CI+YgFgZWJ2CU9ISrAnw7LYrL9ZOZ867E=";
        public const string LogoUrl = "dl2bkBDTf6a56ep7HZ13Cw==";

        #endregion
    }
}
