﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums.Database;
using System.Collections.Generic;
using System.Configuration;

#endregion

namespace CLB.Util
{
    /// <summary>
    /// DbConstants contains methods to return predefined messages for database messages
    /// </summary>
    public class DbConstants
    {
        static string imgSrc = "<img src='images/close_icon.gif' alt='close' style='float:right; cursor: pointer;' onclick='$(this).parent().remove();'/>";
        public static string DateFormat = "yyyy-MM-dd";

        // Create a new dictionary of strings, with string keys.
        static readonly Dictionary<string, string> Dictionary = new Dictionary<string, string>
                {   
                    {DbMessage.CredentialsIncorrect.ToString(), "<div class='error'>" + imgSrc + "Invalid Credentials.</div>"},
                    {DbMessage.Duplicate.ToString(), "<div class='warning'>" + imgSrc + "{0} already exists.</div>"},
                    {DbMessage.InActive.ToString(), "<div class='info'>" + imgSrc + "Account is currently inactive.</div>"},
                    {DbMessage.Locked.ToString(), "<div class='info'>" + imgSrc + "Account is locked. Please contact administrator.</div>"},
                    {DbMessage.NotFound.ToString(), "<div class='info'>" + imgSrc + "{0} not found.</div>"},
                    {DbMessage.OldPasswordIncorrect.ToString(), "<div class='error'>" + imgSrc + "Current Password is incorrect.</div>"},
                    {DbMessage.PasswordChanged.ToString(), "<div class='success'>" + imgSrc + "Password changed successfully.</div>"},
                    {DbMessage.Success.ToString(), "<div class='success'>" + imgSrc + "{0} saved successfully.</div>"},
                    {DbMessage.Created.ToString(), "<div class='success'>" + imgSrc + "{0} created successfully.</div>"},
                    {DbMessage.Sent.ToString(), "<div class='success'>" + imgSrc + "{0} sent successfully.</div>"},
                    {DbMessage.Delete.ToString(), "<div class='success'>" + imgSrc + "{0} deleted successfully.</div>"},
                    {DbMessage.Failed.ToString(), "<div class='error'>" + imgSrc + "Oops! some thing went wrong, please try again after some time.</div>"},
                    {DbMessage.Unauthorized.ToString(), "<div class='error'>" + imgSrc + "Unauthorized operation. Please contact Administrator.</div>"},
                    {DbMessage.ForeignKeyRelationship.ToString(), "<div class='info'>" + imgSrc + "Can't delete {0} as it is associated with {1}.</div>"},
                    {DbMessage.AlreadyLoggedIn.ToString(), "<div class='error'>" + imgSrc + "User is already logged in. Unable to continue.</div>"},
                    {DbMessage.CustomMessage.ToString(), "<div class='{0}'>" + imgSrc + "{1}.</div>"}
                };

        public static string OutMessage(DbMessage dbMessage)
        {
            return Dictionary[dbMessage.ToString()];
        }

        public static string OutMessage(DbMessage dbMessage, string table)
        {
            return string.Format(Dictionary[dbMessage.ToString()], table);
        }

        public static string OutMessage(DbMessage dbMessage, string table, string column)
        {
            return string.Format(Dictionary[dbMessage.ToString()], table.ToLower(), column);
        }
    }
}
