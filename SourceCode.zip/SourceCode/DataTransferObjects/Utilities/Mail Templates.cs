﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Web;

#endregion

namespace CLB.Util
{
    /// <summary>
    /// MailTemplates contains general methods to retrieve mail template content
    /// </summary>
    public class MailTemplates
    {
        #region Private Variables

        private static readonly string EmailTemplatesUrl =
            (bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]) ? "" : "http://") +
            ConfigurationManager.AppSettings["PSAUrl"] + "/ServerData/EmailTemplates/";

        private static readonly Dictionary<string, string> Dictionary = new Dictionary<string, string>
            {
                {EmailTemplates.UserRegistration.ToString(), EmailTemplatesUrl + "Registration.txt"},
                {EmailTemplates.AgentDistWlRegRequest.ToString(), EmailTemplatesUrl + "AgentDistWLRegRequest.txt"},
                {EmailTemplates.ChangeTxnPassword.ToString(), EmailTemplatesUrl + "ChangeTxnPassword.txt"},
                {EmailTemplates.StatusUpdate.ToString(), EmailTemplatesUrl + "AccountInActive.txt"},
                {EmailTemplates.ForgotPassword.ToString(), EmailTemplatesUrl + "ForgotPassword.txt"},
                {EmailTemplates.DepositRequest.ToString(), EmailTemplatesUrl + "DepositRequest.txt"},
                {EmailTemplates.DepositReject.ToString(), EmailTemplatesUrl + "DepositReject.txt"},
                {EmailTemplates.DepositUpdate.ToString(), EmailTemplatesUrl + "DepositUpdate.txt"},
                {EmailTemplates.CancelTicket.ToString(), EmailTemplatesUrl + "CancelTicket.htm"},
                {EmailTemplates.PrintTicket.ToString(), EmailTemplatesUrl + "PrintTicket.htm"},
                {EmailTemplates.ServiceUpdate.ToString(), EmailTemplatesUrl + "ServiceUpdate.txt"},
                {EmailTemplates.AddAmount.ToString(), EmailTemplatesUrl + "AddBalance.txt"},
                {EmailTemplates.RevokeAmount.ToString(), EmailTemplatesUrl + "RevokingBalance.txt"},
                {EmailTemplates.ChangePassword.ToString(), EmailTemplatesUrl + "ChangePassword.txt"},
                {EmailTemplates.ZeroBalanceAlert.ToString(), EmailTemplatesUrl + "ZeroBalanceAlert.txt"},
                {EmailTemplates.LowBalanceAlert.ToString(), EmailTemplatesUrl + "BalanceAlert.txt"},
                {EmailTemplates.SiteAdminRegistration.ToString(), EmailTemplatesUrl + "SiteAdminRegistation.txt"},
                {EmailTemplates.Invoice.ToString(), EmailTemplatesUrl + "Invoice.htm"},
                {EmailTemplates.FlightTicket.ToString(), EmailTemplatesUrl + "FlightTicket.htm"},
                {EmailTemplates.HotelRoomBooking.ToString(), EmailTemplatesUrl + "HotelRoomBooking.htm"},
                {EmailTemplates.CabTicket.ToString(), EmailTemplatesUrl + "CabTicket.htm"}
            };

        #endregion

        #region Public Methods

        public static string OutMessage(EmailTemplates emailTemplate)
        {
            //request from local
            if (bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
            {
                var streamReader = new StreamReader(HttpContext.Current.Server.MapPath((Dictionary[emailTemplate.ToString()])));
                return streamReader.ReadToEnd();
            }
            //request from server
            var webClient = new WebClient();
            var result = webClient.DownloadString(Dictionary[emailTemplate.ToString()]);
            return result;
        }

        #endregion
    }

}
