﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System.Configuration;

#endregion

namespace CLB.Util
{
    public class SessionVariables
    {
        public const string UserId = "UserID";
        public const string CountryId = "CountryID";
        public const string CurrentUser = "CurrentUser";
        public const string CaptchaImageText = "CaptchaImageText";
        public const string SubscriptionDetails = "SubscriptionDetails";
        public const string SearchParams = "SearchParams";
        public const string SearchProdIds = "SearchProdIds";
    }
}
