﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Web;

#endregion

namespace CLB.Util
{
    /// <summary>
    /// SMSNotifications contains general methods to send smses on bookings/recharges
    /// </summary>
    public class SMSNotifications
    {
        public static string RechargeSuccess(string rechargeNumber, string amount, string referenceNumber)
        {
            return "You have successfully recharged mobile no " + rechargeNumber + "  for Rs. " + amount + ". Transaction No: " + referenceNumber;
        }

    }
}
