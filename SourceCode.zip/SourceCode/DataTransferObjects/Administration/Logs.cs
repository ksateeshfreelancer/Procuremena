﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums.Database;
using CLB.Enums;
using System;

#endregion

namespace CLB.DTO
{
    /// <summary>
    /// DbErrorLog class contains the common properties that store the details of database errors
    /// </summary>
    [Serializable]
    public class DbErrorLog
    {
        public int DbErrorLogID { get; set; }
        public int ErrorNumber { get; set; }
        public int ErrorLine { get; set; }
        public string ErrorMessage { get; set; }
        public int ErrorSeverity { get; set; }
        public int ErrorState { get; set; }
        public string ErrorProcedure { get; set; }
        public string LogDate { get; set; }
    }

    /// <summary>
    /// ErrorLog class contains the common properties that store the details of UI errors
    /// </summary>

    [Serializable]
    public class ErrorLog
    {
        public int ErrorLogID { get; set; }
        public string Page { get; set; }
        public string Method { get; set; }
        public string ErrorMessage { get; set; }
        public string DetailedMessage { get; set; }
        public string IPAddress { get; set; }
        public string LogDate { get; set; }
        public string UserId { get; set; }
    }

    /// <summary>
    /// LoginLog class contains the common properties that store the details of user logins
    /// </summary>
    [Serializable]
    public class LoginLog
    {
        public int LoginLogID { get; set; }
        public User User { get; set; }
        public string LoginDateTime { get; set; }
        public string LogoutDateTime { get; set; }
        public string IPAddress { get; set; }
        public Status Status { get; set; }
    }

    [Serializable]
    public class EmailLog
    {
        public int EmailLogID { get; set; }
        public string Emails { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    [Serializable]
    public class SMSLog
    {
        public int SMSLogID { get; set; }
        public string PhoneNos { get; set; }
        public string Message { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
