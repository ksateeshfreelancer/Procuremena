﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class Category
    {
        public int CategoryID { get; set; }
        public MainCategory MainCategory { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string CategoryName { get; set; }
        /// <summary>
        /// Max length 200
        /// </summary>
        public string AliasNames { get; set; }
        public int DisplayOrder { get; set; }
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        [XmlIgnore]
        public List<SubCategory> SubCategories { get; set; }

        [XmlIgnore]
        public string Href { get; set; }

        [XmlIgnore]
        public string ImagePath { get; set; }
    }

    [Serializable]
    public class City
    {
        public int CityID { get; set; }
        public Country Country { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string CityName { get; set; }
        /// <summary>
        /// Max length 200
        /// </summary>
        public string AliasNames { get; set; }
        public int DisplayOrder { get; set; }
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class Country
    {
        public int CountryID { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string CountryName { get; set; }        
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class MainCategory
    {
        public int MainCategoryID { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string MainCategoryName { get; set; }
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class SubCategory
    {
        public int SubCategoryID { get; set; }
        public Category Category { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string SubCategoryName { get; set; }
        /// <summary>
        /// Max length 200
        /// </summary>
        public string AliasNames { get; set; }
        public int DisplayOrder { get; set; }
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        [XmlIgnore]
        public string Href { get; set; }
    }

    [Serializable]
    public class UnitofMeasurement
    {
        public int UnitID { get; set; }       
        /// <summary>
        /// Max length 50
        /// </summary>
        public string UnitName { get; set; }
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
