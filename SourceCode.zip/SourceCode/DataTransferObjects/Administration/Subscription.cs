﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 11-Mar-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class PlanFeature
    {
        /// <summary>
        /// price Feature ID
        /// </summary>
        public int PlanFeatureID { get; set; }
        /// <summary>
        /// price feature name.. Max length 100
        /// </summary>
        public string FeatureName { get; set; }
        /// <summary>
        /// description for feature. Max length 500
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// control type to display ex:textbox,checkbox
        /// </summary>
        public int ControlType { get; set; }
        /// <summary>
        /// control value to display
        /// </summary>
        public string ControlValue { get; set; }
        /// <summary>
        /// Indicates whether feature is editable by admin or not
        /// </summary>
        [XmlIgnore]
        public bool IsEditable { get; set; }
        /// <summary>
        /// user who create plan feature
        /// </summary>
        public string CreatedBy { get; set; }
        /// <summary>
        /// created date of plan feature
        /// </summary>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// user who modify plan feature 
        /// </summary>
        public string ModifiedBy { get; set; }
        /// <summary>
        /// modified date of plan feature
        /// </summary>
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class PricePlan
    {
        public int PlanID { get; set; }
        /// <summary>
        /// plane name. Max length 50
        /// </summary>
        public string PlanName { get; set; }
        public double PlanPrice { get; set; }
        public Frequency PlanSubscription { get; set; }
        /// <summary>
        /// plan and its features. Property is added for UI flexibility
        /// </summary>
        public List<PlanFeature> PlanFeatures { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class PriceManagement
    {        
        public int PriceManagementID { get; set; }        
        public int PlanID { get; set; }
        public int PlanFeatureID { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string ControlValue { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class Subscription
    {
        public int SubscriptionID { get; set; }
        public PricePlan PricePlan { get; set; }
        public User User { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsExpired { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

}
