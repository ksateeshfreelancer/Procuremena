﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 11-Mar-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
#endregion

namespace CLB.DTO
{   
    [Serializable]
    public class BannerAd
    {
        public long BannerAdID { get; set; }
        public User User { get; set; }
        public VendorInventory Inventory { get; set; }
        public BannerPosition BannerPosition { get; set; }
        public DateTime ExpiryDate { get; set; }
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
