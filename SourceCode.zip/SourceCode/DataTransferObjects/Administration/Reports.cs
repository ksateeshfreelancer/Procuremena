﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 11-Mar-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
#endregion

namespace CLB.DTO
{
    /*
    [Serializable]
    public class RptProductsBySales
    {   
        public string ProductName { get; set; } 
        public int Sales { get; set; }        
    }

    [Serializable]
    public class RptUsersByRank
    {
        public string RankName { get; set; }
        public int Users { get; set; }
    }
    */
}
