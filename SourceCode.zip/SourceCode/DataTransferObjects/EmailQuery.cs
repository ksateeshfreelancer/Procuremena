﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 9-May-2014
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class Query
    {
        public long QueryID { get; set; }
        public User User { get; set; }
        public long ThreadID { get; set; }
        public bool IsParent { get; set; }
        public bool IsRead { get; set; }
        public QueryCategory QueryCategory { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
