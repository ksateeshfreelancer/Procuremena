﻿#region Developer Note
/*
 * Created by       : Suresh
 * Created Date     : 16-Feb-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class Config
    {
        public int ConfigurationID { get; set; }
        public string DisplayName { get; set; }
        public string Name { get; set; }
        public double Value { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
