﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class Role
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public int Level { get; set; }
        public List<Screen> Screens { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
