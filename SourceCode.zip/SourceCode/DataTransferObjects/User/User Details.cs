﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class UserDetails
    {
        public int UserID { get; set; }
        /// <summary>
        /// Max Length 50
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// Max Length 50
        /// </summary>
        public string LastName { get; set; }
        public Gender Gender { get; set; }
        public DateTime DOB { get; set; }
        public Country Country { get; set; }
        /// <summary>
        /// Max Length 15
        /// </summary>
        public string RegisteredIP { get; set; }        
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
