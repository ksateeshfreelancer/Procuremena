﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 11-Mar-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
#endregion

namespace CLB.DTO
{   
    [Serializable]
    public class BusinessBranchDetails
    {
        public int BranchID { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string BranchName { get; set; }
        public int UserID { get; set; }
        /// <summary>
        /// Max length 6
        /// </summary>
        public string Pincode { get; set; }
        /// <summary>
        /// Max length 500
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string Landmark { get; set; }
        public int CityID { get; set; }
        /// <summary>
        /// Property is declared only for UI flexibility
        /// </summary>
        public string CityName { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string Emails { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string Phones { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class BusinessDetails
    {
        public int UserID { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string BusinessName { get; set; }                
        public BusinessType BusinessType { get; set; }
        /// <summary>
        /// Max length 10
        /// </summary>
        public string PAN { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string Emails { get; set; }
        /// <summary>
        /// Max length 15
        /// </summary>
        public string PrimaryPhone { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string Phones { get; set; }
        public int CityID { get; set; }
        /// <summary>
        /// Property defined for UI flexibility
        /// </summary>
        public string CityName { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// Max length 500
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// Max length 6
        /// </summary>
        public string Pincode { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string WebsiteURL { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class VendorInventory
    {
        public long InventoryID { get; set; }        
        public int UserID { get; set; }
        /// <summary>
        /// Property not defined in table. used for UI flexibility
        /// </summary>
        public User User { get; set; }
        /// <summary>
        /// Property not defined in table. used for UI flexibility
        /// </summary>
        public BusinessDetails BusinessDetails { get; set; }
        public ProductCatalog Product { get; set; }
        /// <summary>
        /// Max length 1000
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// Max length 200
        /// </summary>
        public string MoreRedirectURL { get; set; }
        /// <summary>
        /// Property not defined in table. used for UI flexibility
        /// </summary>
        [XmlIgnore]
        public string ImageUrl { get; set; }
        public bool ShowProductInSearch { get; set; }
        public double PricePerUnit { get; set; }
        public UnitofMeasurement UOM { get; set; }
        public Status Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
