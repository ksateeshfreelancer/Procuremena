﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using CLB.Enums.Database;
using System;
using System.Collections.Generic;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class User
    {
        public int UserID { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Password { get; set; }
        public DateTime PasswordChangedDate { get; set; }
        public bool IsNewPassword { get; set; }
        public int InvalidLoginAttempts { get; set; }        
        public UserDetails UserDetails { get; set; }
        public Role Role { get; set; }
        public Status Status { get; set; }        
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

}
