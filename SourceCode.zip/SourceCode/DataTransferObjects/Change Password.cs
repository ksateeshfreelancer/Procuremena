﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class ChangePassword
    {
        public int UserID { get; set; }
        public string Email { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
    }
}
