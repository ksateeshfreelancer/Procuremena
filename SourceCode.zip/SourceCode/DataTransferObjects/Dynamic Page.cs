﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
#endregion

namespace CLB.DTO
{
    [Serializable]
    public class DynamicPage
    {
        public int DynamicPageID { get; set; }
        public string PageName { get; set; }
        public string PageContent { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
