﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 11-Mar-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
#endregion

namespace CLB.DTO
{   
    [Serializable]
    public class Enquiry
    {
        public long EnquiryID { get; set; }
        public User User { get; set; }
        /// <summary>
        /// Max length 20
        /// </summary>
        public string EnquiryLabel { get; set; }
        public EnquiryStatus EnquiryStatus { get; set; }        
        public bool IsGeneralEnquiry { get; set; }
        public bool IsMultiProduct { get; set; }
        /// <summary>
        /// If user has entered a new product Product value will be null. and new product name will be stored in productname property.
        /// Once admin approves enquiry, then if product is not matching with any of the existing values, new record will be craeted and product id is updated
        /// </summary>
       // public ProductCatalog Product { get; set; }
         public long ProductID { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string ProductName { get; set; }
        public double Quantity { get; set; }
        public UnitofMeasurement UOM { get; set; }
        /// <summary>
        /// Max length 1000
        /// </summary>
        public string ProductSpecification { get; set; }
        /// <summary>
        /// Max length 100        
        /// </summary>
        public string DeliveryLocation { get; set; }        
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class EnquiryLog
    {
        public long EnquiryLogID { get; set; }
        public long EnquiryID { get; set; }        
        /// <summary>
        /// Property not defined in table. Used for UI flexibility
        /// </summary>
        [XmlIgnore]
        public Enquiry Enquiry { get; set; }
        public User User { get; set; }
        public long QuotationID { get; set; }
        public bool IsParent { get; set; }
        public bool IsRead { get; set; }
        public double UnitCost { get; set; }
        public double Discount { get; set; }
        public double TotalCost { get; set; }
        /// <summary>
        /// Max length 20
        /// </summary>
        public string DeliveryPeriod { get; set; }
        /// <summary>
        /// Max length 100
        /// </summary>
        public string Attachments { get; set; }
        /// <summary>
        /// Max length 1000
        /// </summary>
        public string PaymentTerms { get; set; }
        /// <summary>
        /// Max length 1000
        /// </summary>
        public string OtherDetails { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    [Serializable]
    public class EnquiryStatus
    {
        public int StatusID { get; set; }
        /// <summary>
        /// Max length 50
        /// </summary>
        public string StatusName { get; set; }
        /// <summary>
        /// Max length 200
        /// </summary>
        public string StatusDescription { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    [Serializable]
    public class Quotation
    {
        public long QuotationID { get; set; }
        public Enquiry Enquiry { get; set; }
        public int CustomerID { get; set; }        
        [XmlIgnore]
        public User Customer { get; set; }        
        [XmlIgnore]        
        public User Vendor { get; set; }
        public int VendorID { get; set; }        
        [XmlIgnore]
        public string VendorBusinessName { get; set; }
        [XmlIgnore]
        public string VendorLocation { get; set; }
        public EnquiryStatus EnquiryStatus { get; set; }
        [XmlIgnore]
        public double UnitCost { get; set; }
        [XmlIgnore]
        public double Discount { get; set; }
        [XmlIgnore]
        public double TotalCost { get; set; }
        [XmlIgnore]
        public string DeliveryPeriod { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
