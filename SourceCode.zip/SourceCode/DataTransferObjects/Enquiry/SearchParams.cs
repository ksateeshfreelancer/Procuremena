﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 11-Mar-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
#endregion

namespace CLB.DTO
{   
    public class SearchParams
    {   
        public string CategoryName { get; set; }
        public string SubCategoryName { get; set; }
        public string ProductName { get; set; }
        public string CityName { get; set; }
        public long VendorInventoryID { get; set; }
    }
}
