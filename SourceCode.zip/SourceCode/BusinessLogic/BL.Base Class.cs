﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 21-May-2014
 *  Version          : 1.0
 */
#endregion

#region Imports

using CLB.DP;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
//using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Caching;
//using System.Web.Http;
using System.Xml;
using System.Xml.Linq;

#endregion

namespace CLB.BL
{
    /// <summary>
    /// BLBaseClass Class is responsible for pass queries to provider and retrieve resultsets
    /// </summary>
    public class BLBaseClass
    {
        #region Variables

        protected int _identity;
        public const string dbType = "MSSQL";
        protected Utilities _ = new Utilities();
        protected DataSet _dataSet;
        protected DataTable _dataTable;
        protected Object[,] _par;
        protected DbMessage _dbMessage;
        protected DataProviderFacade _provider;

        #endregion

        #region Public Properties

        public string CurrentUserID
        {
            get
            {
                return Utilities.Decrypt(HttpContext.Current.Session[SessionVariables.UserId]);
            }
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Method to delete data from database with dynamic table and columns information
        /// </summary>
        protected void DeleteData(object[,] par, string storedProcedure = null)
        {
            InitializeDataProvider();
            _provider.ExecuteNonQuery(storedProcedure ?? StoredProcedures.SpDeleteData, par, CommandType.StoredProcedure);
        }

        /// <summary>
        /// Convert all datetime properties to custom format
        /// </summary>
        protected string FormatDate(object date)
        {
            return DateTime.Parse(date.ToString()).ToString("dd MMM yyyy, hh:mm tt");
        }
        
        /// <summary>
        /// Generic method to check if columnname exists in resultset/datatable, validate, and return DateTime value
        /// </summary>
        protected dynamic GetDateTimeValue(DataTable dataTable, DataRow dataRow, string columnName, bool isNullable = false)
        {
            if (dataTable.Columns.Contains(columnName) == false || dataRow[columnName] == DBNull.Value ||
                dataRow[columnName].ToString().Trim() == string.Empty)
                return (isNullable ? (DateTime?)null : new DateTime());
            return DateTime.Parse(dataRow[columnName].ToString());
        }

        /// <summary>
        /// Generic method to check if columnname exists in resultset/datatable, validate, and return string value
        /// </summary>
        protected string GetStringValue(DataTable dataTable, DataRow dataRow, string columnName)
        {
            //',' occurences are replaced with '^' while storing data to database.
            //so '^' should be replaced with ',' while retrieving
            return (dataTable.Columns.Contains(columnName) == false)
                       ? null
                       : dataRow[columnName].ToString().Trim().Replace('^', ',').Replace("`", "'");
        }

        /// <summary>
        /// Generic method to check if columnname exists in resultset/datatable, validate, and return integer value
        /// </summary>
        protected dynamic GetIntegerValue(DataTable dataTable, DataRow dataRow, string columnName, bool isNullable = false)
        {
            if (dataTable.Columns.Contains(columnName) == false || dataRow[columnName] == DBNull.Value ||
                        dataRow[columnName].ToString().Trim() == string.Empty)
                return (isNullable ? (int?)null : 0);

            if (dataRow[columnName].GetType() == typeof(Int64))
                return Int64.Parse(dataRow[columnName].ToString());
            else
                return int.Parse(dataRow[columnName].ToString());
        }

        /// <summary>
        /// Generic method to check if columnname exists in resultset/datatable, validate, and return double value
        /// </summary>
        protected double GetDoubleValue(DataTable dataTable, DataRow dataRow, string columnName)
        {
            return (dataTable.Columns.Contains(columnName) == false || dataRow[columnName] == DBNull.Value ||
                    dataRow[columnName].ToString().Trim() == string.Empty)
                       ? 0.0
                       : double.Parse(dataRow[columnName].ToString());
        }

        /// <summary>
        /// Generic method to check if columnname exists in resultset/datatable, validate, and return boolean value
        /// </summary>
        protected dynamic GetBooleanValue(DataTable dataTable, DataRow dataRow, string columnName, bool isNullable = false)
        {
            if (dataTable.Columns.Contains(columnName) == false || dataRow[columnName] == DBNull.Value ||
                        string.IsNullOrEmpty(dataRow[columnName].ToString().Trim()))
                return (isNullable ? (bool?)null : false);

            return bool.Parse(dataRow[columnName].ToString());
        }

        /// <summary>
        /// Generic method to check if columnname exists in resultset/datatable, validate, and return enum value
        /// </summary>
        protected dynamic GetEnumValue<T>(DataTable dataTable, DataRow dataRow, string columnName)
        {
            if (dataTable.Columns.Contains(columnName) && dataRow[columnName] != DBNull.Value &&
                dataRow[columnName].ToString().Trim() != string.Empty)
            {
                object value = null;
                if (dataRow[columnName] is byte)
                    value = (byte)dataRow[columnName];
                else if (dataRow[columnName] is int)
                    value = int.Parse(dataRow[columnName].ToString());
                else if (dataRow[columnName] is bool)
                    value = (bool)dataRow[columnName] ? 1 : 0;

                if (Enum.GetNames(typeof(T)).Any(x => x == dataRow[columnName].ToString()))
                    return Enum.Parse(typeof(T), dataRow[columnName].ToString());

                if (value != null && Enum.IsDefined(typeof(T), int.Parse(value.ToString())))
                    return Enum.Parse(typeof(T), value.ToString());
            }
            //set default value of datatable doesnot contain column
            return Enum.GetValues(typeof(T)).GetValue(0);
        }

        protected string GetSqlDate(DateTime? date)
        {
            return (date.HasValue && date.Value.Year > 1900) ? date.Value.ToString(DbConstants.DateFormat) : null;
        }

        /// <summary>
        /// Method to get user details 
        /// </summary>
        protected User MapUserDetails(DataTable dataTable, DataRow dataRow, List<Screen> screens = null)
        {
            //var cities = DataConstants.LoadCities();            
            return new User
            {
                UserID = GetIntegerValue(dataTable, dataRow, "UserID"),
                Email = GetStringValue(dataTable, dataRow, "Email"),
                Mobile = GetStringValue(dataTable, dataRow, "Mobile"),
                Password = GetStringValue(dataTable, dataRow, "Password"),
                PasswordChangedDate = GetDateTimeValue(dataTable, dataRow, "PasswordChangedDate"),
                IsNewPassword = GetBooleanValue(dataTable, dataRow, "IsNewPassword"),
                InvalidLoginAttempts = GetIntegerValue(dataTable, dataRow, "InvalidLoginAttempts"),
                Role = new DTO.Role
                {
                    RoleID = GetIntegerValue(dataTable, dataRow, "RoleID"),
                    RoleName = GetStringValue(dataTable, dataRow, "RoleName"),
                    Level = GetIntegerValue(dataTable, dataRow, "Level"),
                    Screens = screens
                },
                UserDetails = new UserDetails
                {
                    UserID = GetIntegerValue(dataTable, dataRow, "UserID"),
                    FirstName = GetStringValue(dataTable, dataRow, "FirstName"),
                    LastName = GetStringValue(dataTable, dataRow, "LastName"),
                    DOB = GetDateTimeValue(dataTable, dataRow, "DOB"),
                    Gender = GetEnumValue<Enums.Gender>(dataTable, dataRow, "Gender"),
                    Country = new Country
                    {
                        CountryID= GetIntegerValue(dataTable, dataRow, "CountryID"),
                        CountryName= GetStringValue(dataTable, dataRow, "CountryName")
                    },
                    RegisteredIP = GetStringValue(dataTable, dataRow, "RegisteredIP")                    
                },
                Status = GetEnumValue<Enums.Status>(dataTable, dataRow, "Status"),
                CreatedBy = GetStringValue(dataTable, dataRow, "CreatedBy1"),
                CreatedDate = GetDateTimeValue(dataTable, dataRow, "CreatedDate"),
                ModifiedBy = GetStringValue(dataTable, dataRow, "ModifiedBy1"),
                ModifiedDate = GetDateTimeValue(dataTable, dataRow, "ModifiedDate")
            };
        }

        /// <summary>
        /// Method to save data to database with dynamic table and columns information
        /// </summary>
        protected object SaveData(object[,] par)
        {
            InitializeDataProvider();
            return _provider.ExecuteScalar(StoredProcedures.SpInsertData, par, CommandType.StoredProcedure);
        }

        /// <summary>
        /// Method to update data to database with dynamic table and columns information
        /// </summary>
        protected void UpdateData(object[,] par)
        {
            InitializeDataProvider();
            _provider.ExecuteNonQuery(StoredProcedures.SpUpdateData, par, CommandType.StoredProcedure);
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Build dynamic sql queries based on entities passed
        /// </summary>
        public void BuildDynamicQuery(object entity, StringBuilder sbColumnNames, StringBuilder sbColumnValues,
                                      string[] propertiesToSkip, bool isInsert, int userId = 0, bool includeAuditColumns = true)
        {
            //skip these properties even if they are passed >> CreatedBy, CreatedDate, ModifiedBy, ModifiedDate
            if (propertiesToSkip != null && includeAuditColumns)
            {
                Array.Resize(ref propertiesToSkip, propertiesToSkip.Length + 4);
                propertiesToSkip[propertiesToSkip.Length - 4] = "CreatedBy";
                propertiesToSkip[propertiesToSkip.Length - 3] = "CreatedDate";
                propertiesToSkip[propertiesToSkip.Length - 2] = "ModifiedBy";
                propertiesToSkip[propertiesToSkip.Length - 1] = "ModifiedDate";
            }

            var properties =
                entity.GetType()
                      .GetProperties()
                      .Where(
                          propertyInfo =>
                          propertiesToSkip == null ||
                          !Array.ConvertAll(propertiesToSkip, s => s.ToLower()).Contains(propertyInfo.Name.ToLower()))
                      .ToList();
            foreach (var propertyInfo in properties)
            {
                sbColumnNames.Append((sbColumnNames.Length != 0) ? "," : string.Empty);
                sbColumnValues.Append((sbColumnValues.Length != 0) ? "," : string.Empty);

                sbColumnNames.Append("[" + propertyInfo.Name + "]");

                //check if property value is set to null
                if (propertyInfo.GetValue(entity, null) == null)
                {
                    sbColumnValues.Append("null");
                }
                else
                {
                    if (propertyInfo.PropertyType.BaseType == typeof(Enum))
                        sbColumnValues.Append("'" + (int)propertyInfo.GetValue(entity, null) + "'");
                    else
                    {
                        if (propertyInfo.PropertyType == typeof(IList))
                        {

                        }
                        if (propertyInfo.PropertyType == typeof(DateTime))
                        {
                            sbColumnValues.Append("'" + DateTime.Parse(propertyInfo.GetValue(entity, null).ToString()).ToString("yyyy-MM-dd HH:mm:ss") + "'");
                        }
                        //check if property is nullable property and is of type enum
                        else if (propertyInfo.PropertyType.Name == "Nullable`1")
                        {
                            if (propertyInfo.GetValue(entity, null).GetType().BaseType == typeof(Enum))
                                sbColumnValues.Append("'" + (int)propertyInfo.GetValue(entity, null) + "'");
                            else if (propertyInfo.GetValue(entity, null).GetType() == typeof(DateTime))
                                sbColumnValues.Append("'" + DateTime.Parse(propertyInfo.GetValue(entity, null).ToString()).ToString("yyyy-MM-dd HH:mm:ss") + "'");
                            else
                                sbColumnValues.Append("'" + propertyInfo.GetValue(entity, null) + "'");
                        }
                        else if (propertyInfo.PropertyType.Name == "Boolean")
                        {
                            sbColumnValues.Append("'" + Convert.ToInt16(propertyInfo.GetValue(entity, null)) + "'");
                        }
                        else if (propertyInfo.PropertyType.Name == "List`1")
                        {
                            var items = (IList)propertyInfo.GetValue(entity, null);

                            var csvalues = string.Empty;
                            if (items != null)
                            {
                                foreach (var item in items)
                                {
                                    csvalues += (csvalues == string.Empty ? string.Empty : "~");
                                    csvalues += (int)item;
                                }
                            }

                            sbColumnValues.Append("'" + csvalues + "'");
                        }
                        else
                        {
                            //replace ',' occurences with '^' and ''' occurences with '`' 
                            sbColumnValues.Append("'" +
                                                  propertyInfo.GetValue(entity, null)
                                                      .ToString().Trim()
                                                      .Replace(',', '^')
                                                      .Replace("'", "`") +
                                                  "'");
                        }
                    }
                }

                if (propertyInfo == properties.Last() && includeAuditColumns)
                {
                    //if userid is explicitly passed as parameter assign userid to user
                    var user = userId;

                    //session is null when request is from webapi
                    if (HttpContext.Current != null && HttpContext.Current.Session != null &&
                        HttpContext.Current.Session[SessionVariables.UserId] != null && user == 0)
                        int.TryParse(Utilities.Decrypt(HttpContext.Current.Session[SessionVariables.UserId].ToString()), out user);

                    sbColumnNames.Append((isInsert ? ",[CreatedBy],[CreatedDate]" : string.Empty) +
                                         ",[ModifiedBy],[ModifiedDate]");
                    sbColumnValues.Append((isInsert ? ("," + user + ",GETDATE()") : string.Empty) +
                                          "," + user + ",GETDATE()");
                }
            }
        }

        /// <summary>
        /// Build dynamic xml string from dto to store booking details in booking tables and return XML string
        /// </summary>
        public string BuildDynamicXml(object entity, string[] propertiesToSkip = null)
        {
            try
            {
                if (entity == null) return string.Empty;

                if (entity.GetType().Name == "List`1" || entity.GetType().BaseType == typeof(Array))
                {
                    var list = entity.GetType().Name == "List`1" ? entity as IList : entity as Array;
                    if (list != null)
                    {
                        var xElementsArray = (from object item in list
                                              let xElements =
                                                  item.GetType()
                                                      .GetProperties()
                                                      .Where(
                                                          propertyInfo =>
                                                          propertiesToSkip == null ||
                                                          !propertiesToSkip.Contains(propertyInfo.Name))
                                                      .Select(
                                                          propertyInfo =>
                                                          new XElement(propertyInfo.Name,
                                                                       propertyInfo.GetValue(item, null)))
                                                      .ToList()
                                              select new XElement(item.GetType().Name, xElements)).ToList();

                        var rootElementName = entity.GetType().FullName;
                        if (rootElementName.Split(',').Length > 0)
                        {
                            rootElementName = rootElementName.Split(',')[0];
                            rootElementName = rootElementName.Replace("System.Collections.Generic.", string.Empty);
                        }
                        rootElementName = Utilities.RemoveSpecialCharacters(rootElementName, new[] { "`", "]", "[" });

                        var myXml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"),
                                                  new XElement(rootElementName, xElementsArray));
                        return myXml.ToString();
                    }
                }
                else
                {
                    var xElements =
                        entity.GetType()
                              .GetProperties()
                              .Where(
                                  propertyInfo =>
                                  propertiesToSkip == null || !propertiesToSkip.Contains(propertyInfo.Name))
                              .Select(
                                  propertyInfo => new XElement(propertyInfo.Name, propertyInfo.GetValue(entity, null)))
                              .ToList();
                    var myXml = new XDocument(
                        new XDeclaration("1.0", "utf-8", "yes"),
                        new XElement(entity.GetType().Name, xElements));
                    return myXml.ToString();
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return string.Empty;
        }

        /// <summary>
        /// Method to delete data from database with dynamic table and columns information
        /// </summary>
        public DbMessage Delete(Tables table, string columnName = null, string columnValue = null)
        {
            try
            {
                _par = new object[,]
                {
                    {"@TableName", table.ToString(), null}
                    , {"@ColumnName", columnName, null}
                    , {"@ColumnValue", columnValue, null}
                    , {"@OutMessage", null, "Out"}
                };
                DeleteData(_par);
                return (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
            }
            catch (Exception ex)
            {
                LogException(ex);
                return DbMessage.Failed;
            }
        }

        /// <summary>
        /// Method to get required fields/columns from table based on input filters
        /// </summary>
        /// <param name="table"></param>
        /// <param name="filterColumnNames">Comma seperated column names to filter</param>
        /// <param name="filterColumnValues">Comma seperated column values</param>
        /// <param name="columnsToRetrieve">Comma seperated column names to retrieve</param>
        /// <returns></returns>
        public DataTable GetData(Tables table, string filterColumnNames, string filterColumnValues, string columnsToRetrieve = null)
        {
            _par = new Object[,]
                {
                    {"@TableName", table.ToString(), null}
                    , {"@ColumnNames", filterColumnNames, null}
                    , {"@ColumnValues", filterColumnValues, null}
                    , {"@ColumnsToRetrieve", columnsToRetrieve, null}
                    , {"@OutMessage", null, "Out"}
                };
            return GetDataTable(_par);
        }

        /// <summary>
        /// Method to get data form multiple tables based on transaction type
        /// </summary>
        public DataTable GetDataFromMultipleTables(object[,] par)
        {
            InitializeDataProvider();
            return _provider.ExecuteDataTable(StoredProcedures.SpGetDataFromMultipleTables, par, CommandType.StoredProcedure);
        }

        /// <summary>
        /// Method to get data from database with dynamic dataset and columns information
        /// </summary>
        public DataSet GetDataSet(object[,] par, string storedProcedure = null)
        {
            InitializeDataProvider();
            return _provider.ExecuteDataSet(storedProcedure ?? StoredProcedures.SpGetData, par, CommandType.StoredProcedure);
        }

        /// <summary>
        /// Method to get data from database with dynamic table and columns information
        /// </summary>
        public DataTable GetDataTable(object[,] par, string storedProcedure = null)
        {
            InitializeDataProvider();
            return _provider.ExecuteDataTable(storedProcedure ?? StoredProcedures.SpGetData, par, CommandType.StoredProcedure);
        }

        public string GetOutputMessage(Object[,] par)
        {
            var outMsg = string.Empty;
            for (var i = 0; i < par.GetLength(0); i++)
            {
                if (par[i, 2] != null)
                {
                    outMsg = par[i, 1].ToString();
                }
            }
            return outMsg;
        }

        /// <summary>
        /// Generic method to insert multiple rows with dynamic table name, columnnames and columnvalues 
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="columnNamesArray"></param>
        /// <param name="columnValuesArray"></param>
        /// <returns>DbMessage</returns>
        public DbMessage InsertMultipleRows(string tableName, string columnNamesArray, string columnValuesArray)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", tableName, null}
                    , {"@ColumnNamesArray", columnNamesArray, null}
                    , {"@ColumnValuesArray", columnValuesArray, null}
                    , {"@OutMessage", null, "Out"}        
                    };
                InitializeDataProvider();
                _provider.ExecuteNonQuery(StoredProcedures.SpInsertMultipleRows, _par, CommandType.StoredProcedure);
                return (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
            }
            catch (Exception ex)
            {
                LogException(ex);
                return DbMessage.Failed;
            }
        }

        /// <summary>
        /// Method to log exception details to database
        /// </summary>
        public void LogException(Exception ex)
        {
            try
            {
                if (!bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
                {
                    var pagePath = HttpContext.Current != null
                                       ? HttpContext.Current.Request.FilePath
                                       : HttpRuntime.AppDomainAppPath;

                    var par = new object[,]
                    {
                        {"@Page", pagePath, null},
                        {"@Method", ex.TargetSite.ToString(), null},
                        {"@ErrorMessage", ex.Message, null},
                        {"@DetailedMessage", ex.StackTrace.Length > 3999 ? ex.StackTrace.Substring(0, 3999) : ex.StackTrace, null},
                        {
                            "@IPAddress", Utilities.IPAddress, null
                        },
                        {
                            "@UserID", (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session[SessionVariables.CurrentUser] == null)
                                ? null //indicates request is from webapi or a whitelabel guest
                                : ((User) HttpContext.Current.Session[SessionVariables.CurrentUser]).UserID
                                    .ToString()
                            ,
                            null
                        }
                    };

                    _provider = new DataProviderFacade(dbType, ConnectionStrings.ConnectionString);
                    _provider.ExecuteNonQuery(StoredProcedures.SpSaveErrorLog, par, CommandType.StoredProcedure);
                }
            }
            catch (Exception)
            {
                /*
                Utilities.SendEmail(ConfigurationManager.AppSettings["SupportEmail"], "Failed to log exception",
                                    "Exception details: <br/><br/><br/><b>Message</b><br/>" + ex.Message +
                                    "<br/><br/><b>Stack Trace</b><br/><br/>" + ex.StackTrace +
                                    "<br/><br/><b>Method</b><br/><br/>" + ex.TargetSite +
                                    " <br/><br/> Regards,<br/>Support Team.");
                 * */
            }
        }

        /// <summary>
        /// Method to log exception details to database with userdefined log information
        /// </summary>
        public void LogException(string method, string errormessage, string detailedmessage, string userid = null, string page = null)
        {
            try
            {
                if (!bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
                {
                    var pagePath = HttpContext.Current != null
                                       ? HttpContext.Current.Request.FilePath
                                       : HttpRuntime.AppDomainAppPath;

                    var par = new object[,]
                        {
                            {"@Page", string.IsNullOrEmpty(page) ? pagePath : page, null},
                            {"@Method", method, null},
                            {"@ErrorMessage", errormessage, null},
                            {
                                "@DetailedMessage",
                                detailedmessage.Length > 3999 ? detailedmessage.Substring(0, 3999) : detailedmessage,
                                null
                            },
                            {
                                "@IPAddress", Utilities.IPAddress, null
                            },
                            {
                                "@UserID", (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session[SessionVariables.CurrentUser] == null)
                                               ? userid //indicates request is from webapi or a whitelabel guest
                                               : ((User) HttpContext.Current.Session[SessionVariables.CurrentUser])
                                                     .UserID
                                                     .ToString()
                                , null
                            }
                        };

                    InitializeDataProvider();
                    _provider.ExecuteNonQuery(StoredProcedures.SpSaveErrorLog, par, CommandType.StoredProcedure);
                }
            }
            catch (Exception)
            {
                //if (!errormessage.ToUpper().Contains("THREAD WAS BEING ABORTED"))
                //    Utilities.SendEmail(ConfigurationManager.AppSettings["SupportEmail"], "Failed to log exception",
                //                        "Exception details: <br/><br/><br/><b>Message</b><br/>" + errormessage +
                //                        "<br/><br/><b>Stack Trace</b><br/><br/>" + detailedmessage +
                //                        "<br/><br/><b>Method</b><br/><br/>" + method +
                //                        " <br/><br/> Regards,<br/>Support Team.");
            }
        }

        /// <summary>
        /// Generic method to insert or update details to database with dynamic table and columns information
        /// </summary>
        protected DbMessage Save_Update(Object obj, Tables tablename, string[] propertiestoSkip, out bool status, out int identity, string uniqueColumns = null,
            string filterColumnName = null, string filterColumnValue = null, bool includeAuditColumns = true)
        {
            try
            {
                var sbColumnNames = new StringBuilder();
                var sbColumnValues = new StringBuilder();

                //update entity
                if (filterColumnName != null && filterColumnValue != null)
                {
                    BuildDynamicQuery(obj, sbColumnNames, sbColumnValues, propertiestoSkip, false, 0, includeAuditColumns);
                    _par = new object[,]
                    {
                      {"@TableName", tablename.ToString(), null}
                    , {"@ColumnNames", sbColumnNames.ToString(), null}
                    , {"@ColumnValues", sbColumnValues.ToString(), null}
                    , {"@UniqueColumns", uniqueColumns, null}
                    , {"@FilterColumnName", filterColumnName, null}
                    , {"@FilterColumnValue", filterColumnValue, null}                    
                    , {"@OutMessage", null, "Out"}        
                    };
                    UpdateData(_par);

                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    identity = 0;
                    status = (_dbMessage == DbMessage.Success);
                    return _dbMessage;
                }
                //insert entity
                BuildDynamicQuery(obj, sbColumnNames, sbColumnValues, propertiestoSkip, true, 0, includeAuditColumns);
                _par = new object[,]
                    {
                        {"@Identity", null, "Out"}
                        , {"@TableName", tablename.ToString(), null}
                        , {"@ColumnNames", sbColumnNames.ToString(), null}
                        , {"@ColumnValues", sbColumnValues.ToString(), null}
                        , {"@UniqueColumns", uniqueColumns, null}
                        , {"@OutMessage", null, "Out"}        
                    };
                var result = SaveData(_par);
                identity = int.Parse(_par[0, 1].ToString());
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Success);
                return _dbMessage;
            }
            catch (Exception ex)
            {
                identity = 0;
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbMessage.Failed;
            }
        }

        /// <summary>
        /// Method to update specific field to database with dynamic table and columns information
        /// </summary>
        public DbMessage UpdateField(Tables tableName, string columnName, string columnValue, string filterColumnName,
                                     string filterColumnValue)
        {
            try
            {
                _par = new object[,]
                    {
                        {"@TableName", tableName.ToString(), null}
                        , {"@ColumnName", columnName, null}
                        , {"@ColumnValue", columnValue, null}
                        , {"@FilterColumnName", filterColumnName, null}
                        , {"@FilterColumnValue", filterColumnValue, null}
                        , {"@OutMessage", null, "Out"}
                    };

                InitializeDataProvider();
                _provider.ExecuteNonQuery(StoredProcedures.SpUpdateField, _par, CommandType.StoredProcedure);
                return (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
            }
            catch (Exception ex)
            {
                LogException(ex);
                return DbMessage.Failed;
            }
        }

        /// <summary>
        /// Generic method to 
        /// UPDATE SINGLE ROW SINGLE COLUMN 
        /// UPDATE MULTIPLE ROWS SINGLE COLUMN 
        /// UPDATE SINGLE ROW MULTIPLE COLUMNS 
        /// UPDATE MULTIPLE ROWS MULTIPLE COLUMNS 
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="columnNames"></param>
        /// <param name="columnValuesArray"></param>
        /// <param name="filterColumnName"></param>
        /// <param name="filterColumnValues"></param>
        /// <param name="nameToBeDisplayed"></param>
        /// <returns></returns>
        public DbMessage UpdateMultipleRows(string tableName, string columnNames, string columnValuesArray, string filterColumnName, string filterColumnValues)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", tableName, null}
                    , {"@ColumnNames", columnNames, null}
                    , {"@ColumnValuesArray", columnValuesArray, null}
                    , {"@FilterColumnName", filterColumnName, null}
                    , {"@FilterColumnValues", filterColumnValues, null}                    
                    , {"@OutMessage", null, "Out"}        
                    };
                InitializeDataProvider();
                _provider.ExecuteNonQuery(StoredProcedures.SpUpdateMultipleRows, _par, CommandType.StoredProcedure);
                return (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
            }
            catch (Exception ex)
            {
                LogException(ex);
                return DbMessage.Failed;
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Method to get XmlElement Value
        /// </summary>
        private string GetElementValue(XmlElement element, string tagName)
        {
            return (element.GetElementsByTagName(tagName)[0] != null)
                ? element.GetElementsByTagName(tagName)[0].InnerText
                : "";
        }

        /// <summary>
        /// Method to initialize dataprovider and connect to TPA/TPC database based on parameters
        /// </summary>
        private void InitializeDataProvider()
        {
            _provider = new DataProviderFacade(dbType, ConnectionStrings.ConnectionString);
        }
        /*
        private PaymentInfo GetPaymentInfo(DataTable table, DataRow row)
        {
            var paymentInfo = new PaymentInfo();
            try
            {
                var response = GetStringValue(table, row, "ResponseString");
                if (response.Contains("&"))
                {
                    var responseFields = response.Split('&');
                    paymentInfo.PaymentId = responseFields[3].Contains("PaymentID=")
                                                ? responseFields[3].Split('=')[1]
                                                : "";
                    paymentInfo.ResponseCode = responseFields[0].Contains("ResponseCode=")
                                                   ? responseFields[0].Split('=')[1]
                                                   : "";
                    paymentInfo.ResponseMessage = responseFields[1].Contains("ResponseMessage=")
                                                      ? responseFields[1].Split('=')[1]
                                                      : "";
                    paymentInfo.MerchtRefNumber = responseFields[4].Contains("MerchantRefNo=")
                                                      ? responseFields[4].Split('=')[1]
                                                      : "";
                    paymentInfo.Amount = responseFields[5].Contains("Amount=") ? responseFields[5].Split('=')[1] : "";
                    paymentInfo.Mode = responseFields[6].Contains("Mode=") ? responseFields[6].Split('=')[1] : "";
                    paymentInfo.TransactionId = responseFields[24].Contains("TransactionID=")
                                                    ? responseFields[24].Split('=')[1]
                                                    : "";
                    paymentInfo.PaymentMethod = responseFields[25].Contains("PaymentMethod=")
                                                    ? responseFields[25].Split('=')[1]
                                                    : "";
                    paymentInfo.PaymentStatus = !string.IsNullOrEmpty(GetStringValue(table, row, "PaymentStatus"))
                                                    ? GetEnumValue<PaymentStatus>(table, row, "PaymentStatus")
                                                    : PaymentStatus.Pending;
                }

            }
            catch (Exception)
            {

            }
            return paymentInfo;
        }
        */
        #endregion
    }
}

