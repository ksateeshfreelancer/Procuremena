﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;

#endregion

namespace CLB.BL
{
    public class ReportManager : BLBaseClass
    {   
        
    }
}