﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL.Administration
{
    public class CountryManager : BLBaseClass
    {   
        /// <summary>
        /// Save multiple Countries
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveCountries(List<Country> countries, out bool status)
        {
            try
            {
                status = true;
                if (countries == null || countries.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnNamesArray = "CountryName,Status,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate";
                var columnValuesArray = countries.Aggregate(string.Empty,
                            (current, country) =>
                            current +
                            ("'" + country.CountryName.Replace(',', '^').Replace("'", "`") +
                            "','" + (int)country.Status +
                            "','" + CurrentUserID +
                            "',GETDATE()" +
                            ",'" + CurrentUserID +
                            "',GETDATE()~"));
                return
                    DbConstants.OutMessage(InsertMultipleRows(Tables.Country.ToString(), columnNamesArray, columnValuesArray.TrimEnd('~')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Update countries
        /// </summary>        
        /// <returns>message to display</returns>
        public string UpdateCountries(List<Country> countries, out bool status)
        {
            try
            {
                status = true;
                if (countries == null || countries.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnValuesArray = countries.Aggregate(string.Empty,
                            (current, country) => current + ("'" + country.CountryName.Replace(',', '^').Replace("'", "`") +                                                        
                                                        "','" + (int)country.Status +
                                                        "','" + CurrentUserID +
                                                        "',GETDATE()~"));
                var filterColumnValuesArray = countries.Aggregate(string.Empty,
                            (current, country) => current + ("'" + country.CountryID + "',"));

                return DbConstants.OutMessage(UpdateMultipleRows(Tables.Country.ToString(),
                    "CountryName,Status,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~'), "CountryID",
                    filterColumnValuesArray.TrimEnd(',')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Delete country by country id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteCountry(int countryID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.Country.ToString(), null}
                    , {"@ColumnName", "CountryID", null}
                    , {"@ColumnValue", countryID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Country");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "Country", "Other data");
            }
        }

        /// <summary>
        /// Get the list of Country
        /// </summary>        
        /// <returns>list of Countries</returns>
        public List<Country> GetCountries()
        {
            var countries = new List<Country>();
            try
            {
                _dataTable = GetData(Tables.Country, null, null);
                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    countries.AddRange(from DataRow dataRow in _dataTable.Rows                                        
                                         select new Country
                                         {
                                             CountryID = GetIntegerValue(_dataTable, dataRow, "CountryID"),
                                             CountryName = GetStringValue(_dataTable, dataRow, "CountryName"),
                                             Status = GetEnumValue<Status>(_dataTable, dataRow, "Status"),
                                             CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy1"),
                                             CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                             ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy1"),
                                             ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                         });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return countries;
        }
    }
}