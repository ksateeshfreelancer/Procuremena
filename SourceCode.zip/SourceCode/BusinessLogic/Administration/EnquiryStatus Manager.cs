﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL
{
    public class EnquiryStatusManager : BLBaseClass
    {
        /// <summary>
        /// Save or update Enquiry Status detials
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveEnquiryStatus(EnquiryStatus enquiryStatus, out bool status)
        {
            _dbMessage = Save_Update(enquiryStatus, Tables.EnquiryStatus, new[] { "StatusID" }, out status,
               out _identity, "StatusName", enquiryStatus.StatusID > 0 ? "StatusID" : null, enquiryStatus.StatusID > 0 ? enquiryStatus.StatusID.ToString() : null);
            return DbConstants.OutMessage(_dbMessage, "Enquiry Status");
        }

        /// <summary>
        /// Save multiple Enquiry Statuses
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveEnquiryStatuses(List<EnquiryStatus> enquiryStatuses, out bool status)
        {
            try
            {
                status = true;
                if (enquiryStatuses == null || enquiryStatuses.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnNamesArray = "StatusName,StatusDescription,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate";
                var columnValuesArray = enquiryStatuses.Aggregate(string.Empty,
                            (current, enquiry) =>
                            current +
                            ("'" + enquiry.StatusName.Replace(',', '^').Replace("'", "`") +
                            "','" + enquiry.StatusDescription.Replace(',', '^').Replace("'", "`") +                            
                            "','" + CurrentUserID +
                            "',GETDATE()" +
                            ",'" + CurrentUserID +
                            "',GETDATE()~"));
                return
                    DbConstants.OutMessage(InsertMultipleRows(Tables.EnquiryStatus.ToString(), columnNamesArray, columnValuesArray.TrimEnd('~')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Update Enquiry Statuses
        /// </summary>        
        /// <returns>message to display</returns>
        public string UpdateEnquiryStatuses(List<EnquiryStatus> enquiryStatuses, out bool status)
        {
            try
            {
                status = true;
                if (enquiryStatuses == null || enquiryStatuses.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnValuesArray = enquiryStatuses.Aggregate(string.Empty,
                            (current, enquiry) => current + ("'" + enquiry.StatusName.Replace(',', '^').Replace("'", "`") +
                                                        "','" + enquiry.StatusDescription.Replace(',', '^').Replace("'", "`") +
                                                        "','" + CurrentUserID +
                                                        "',GETDATE()~"));
                var filterColumnValuesArray = enquiryStatuses.Aggregate(string.Empty,
                            (current, enquiry) => current + ("'" + enquiry.StatusID + "',"));

                return DbConstants.OutMessage(UpdateMultipleRows(Tables.EnquiryStatus.ToString(),
                    "StatusName,StatusDescription,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~'), "StatusID",
                    filterColumnValuesArray.TrimEnd(',')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Delete enquiry status by status id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteEnquiryStatus(int statusID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.EnquiryStatus.ToString(), null}
                    , {"@ColumnName", "StatusID", null}
                    , {"@ColumnValue", statusID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Enquiry Status");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "Enquiry Status", "Other data");
            }
        }

        /// <summary>
        /// Get the list of EnquiryStatuses 
        /// </summary>        
        /// <returns>list of EnquiryStatuses</returns>
        public List<EnquiryStatus> GetEnquiryStatuses()
        {
            var enquiryStatuses = new List<EnquiryStatus>();
            try
            {
                _dataTable = GetData(Tables.EnquiryStatus, null, null);
                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    enquiryStatuses.AddRange(from DataRow dataRow in _dataTable.Rows
                                         select new EnquiryStatus
                                         {
                                             StatusID = GetIntegerValue(_dataTable, dataRow, "StatusID"),
                                             StatusName = GetStringValue(_dataTable, dataRow, "StatusName"),
                                             StatusDescription = GetStringValue(_dataTable, dataRow, "StatusDescription"),
                                             CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy1"),
                                             CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                             ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy1"),
                                             ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                         });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return enquiryStatuses;
        }
    }
}