﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL
{
    public class QueryManager : BLBaseClass
    {
        /// <summary>
        /// Save or update query detials
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveQuery(Query query, out bool status)
        {
            try
            {
                var sbColumnNames = new StringBuilder();
                var sbColumnValues = new StringBuilder();
                var propertiestoSkip = new List<string>(new[] { "QueryID" });
                //insert query comments
                BuildDynamicQuery(query, sbColumnNames, sbColumnValues, propertiestoSkip.ToArray(), true, 0, false);
                _par = new object[,]
                    {
                        {"@TableName", Tables.EmailQueries.ToString(), null}
                        , {"@ColumnNames", sbColumnNames.ToString().Replace("User", "UserID"), null}
                        , {"@ColumnValues", sbColumnValues.ToString()
                                .Replace("CLB.DTO.User", query.User.UserID.ToString()), null}
                        , {"@UniqueColumns", null, null}
                        , {"@OutMessage", null, "Out"}
                    };

                SaveData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Sent, "Query");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Failed);
            }
        }
        public DbMessage MarkAsRead(long queryID)
        {
            return UpdateField(Tables.EmailQueries, "IsRead", "1", "QueryID", queryID.ToString());
        }
        public DbMessage MarkAsRead(IEnumerable<Query> queryLog)
        {
            try
            {
                if (queryLog == null || queryLog.Count() == 0)
                    return DbMessage.Success;

                var columnValuesArray = queryLog.Aggregate(string.Empty,
                            (current, enquiry) => current + "1~");

                var filterColumnValuesArray = queryLog.Aggregate(string.Empty,
                            (current, enquiry) => current + ("'" + enquiry.QueryID + "',"));

                return UpdateMultipleRows(Tables.EmailQueries.ToString(), "IsRead", columnValuesArray.TrimEnd('~'), "QueryID",
                    filterColumnValuesArray.TrimEnd(','));
            }
            catch (Exception ex)
            {
                LogException(ex);
                return DbMessage.Failed;
            }
        }
        /// <summary>
        /// Delete query by thread id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteQuery(long threadID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.EmailQueries.ToString(), null}
                    , {"@ColumnName", "ThreadID", null}
                    , {"@ColumnValue", threadID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Query");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "Query", "Other Data");
            }
        }
        /// <summary>
        /// Get the list of queries
        /// </summary>        
        /// <returns>list of Queries</returns>
        public List<Query> GetQueries(long? threadID = null, int? userID = null)
        {
            var queries = new List<Query>();
            try
            {
                _par = new Object[,]
                    {
                         {"@TxnType", Tables.EmailQueries.ToString(), null}
                        ,{"@ThreadID", threadID, null}
                        ,{"@UserID", userID, null}
                    };

                _dataTable = new DataTable();
                _dataTable = GetDataTable(_par, StoredProcedures.SpGetDataFromMultipleTables);

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    queries.AddRange(from DataRow dataRow in _dataTable.Rows
                                    where (!threadID.HasValue || threadID.Value == GetIntegerValue(_dataTable, dataRow, "ThreadID"))
                                       && (!userID.HasValue || userID.Value == GetIntegerValue(_dataTable, dataRow, "UserID"))
                                    select new Query
                                        {
                                            QueryID = GetIntegerValue(_dataTable, dataRow, "QueryID"),
                                            ThreadID = GetIntegerValue(_dataTable, dataRow, "ThreadID"),
                                            User = new User
                                            {
                                                UserID = GetIntegerValue(_dataTable, dataRow, "UserID"),
                                                UserDetails = new UserDetails
                                                {
                                                    FirstName = GetStringValue(_dataTable, dataRow, "FirstName"),
                                                    LastName = GetStringValue(_dataTable, dataRow, "LastName")
                                                }
                                            },
                                            QueryCategory = GetEnumValue<Enums.QueryCategory>(_dataTable, dataRow, "QueryCategory"),
                                            IsRead = GetBooleanValue(_dataTable, dataRow, "IsRead"),
                                            IsParent = GetBooleanValue(_dataTable, dataRow, "IsParent"),
                                            Subject = GetStringValue(_dataTable, dataRow, "Subject"),
                                            Body = GetStringValue(_dataTable, dataRow, "Body"),
                                            CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate")
                                        });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return queries;
        }
    }
}