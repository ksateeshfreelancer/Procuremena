﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;
using CLB.BL.Administration;

#endregion

namespace CLB.BL
{
    public class SubscriptionManager : BLBaseClass
    {
        string columnNamesArray = "PlanID,UserID,StartDate,EndDate,IsExpired";
        public string SaveSubscription(Subscription subscription, out bool status)
        {
            try
            {
                //update Subscription
                if (subscription.SubscriptionID > 0)
                {
                    _par = new object[,] 
                        {
                            {"@TableName", Tables.Subscription.ToString(), null}
                            , {"@ColumnNames", columnNamesArray + ",ModifiedBy,ModifiedDate", null}
                            , {"@ColumnValues", GetColumnValuesArray(subscription) + "','" + CurrentUserID +
                                            "',GETDATE()", null}
                            , {"@UniqueColumns", null, null}
                            , {"@FilterColumnName", "SubscriptionID", null}
                            , {"@FilterColumnValue", subscription.SubscriptionID, null}
                            , {"@OutMessage", null, "Out"}
                        };

                    UpdateData(_par);

                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    return DbConstants.OutMessage(_dbMessage, "Subscription");
                }
                //insert Subscription                
                _par = new object[,]
                    {
                        {"@Identity", null, "Out"}
                        , {"@TableName", Tables.Subscription.ToString(), null}
                        , {"@ColumnNames", columnNamesArray + ",CreatedBy,CreatedDate,ModifiedBy,ModifiedDate", null}
                        , {"@ColumnValues", GetColumnValuesArray(subscription) + "','" + CurrentUserID +
                                            "',GETDATE()" + ",'" + CurrentUserID +
                                            "',GETDATE()", null}
                        , {"@UniqueColumns", null, null}
                        , {"@OutMessage", null, "Out"}
                    };

                var result = SaveData(_par);
                //_identity = int.Parse(_par[0, 1].ToString());
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(_dbMessage, "Subscription");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Failed);
            }
        }         
        /// <summary>
        /// Delete subscription by subscription id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteSubscription(long subscriptionID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.Subscription.ToString(), null}
                    , {"@ColumnName", "SubscriptionID", null}
                    , {"@ColumnValue", subscriptionID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Subscription");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "Subscription", "Other Data");
            }
        }
        /// <summary>
        /// Get the list of subscriptions
        /// </summary>        
        /// <returns>list of Subscriptions</returns>
        public List<Subscription> GetSubscriptions(bool? isExpired = null, int? userID = null, int? subscriptionID = null)
        {
            var subscriptions = new List<Subscription>();
            try
            {
                _par = new Object[,]
                    {
                         {"@TxnType", Tables.Subscription.ToString(), null}
                        ,{"@SubscriptionID", subscriptionID, null}
                        ,{"@Status", isExpired, null}
                        ,{"@UserID", userID, null}
                    };

                _dataTable = GetDataTable(_par, StoredProcedures.SpGetDataFromMultipleTables);

                PricePlanManager ppm = new PricePlanManager();
                var pricePlans = ppm.GetPricePlans();

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    subscriptions.AddRange(from DataRow dataRow in _dataTable.Rows
                                     select new Subscription
                                         {
                                             SubscriptionID = GetIntegerValue(_dataTable, dataRow, "SubscriptionID"),
                                             User = new User
                                             {
                                                 UserID = GetIntegerValue(_dataTable, dataRow, "UserID")
                                             },
                                             PricePlan = pricePlans.FirstOrDefault(x => x.PlanID == GetIntegerValue(_dataTable, dataRow, "PlanID")),
                                             StartDate = GetDateTimeValue(_dataTable, dataRow, "StartDate"),
                                             EndDate = GetDateTimeValue(_dataTable, dataRow, "EndDate"),
                                             IsExpired = GetBooleanValue(_dataTable, dataRow, "IsExpired"),
                                             CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy1"),
                                             CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                             ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy1"),
                                             ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                         });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return subscriptions;
        }
        private string GetColumnValuesArray(Subscription subscription)
        {
            return
                "'" + subscription.PricePlan.PlanID +
                "','" + subscription.User.UserID +
                "','" + subscription.StartDate.ToString(DbConstants.DateFormat) +
                "','" + subscription.EndDate.ToString(DbConstants.DateFormat) +
                "','" + (subscription.IsExpired ? "1" : "0");
        }
    }
}