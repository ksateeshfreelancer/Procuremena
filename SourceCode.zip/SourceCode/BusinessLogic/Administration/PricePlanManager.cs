﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 26-Apr-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;

#endregion

namespace CLB.BL.Administration
{   
    public class PricePlanManager : BLBaseClass
    {
        public string SavePlanFeature(PlanFeature planFeature, out bool status)
        {
            DbMessage dbMessage = Save_Update(planFeature, Tables.PlanFeature, new[] { "PlanFeatureID", "ControlValue" }, out status,
                out _identity, "FeatureName", planFeature.PlanFeatureID > 0 ? "PlanFeatureID" : null, planFeature.PlanFeatureID > 0 ? planFeature.PlanFeatureID.ToString() : null);
            return DbConstants.OutMessage(dbMessage, "Plan Feature");
        }
        public string SavePricePlan(PricePlan pricePlan, out bool status)
        {
            DbMessage dbMessage = Save_Update(pricePlan, Tables.PricePlan, new[] { "PlanID", "PlanFeatures" }, out status,
                out _identity, "PlanName", (pricePlan.PlanID > 0) ? "PlanID" : null, (pricePlan.PlanID > 0) ? pricePlan.PlanID.ToString() : null);
            return DbConstants.OutMessage(dbMessage, "Price Plan");
        }
        public string DeletePlanFeature(int planFeatureID)
        {
            return DbConstants.OutMessage(Delete(Tables.PlanFeature, "PlanFeatureID", planFeatureID.ToString()), "Plan Feature");
        }
        public string DeletePricePlan(int pricePlanID)
        {
            return DbConstants.OutMessage(Delete(Tables.PricePlan, "PlanID", pricePlanID.ToString()), "Price Plan");
        }                
        /// <summary>
        /// Method to delete existing price plan details from database and add new
        /// </summary>
        /// <param name="pricePlans"></param>
        /// <returns></returns>
        public string UpdatePricePlanManagement(IEnumerable<PricePlan> pricePlans)
        {
            var msg = DbMessage.Failed;
            //delete only those plans that require update
            foreach (var pricePlan in pricePlans)
            {
                msg = Delete(Tables.PriceManagement, "PlanID", pricePlan.PlanID.ToString());    
            }
            //var msg = Delete(Tables.PriceManagement);

            var columnValuesArray = pricePlans.Aggregate(string.Empty,
                (current1, pricePlan) =>
                    pricePlan.PlanFeatures.Aggregate(current1,
                        (current, planFeature) =>
                            current +
                            ("'" + pricePlan.PlanID + "','" + planFeature.PlanFeatureID + "','" +
                             planFeature.ControlValue + "','" + pricePlan.CreatedBy + "','" + pricePlan.ModifiedBy +
                             "'~")));

            return
                DbConstants.OutMessage(
                    msg == DbMessage.Delete || msg == DbMessage.NotFound
                        ? InsertMultipleRows(Tables.PriceManagement.ToString(), "PlanID,PlanFeatureID,ControlValue,CreatedBy,ModifiedBy",
                            columnValuesArray.TrimEnd('~'))
                        : DbMessage.Failed, "Price Plan");
        }
        public List<PricePlan> GetPricePlans(int? planID = null)
        {
            var pricePlans = new List<PricePlan>();

            var priceManagements = GetData(Tables.PriceManagement, (planID.HasValue) ? "PlanID" : null, (planID.HasValue) ? planID.ToString() : null);

            var planFeatures = GetPlanFeatures();

            _dataTable = GetData(Tables.PricePlan, (planID.HasValue) ? "PlanID" : null, (planID.HasValue) ? planID.ToString() : null);

            pricePlans.AddRange((from DataRow dr in _dataTable.Rows
                                 select new PricePlan
                                 {
                                     PlanID = GetIntegerValue(_dataTable, dr, "PlanID"),
                                     PlanName = GetStringValue(_dataTable, dr, "PlanName"),
                                     PlanPrice = GetDoubleValue(_dataTable, dr, "PlanPrice"),
                                     PlanSubscription = GetEnumValue<Frequency>(_dataTable, dr, "PlanSubscription"),
                                     PlanFeatures = new List<PlanFeature>(),
                                     CreatedBy = GetStringValue(_dataTable, dr, "CreatedBy1"),
                                     CreatedDate = GetDateTimeValue(_dataTable, dr, "CreatedDate"),
                                     ModifiedBy = GetStringValue(_dataTable, dr, "ModifiedBy1"),
                                     ModifiedDate = GetDateTimeValue(_dataTable, dr, "ModifiedDate")
                                 }));

            foreach (var priceplan in pricePlans)
            {
                var drArray = priceManagements.Select("PlanID=" + priceplan.PlanID);

                var newPlanFeatures = new List<PlanFeature>();

                foreach (DataRow item in drArray)
                {
                    if (planFeatures.Count(x => x.PlanFeatureID == int.Parse(item["PlanFeatureID"].ToString())) != 0)
                    {
                        var planFeature = planFeatures.SingleOrDefault(x => x.PlanFeatureID == int.Parse(item["PlanFeatureID"].ToString()));
                        newPlanFeatures.Add(new PlanFeature
                        {
                            CreatedBy = planFeature.CreatedBy,
                            CreatedDate = planFeature.CreatedDate,
                            Description = planFeature.Description,
                            FeatureName = planFeature.FeatureName,
                            ModifiedBy = planFeature.ModifiedBy,
                            ModifiedDate = planFeature.ModifiedDate,
                            PlanFeatureID = planFeature.PlanFeatureID,
                            ControlType = planFeature.ControlType,
                            ControlValue = item["ControlValue"].ToString(),
                        });
                    }
                }
                priceplan.PlanFeatures = newPlanFeatures;
            }


            return pricePlans;
        }
        public List<PlanFeature> GetPlanFeatures(int? planFeatureId = null)
        {
            var planFeatures = new List<PlanFeature>();

            _dataTable = GetData(Tables.PlanFeature, (planFeatureId.HasValue) ? "PlanFeatureID" : null, (planFeatureId.HasValue) ? planFeatureId.Value.ToString() : null, null);

            planFeatures.AddRange((from DataRow dr in _dataTable.Rows
                                   select new PlanFeature
                                   {
                                       PlanFeatureID = GetIntegerValue(_dataTable, dr, "PlanFeatureID"),
                                       FeatureName = GetStringValue(_dataTable, dr, "FeatureName"),
                                       Description = GetStringValue(_dataTable, dr, "Description"),
                                       ControlType = GetIntegerValue(_dataTable, dr, "ControlType"),
                                       IsEditable = GetBooleanValue(_dataTable, dr, "IsEditable"),
                                       CreatedBy = GetStringValue(_dataTable, dr, "CreatedBy1"),
                                       CreatedDate = GetDateTimeValue(_dataTable, dr, "CreatedDate"),
                                       ModifiedBy = GetStringValue(_dataTable, dr, "ModifiedBy1"),
                                       ModifiedDate = GetDateTimeValue(_dataTable, dr, "ModifiedDate")
                                   }).ToList());

            return planFeatures;
        }
    }
}
