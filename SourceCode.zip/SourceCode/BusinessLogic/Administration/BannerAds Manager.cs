﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Apr-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL.Administration
{
    public class BannerAdManager : BLBaseClass
    {
        /// <summary>
        /// Save multiple BannerAds
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveBannerAds(List<BannerAd> bannerAds, out bool status)
        {
            try
            {
                status = true;
                if (bannerAds == null || bannerAds.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "BannerAd(s)");

                var columnNamesArray = "UserID,InventoryID,BannerPosition,ExpiryDate,Status,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate";
                var columnValuesArray = bannerAds.Aggregate(string.Empty,
                            (current, bannerAd) =>
                            current +
                            ("'" + bannerAd.User.UserID +
                            "','" + bannerAd.Inventory.InventoryID +
                            "','" + (int)bannerAd.BannerPosition +
                            "','" + bannerAd.ExpiryDate.ToString(DbConstants.DateFormat) +
                            "','" + (int)bannerAd.Status +
                            "','" + CurrentUserID +
                            "',GETDATE()" +
                            ",'" + CurrentUserID +
                            "',GETDATE()~"));
                return
                    DbConstants.OutMessage(InsertMultipleRows(Tables.BannerAd.ToString(), columnNamesArray, columnValuesArray.TrimEnd('~')), "BannerAds");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "BannerAd(s)");
            }
        }

        /// <summary>
        /// Update bannerAds
        /// </summary>        
        /// <returns>message to display</returns>
        public string UpdateBannerAds(List<BannerAd> bannerAds, out bool status)
        {
            try
            {
                status = true;
                if (bannerAds == null || bannerAds.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "BannerAd(s)");

                var columnValuesArray = bannerAds.Aggregate(string.Empty,
                            (current, bannerAd) => current + ("'" + bannerAd.User.UserID +
                                                        "','" + bannerAd.Inventory.InventoryID +
                                                        "','" + (int)bannerAd.BannerPosition +
                                                        "','" + bannerAd.ExpiryDate.ToString(DbConstants.DateFormat) +
                                                        "','" + (int)bannerAd.Status +
                                                        "','" + CurrentUserID +
                                                        "',GETDATE()~"));
                var filterColumnValuesArray = bannerAds.Aggregate(string.Empty,
                            (current, bannerAd) => current + ("'" + bannerAd.BannerAdID + "',"));

                return DbConstants.OutMessage(UpdateMultipleRows(Tables.BannerAd.ToString(),
                    "UserID,InventoryID,BannerPosition,ExpiryDate,Status,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~'), "BannerAdID",
                    filterColumnValuesArray.TrimEnd(',')), "BannerAd(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "BannerAds");
            }
        }

        /// <summary>
        /// Delete BannerAd by BannerAd id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteBannerAd(int bannerAdID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.BannerAd.ToString(), null}
                    , {"@ColumnName", "BannerAdID", null}
                    , {"@ColumnValue", bannerAdID, null}
                    , {"@OutMessage", null, "Out"}
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "BannerAd");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "BannerAd", "Other data");
            }
        }

        /// <summary>
        /// Get the list of BannerAds
        /// </summary>        
        /// <returns>list of BannerAds</returns>
        public List<BannerAd> GetBannerAds(Status? status = null, int bannerAdId = 0)
        {
            var bannerAds = new List<BannerAd>();
            try
            {

                if (_dataTable == null)
                {
                    _par = new Object[,]
                   {
                         {"@TxnType", Tables.BannerAd.ToString(), null}
                        ,{"@BannerAdId", bannerAdId == 0 ? null : bannerAdId.ToString(), null}
                        ,{"@status", status, null}
                   };

                    if (status.HasValue)
                        _dataTable = GetData(Tables.BannerAd, "Status", Convert.ToString((int)status));
                    else
                        _dataTable = GetDataTable(_par, StoredProcedures.SpGetDataFromMultipleTables);
                }

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    bannerAds.AddRange(from DataRow dataRow in _dataTable.Rows
                                       select new BannerAd
                                       {
                                           BannerAdID = GetIntegerValue(_dataTable, dataRow, "BannerAdID"),
                                           User = new User
                                           {
                                               UserDetails = new UserDetails
                                               {
                                                   FirstName = GetStringValue(_dataTable, dataRow, "FirstName"),
                                                   LastName = GetStringValue(_dataTable, dataRow, "LastName"),
                                               },

                                               UserID = GetIntegerValue(_dataTable, dataRow, "UserId"),
                                               Email = GetStringValue(_dataTable, dataRow, "Email"),
                                               Mobile = GetStringValue(_dataTable, dataRow, "Mobile"),
                                           },
                                           Inventory = new VendorInventory
                                           {
                                               InventoryID = GetIntegerValue(_dataTable, dataRow, "InventoryID"),
                                               Description = GetStringValue(_dataTable, dataRow, "Description"),
                                               Product = new ProductCatalog
                                               {
                                                   ProductID = GetIntegerValue(_dataTable, dataRow, "ProductID")
                                               }
                                           },
                                           BannerPosition = GetEnumValue<BannerPosition>(_dataTable, dataRow, "BannerPosition"),
                                           ExpiryDate = GetDateTimeValue(_dataTable, dataRow, "ExpiryDate"),
                                           Status = GetEnumValue<Status>(_dataTable, dataRow, "Status"),
                                           CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy1"),
                                           CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                           ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy1"),
                                           ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                       });
                };
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return bannerAds;
        }
    }
}