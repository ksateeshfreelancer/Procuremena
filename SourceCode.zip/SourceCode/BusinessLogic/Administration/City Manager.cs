﻿#region Developer Note
/*
 * Created by       : Jagan
 * Created Date     : 16-Apr-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;
using System.Data;
#endregion

namespace CLB.BL.Administration
{
    public class CityManager : BLBaseClass
    {
        string columnNamesArray = "CityName,CountryID,AliasNames,DisplayOrder,Status";
        public string SaveCity(City city, out int _identity, out bool status)
        {
            try
            {
                //city can be inserted even as a guest
                int userid = 0;
                int.TryParse(CurrentUserID, out userid);
                //update city
                if (city.CityID > 0)
                {
                    _par = new object[,]
                        {
                            {"@TableName", Tables.City.ToString(), null}
                            , {"@ColumnNames", columnNamesArray + ",ModifiedBy,ModifiedDate", null}
                            , {"@ColumnValues", GetColumnValuesArray(city) + "','" + userid +
                                            "',GETDATE()", null}
                            , {"@UniqueColumns", null, null}
                            , {"@FilterColumnName", "CityID", null}
                            , {"@FilterColumnValue", city.CityID, null}
                            , {"@OutMessage", null, "Out"}
                        };

                    UpdateData(_par);
                    _identity = city.CityID;
                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    return DbConstants.OutMessage(_dbMessage, "City");
                }
                //insert city                
                _par = new object[,]
                    {
                        {"@Identity", null, "Out"}
                        , {"@TableName", Tables.City.ToString(), null}
                        , {"@ColumnNames", columnNamesArray + ",CreatedBy,CreatedDate,ModifiedBy,ModifiedDate", null}
                        , {"@ColumnValues", GetColumnValuesArray(city) + "','" + userid +
                                            "',GETDATE()" + ",'" + userid +
                                            "',GETDATE()", null}
                        , {"@UniqueColumns", null, null}
                        , {"@OutMessage", null, "Out"}
                    };

                var result = SaveData(_par);
                _identity = int.Parse(_par[0, 1].ToString());
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(_dbMessage, "City");
            }
            catch (Exception ex)
            {
                LogException(ex);
                _identity = 0;
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Failed);
            }
        }

        /// <summary>
        /// Save multiple Cities
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveCities(List<City> cities, out bool status)
        {
            try
            {
                status = true;
                if (cities == null || cities.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");
                var columnValuesArray = cities.Aggregate(string.Empty,
                            (current, city) =>
                            current +
                            (GetColumnValuesArray(city) +
                            "','" + CurrentUserID +
                            "',GETDATE()" +
                            ",'" + CurrentUserID +
                            "',GETDATE()~"));
                return
                    DbConstants.OutMessage(InsertMultipleRows(Tables.City.ToString(), columnNamesArray + ",CreatedBy,CreatedDate,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Update Cities
        /// </summary>        
        /// <returns>message to display</returns>
        public string UpdateCities(List<City> cities, out bool status)
        {
            try
            {
                status = true;
                if (cities == null || cities.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnValuesArray = cities.Aggregate(string.Empty,
                            (current, city) => current + (GetColumnValuesArray(city) +
                                                        "','" + CurrentUserID +
                                                        "',GETDATE()~"));
                var filterColumnValuesArray = cities.Aggregate(string.Empty,
                            (current, city) => current + ("'" + city.CityID + "',"));

                return DbConstants.OutMessage(UpdateMultipleRows(Tables.City.ToString(),
                    "CityName,CountryID,AliasNames,DisplayOrder,Status,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~'), "CityID",
                    filterColumnValuesArray.TrimEnd(',')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Delete city by city id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteCity(int cityID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.City.ToString(), null}
                    , {"@ColumnName", "CityID", null}
                    , {"@ColumnValue", cityID, null}
                    , {"@OutMessage", null, "Out"}
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "City");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "City", "Other data");
            }
        }

        /// <summary>
        /// Get the list of Cities
        /// </summary>        
        /// <returns>list of Cities</returns>
        public List<City> GetCities(int? countryID = null)
        {
            var cities = new List<City>();
            try
            {
                _dataTable = GetData(Tables.City, null, null);
                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    cities.AddRange(from DataRow dataRow in _dataTable.Rows
                                    where (!countryID.HasValue || countryID.Value == GetIntegerValue(_dataTable, dataRow, "CountryID"))
                                    select new City
                                    {
                                        CityID = GetIntegerValue(_dataTable, dataRow, "CityID"),
                                        CityName = GetStringValue(_dataTable, dataRow, "CityName"),
                                        Country = new Country
                                        {
                                            CountryID = GetIntegerValue(_dataTable, dataRow, "CountryID"),
                                            CountryName = GetStringValue(_dataTable, dataRow, "CountryName")
                                        },
                                        AliasNames = GetStringValue(_dataTable, dataRow, "AliasNames"),
                                        DisplayOrder = GetIntegerValue(_dataTable, dataRow, "DisplayOrder"),
                                        Status = GetEnumValue<Status>(_dataTable, dataRow, "Status"),
                                        CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy1"),
                                        CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                        ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy1"),
                                        ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                    });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return cities;
        }

        private string GetColumnValuesArray(City city)
        {
            return
                "'" + city.CityName.Replace(',', '^').Replace("'", "`") +
                "','" + city.Country.CountryID +
                "','" + (city.AliasNames == null ? "" : city.AliasNames.Replace(',', '^').Replace("'", "`")) +
                "','" + city.DisplayOrder +
                "','" + (int)city.Status;
        }

    }
}
