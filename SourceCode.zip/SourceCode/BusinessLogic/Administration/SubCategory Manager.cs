﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL.Administration
{
    public class SubCategoryManager : BLBaseClass
    {
        /// <summary>
        /// Save multiple SubCategories
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveSubCategories(List<SubCategory> subCategories, out bool status)
        {
            try
            {
                status = true;
                if (subCategories == null || subCategories.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnNamesArray = "CategoryID,SubCategoryName,AliasNames,DisplayOrder,Status,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate";
                var columnValuesArray = subCategories.Aggregate(string.Empty,
                            (current, subCategory) =>
                            current +
                            ("'" + subCategory.Category.CategoryID +
                            "','" + subCategory.SubCategoryName.Replace(',', '^').Replace("'", "`") +
                            "','" + subCategory.AliasNames.Replace(',', '^').Replace("'", "`") +
                            "','" + subCategory.DisplayOrder +
                            "','" + (int)subCategory.Status +
                            "','" + CurrentUserID +
                            "',GETDATE()" +
                            ",'" + CurrentUserID +
                            "',GETDATE()~"));
                return
                    DbConstants.OutMessage(InsertMultipleRows(Tables.SubCategory.ToString(), columnNamesArray,
                    columnValuesArray.TrimEnd('~')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Update subCategories
        /// </summary>        
        /// <returns>message to display</returns>
        public string UpdateSubCategories(List<SubCategory> subCategories, out bool status)
        {
            try
            {
                status = true;
                if (subCategories == null || subCategories.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnValuesArray = subCategories.Aggregate(string.Empty,
                            (current, subCategory) => current + ("'" + subCategory.Category.CategoryID +
                                                        "','" + subCategory.SubCategoryName.Replace(',', '^').Replace("'", "`") +
                                                        "','" + subCategory.AliasNames.Replace(',', '^').Replace("'", "`") +
                                                        "','" + subCategory.DisplayOrder +
                                                        "','" + (int)subCategory.Status +
                                                        "','" + CurrentUserID +
                                                        "',GETDATE()~"));
                var filterColumnValuesArray = subCategories.Aggregate(string.Empty,
                            (current, subCategory) => current + ("'" + subCategory.SubCategoryID + "',"));

                return DbConstants.OutMessage(UpdateMultipleRows(Tables.SubCategory.ToString(),
                    "CategoryID,SubCategoryName,AliasNames,DisplayOrder,Status,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~'), "SubCategoryID",
                    filterColumnValuesArray.TrimEnd(',')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Delete subCategory by subCategory id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteSubCategory(int subCategoryID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.SubCategory.ToString(), null}
                    , {"@ColumnName", "SubCategoryID", null}
                    , {"@ColumnValue", subCategoryID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "SubCategory");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "SubCategory", "Other data");
            }
        }

        /// <summary>
        /// Get the list of SubCategories
        /// </summary>        
        /// <returns>list of SubCategories</returns>
        public List<SubCategory> GetSubCategories(int? subCategoryID = null)
        {
            var subCategories = new List<SubCategory>();
            try
            {
                _par = new Object[,]
                    {
                         {"@TxnType", Tables.SubCategory.ToString(), null}
                        ,{"@SubCategoryID", subCategoryID, null}
                    };

                _dataTable = GetDataTable(_par, StoredProcedures.SpGetDataFromMultipleTables);

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    subCategories.AddRange(from DataRow dataRow in _dataTable.Rows
                                           select new SubCategory
                                           {
                                               SubCategoryID = GetIntegerValue(_dataTable, dataRow, "SubCategoryID"),
                                               SubCategoryName = GetStringValue(_dataTable, dataRow, "SubCategoryName"),
                                               AliasNames = GetStringValue(_dataTable, dataRow, "AliasNames"),
                                               Category = new Category
                                               {
                                                   CategoryID = GetIntegerValue(_dataTable, dataRow, "CategoryID"),
                                                   CategoryName = GetStringValue(_dataTable, dataRow, "CategoryName"),
                                                   DisplayOrder = GetIntegerValue(_dataTable, dataRow, "CDisplayOrder"),
                                               },
                                               DisplayOrder = GetIntegerValue(_dataTable, dataRow, "DisplayOrder"),
                                               Status = GetEnumValue<Status>(_dataTable, dataRow, "Status"),
                                               CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy"),
                                               CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                               ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy"),
                                               ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                           });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return subCategories;
        }
    }
}