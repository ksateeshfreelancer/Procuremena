﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL
{
    public class UnitofMeasurementManager : BLBaseClass
    {
        /// <summary>
        /// Save or update unit detials
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveUnitofMeasurement(UnitofMeasurement unitofMeasurement, out bool status)
        {
            _dbMessage = Save_Update(unitofMeasurement, Tables.UnitofMeasurement, new[] { "UnitID" }, out status,
               out _identity, "UnitName", unitofMeasurement.UnitID > 0 ? "UnitID" : null, unitofMeasurement.UnitID > 0 ? unitofMeasurement.UnitID.ToString() : null);
            return DbConstants.OutMessage(_dbMessage, "Unit Details");
        }

        /// <summary>
        /// Save multiple units details
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveUnitofMeasurements(List<UnitofMeasurement> unitofMeasurements, out bool status)
        {
            try
            {
                status = true;
                if (unitofMeasurements == null || unitofMeasurements.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnNamesArray = "UnitName,Status,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate";
                var columnValuesArray = unitofMeasurements.Aggregate(string.Empty,
                            (current, unit) =>
                            current +
                            ("'" + unit.UnitName.Replace(',', '^').Replace("'", "`") +
                            "','" + (int)unit.Status +
                            "','" + CurrentUserID +
                            "',GETDATE()" +
                            ",'" + CurrentUserID +
                            "',GETDATE()~"));
                return
                    DbConstants.OutMessage(InsertMultipleRows(Tables.UnitofMeasurement.ToString(), columnNamesArray, columnValuesArray.TrimEnd('~')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Update Units details 
        /// </summary>        
        /// <returns>message to display</returns>
        public string UpdateUnitofMeasurements(List<UnitofMeasurement> unitofMeasurements, out bool status)
        {
            try
            {
                status = true;
                if (unitofMeasurements == null || unitofMeasurements.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnValuesArray = unitofMeasurements.Aggregate(string.Empty,
                            (current, unit) => current + ("'" + unit.UnitName.Replace(',', '^').Replace("'", "`") +
                                                        "','" + (int)unit.Status +
                                                        "','" + CurrentUserID +
                                                        "',GETDATE()~"));
                var filterColumnValuesArray = unitofMeasurements.Aggregate(string.Empty,
                            (current, enquiry) => current + ("'" + enquiry.UnitID + "',"));

                return DbConstants.OutMessage(UpdateMultipleRows(Tables.UnitofMeasurement.ToString(),
                    "UnitName,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~'), "UnitID",
                    filterColumnValuesArray.TrimEnd(',')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Delete unit by unitid
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteUnitofMeasurement(int unitID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.UnitofMeasurement.ToString(), null}
                    , {"@ColumnName", "UnitID", null}
                    , {"@ColumnValue", unitID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Unit");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "Unit", "Other data");
            }
        }

        /// <summary>
        /// Get the list of UnitofMeasurements 
        /// </summary>        
        /// <returns>list of UnitofMeasurements</returns>
        public List<UnitofMeasurement> GetUnitofMeasurements()
        {
            var unitofMeasurements = new List<UnitofMeasurement>();
            try
            {
                _dataTable = GetData(Tables.UnitofMeasurement, null, null);
                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    unitofMeasurements.AddRange(from DataRow dataRow in _dataTable.Rows
                                         select new UnitofMeasurement
                                         {
                                             UnitID = GetIntegerValue(_dataTable, dataRow, "UnitID"),
                                             UnitName = GetStringValue(_dataTable, dataRow, "UnitName"),
                                             Status = GetEnumValue<Status>(_dataTable, dataRow, "Status"),
                                             CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy1"),
                                             CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                             ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy1"),
                                             ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                         });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return unitofMeasurements;
        }
    }
}