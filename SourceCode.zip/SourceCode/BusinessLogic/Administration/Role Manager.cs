﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 17-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Caching;
using System.Xml;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;

#endregion

namespace CLB.BL
{
    public sealed class RoleManager : BLBaseClass
    {
        #region Private Variables

        //string columnNamesArray = "RoleName,Level,Screens";

        #endregion

        #region Public Methods

        /// <summary>
        /// Save or update role detials
        /// </summary>
        /// <param name="roleName"></param>
        /// <param name="status"></param>
        /// <param name="roleId"></param>
        /// <returns>message to display</returns>
        public string SaveRole(Role role, out bool status)
        {
            try
            {
                var user = (User)HttpContext.Current.Session[SessionVariables.CurrentUser];

                var screenIds = "";
                foreach (var screen in role.Screens)
                {
                    if (screenIds != string.Empty)
                        screenIds += "~";
                    screenIds += screen.ScreenID;
                }

                //update entity
                if (role.RoleID > 0)
                {
                    _par = new object[,]
                        {
                            {"@TableName", Tables.Roles.ToString(), null}
                            , {"@ColumnNames", "[RoleName],[Level],[Screens],[ModifiedBy],[ModifiedDate]", null}
                            ,
                            {
                                "@ColumnValues",
                                "'" + role.RoleName.Replace(',', '^').Replace("'", "`") + "','" + role.Level +  
                                "'," + (string.IsNullOrEmpty(screenIds) ? "NULL" : ("'" + screenIds + "'")) + 
                                ",'" + user.UserID + "',GETDATE()",
                                null
                            }
                            , {"@UniqueColumns", "RoleName", null}
                            , {"@FilterColumnName", "RoleID", null}
                            , {"@FilterColumnValue", role.RoleID, null}
                            , {"@OutMessage", null, "Out"}
                        };
                    UpdateData(_par);

                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    return DbConstants.OutMessage(_dbMessage, "Role");
                }
                //insert entity
                _par = new object[,]
                    {
                        {"@TableName", Tables.Roles.ToString(), null}
                        //current date will be inserted to CreatedDate and ModifiedDate columns when new row is created
                        , {"@ColumnNames", "[RoleName],[Level],[Screens],[CreatedBy],[ModifiedBy]", null}
                        ,
                        {
                            "@ColumnValues",
                            "'" + role.RoleName.Replace(',', '^').Replace("'", "`") + "','" + role.Level + 
                            "'," + (string.IsNullOrEmpty(screenIds) ? "NULL" : ("'" + screenIds + "'")) +",'" + user.UserID + "','" + user.UserID + "'", null
                        }
                        , {"@UniqueColumns", "RoleName", null}
                        , {"@OutMessage", null, "Out"}
                    };
                SaveData(_par);

                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(_dbMessage, "Role");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Failed, "Role");
            }
        }

        /******************************
         * Save & Update multiple roles is deleted as insert/update multiple rows SP will not work here. 
         * Screens are appended with ~ character, this has conflict with ~ in SP
        ******************************/

        /// <summary>
        /// Delete role by role id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteRole(int roleID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.Roles.ToString(), null}
                    , {"@ColumnName", "RoleID", null}
                    , {"@ColumnValue", roleID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Role");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "Role", "Other data");
            }
        }

        /// <summary>
        /// Get the list of roles, filter role
        /// </summary>
        /// <param name="columnNames"></param>
        /// <param name="columnValues"></param>
        /// <param name="columnsToRetrieve"></param>
        /// <returns>list of roles</returns>
        public List<Role> GetRoles(string columnNames = null, string columnValues = null, string columnsToRetrieve = null)
        {
            var roles = new List<Role>();

            try
            {
                var screens = GetScreens();

                _par = new Object[,] 
                {   
                    { "@TableName", Tables.Roles.ToString(), null}
                    ,{ "@ColumnNames",columnNames, null}
                    ,{ "@ColumnValues", columnValues, null}
                    ,{ "@ColumnsToRetrieve", columnsToRetrieve, null}
                    ,{"@OutMessage", null, "Out"}
                };

                var dataTable = GetDataTable(_par);

                if (dataTable.Rows.Count > 0)
                {
                    roles.AddRange(from DataRow myDataRow in dataTable.Rows
                                   select new Role
                                       {
                                           RoleID = GetIntegerValue(dataTable, myDataRow, "RoleID"),
                                           RoleName = GetStringValue(dataTable, myDataRow, "RoleName"),
                                           Level =
                                               (dataTable.Columns.Contains("Level") == false)
                                                   ? 2
                                                   : int.Parse(myDataRow["Level"].ToString()),
                                           Screens =
                                               (dataTable.Columns.Contains("Screens") == false)
                                                   ? null
                                                   : MapScreens(screens, myDataRow["Screens"].ToString()),
                                           CreatedBy = GetStringValue(dataTable, myDataRow, "CreatedBy1"),
                                           CreatedDate = GetDateTimeValue(dataTable, myDataRow, "CreatedDate"),
                                           ModifiedBy = GetStringValue(dataTable, myDataRow, "ModifiedBy1"),
                                           ModifiedDate = GetDateTimeValue(dataTable, myDataRow, "ModifiedDate")
                                       });

                    roles = roles.OrderBy(x => x.RoleID).ToList();
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return roles;
        }

        /// <summary>
        /// Get the list of roles, filter role
        /// </summary>
        /// <param name="columnNames"></param>
        /// <param name="columnValues"></param>
        /// <param name="columnsToRetrieve"></param>
        /// <returns>list of roles</returns>
        public List<Screen> GetScreens(string columnNames = null, string columnValues = null, string columnsToRetrieve = null)
        {
            var screens = new List<Screen>();
            try
            {
                _par = new Object[,] 
                {   
                    { "@TableName", Tables.Screens.ToString(), null}
                    ,{ "@ColumnNames",columnNames, null}
                    ,{ "@ColumnValues", columnValues, null}
                    ,{ "@ColumnsToRetrieve", columnsToRetrieve, null}
                    ,{"@OutMessage", null, "Out"}
                };
                var dataTable = GetDataTable(_par);

                if (dataTable.Rows.Count > 0)
                {
                    screens.AddRange(from DataRow myDataRow in dataTable.Rows
                                     select new Screen
                                     {
                                         ScreenID = GetIntegerValue(dataTable, myDataRow, "ScreenId"),
                                         ScreenName = GetStringValue(dataTable, myDataRow, "Name"),
                                         DisplayName = GetStringValue(dataTable, myDataRow, "DisplayName"),
                                         Order = GetIntegerValue(dataTable, myDataRow, "Order"),
                                         Status = GetEnumValue<CLB.Enums.Status>(dataTable, myDataRow, "Status"),
                                         Category = (MenuCategory)(byte)myDataRow["Category"],
                                         ShowInMenu = GetBooleanValue(dataTable, myDataRow, "ShowInMenu"),
                                         IsAdminScreen = GetBooleanValue(dataTable, myDataRow, "IsAdminScreen")
                                     });

                    screens = screens.OrderBy(x => x.ScreenID).ToList();
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return screens;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Convert screen ids comma seperated string to list of screens
        /// </summary>
        /// <param name="screens"></param>
        /// <param name="screenIds"></param>
        /// <returns></returns>
        private List<Screen> MapScreens(IEnumerable<Screen> screens, string screenIds)
        {
            return screens.Where(x => screenIds.Split('~').Contains(x.ScreenID.ToString())).ToList();
        }


        private string GetColumnValuesArray(Role role)
        {
            return
                "'" + role.RoleName + "'" +
                "," + role.Level +
                ",'" + string.Join("~", (role.Screens.Select(x => x.ScreenID)));
        }

        #endregion
    }
}
