﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL.Administration
{
    public class MainCategoryManager : BLBaseClass
    {
        /// <summary>
        /// Get the list of Category
        /// </summary>        
        /// <returns>list of Categories</returns>
        public List<MainCategory> GetMainCategories(int? mainCategoryID = null)
        {
            var mainCategories = new List<MainCategory>();
            try
            {
                _dataTable = GetData(Tables.MainCategory, null, null);

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    mainCategories.AddRange(from DataRow dataRow in _dataTable.Rows
                                            where (!mainCategoryID.HasValue || mainCategoryID.Value == GetIntegerValue(_dataTable, dataRow, "MainCategoryID"))
                                            select new MainCategory
                                            {
                                                MainCategoryID = GetIntegerValue(_dataTable, dataRow, "MainCategoryID"),
                                                MainCategoryName = GetStringValue(_dataTable, dataRow, "MainCategoryName"),
                                                Status = GetEnumValue<Status>(_dataTable, dataRow, "Status"),
                                                CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy1"),
                                                CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                                ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy1"),
                                                ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                            });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return mainCategories;
        }
    }
}