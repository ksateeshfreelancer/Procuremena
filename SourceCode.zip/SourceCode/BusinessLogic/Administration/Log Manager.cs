﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;


#endregion

namespace CLB.BL.Administration
{
    public class LogManager : BLBaseClass
    {

        /// <summary>
        /// Save or SMS Log
        /// </summary>        
        /// <returns>message to display</returns>
        public string LogSMS(SMSLog smsLog, out bool status)
        {
            _dbMessage = Save_Update(smsLog, Tables.SMSLog, new[] { "SMSLogID" }, out status, out _identity,
                null, null, null, false);
            return DbConstants.OutMessage(_dbMessage, "SMS Log");
        }

        /// <summary>
        /// Save or Email Log
        /// </summary>        
        /// <returns>message to display</returns>
        public string LogEmail(EmailLog emailLog, out bool status)
        {
            _dbMessage = Save_Update(emailLog, Tables.EmailLog, new[] { "EmailLogID" }, out status, out _identity,
                null, null, null, false);
            return DbConstants.OutMessage(_dbMessage, "Email Log");
        }

        public List<DbErrorLog> GetDbErrorLog(string fromDate = null, string toDate = null)
        {
            _par = new Object[,]
                {
                    {"@TxnType", Tables.DbErrorLog, null}
                    , {"@FromDate", fromDate, null}
                    , {"@ToDate", toDate, null}
                };
            _dataTable = GetDataFromMultipleTables(_par);

            var dbErrorLog = new List<DbErrorLog>();

            dbErrorLog.AddRange((from DataRow dr in _dataTable.Rows
                                 select new DbErrorLog
                                 {
                                     DbErrorLogID = GetIntegerValue(_dataTable, dr, "DbErrorLogID"),
                                     ErrorSeverity = GetIntegerValue(_dataTable, dr, "ErrorSeverity"),
                                     ErrorState = GetIntegerValue(_dataTable, dr, "ErrorState"),
                                     ErrorProcedure = GetStringValue(_dataTable, dr, "ErrorProcedure"),
                                     ErrorMessage = GetStringValue(_dataTable, dr, "ErrorMessage"),
                                     ErrorNumber = GetIntegerValue(_dataTable, dr, "ErrorNumber"),
                                     LogDate = FormatDate(dr["LogDate"]),
                                     ErrorLine = GetIntegerValue(_dataTable, dr, "ErrorLine"),
                                 }).OrderByDescending(x => x.DbErrorLogID).ToList());

            return dbErrorLog;
        }

        public List<ErrorLog> GetErrorLog(string fromDate = null, string toDate = null)
        {
            _par = new Object[,]
                {
                    {"@TxnType", Tables.ErrorLog.ToString(), null}
                    , {"@FromDate", fromDate, null}
                    , {"@ToDate", toDate, null}
                };
            _dataTable = GetDataFromMultipleTables(_par);

            var uiErrorLog = new List<ErrorLog>();

            uiErrorLog.AddRange((from DataRow dr in _dataTable.Rows
                                 select new ErrorLog
                                 {
                                     DetailedMessage = GetStringValue(_dataTable, dr, "DetailedMessage"),
                                     ErrorLogID = GetIntegerValue(_dataTable, dr, "ErrorLogID"),
                                     ErrorMessage = GetStringValue(_dataTable, dr, "ErrorMessage"),
                                     IPAddress = GetStringValue(_dataTable, dr, "IPAddress"),
                                     LogDate = FormatDate(GetDateTimeValue(_dataTable, dr, "LogDate")),
                                     Method = GetStringValue(_dataTable, dr, "Method"),
                                     Page = GetStringValue(_dataTable, dr, "Page"),
                                     //UserId = dr["UserID"].ToString()
                                 }).OrderByDescending(x => x.ErrorLogID).ToList());

            return uiErrorLog;
        }

        public List<LoginLog> GetLoginLog(string fromDate = null, string toDate = null)
        {
            _par = new Object[,]
                {
                    {"@TxnType", Tables.LoginLog.ToString(), null}
                    , {"@FromDate", fromDate, null}
                    , {"@ToDate", toDate, null}
                };
            _dataTable = GetDataFromMultipleTables(_par);

            var loginLog = new List<LoginLog>();

            loginLog.AddRange((from DataRow dr in _dataTable.Rows
                               select new LoginLog
                               {
                                   IPAddress = GetStringValue(_dataTable, dr, "IPAddress"),
                                   LoginDateTime = FormatDate(dr["LoginDateTime"]),
                                   LoginLogID = GetIntegerValue(_dataTable, dr, "LoginLogID"),
                                   Status =
                                       (int.Parse(dr["Status"].ToString()) == 1)
                                           ? Status.Active
                                           : Status.InActive,
                                   //UserId = int.Parse(dr["UserID"].ToString()),
                                   User = new User
                                   {
                                       Email = GetStringValue(_dataTable, dr, "Email"),
                                       Mobile = GetStringValue(_dataTable, dr, "Mobile"),
                                       Role =
                                           (GetIntegerValue(_dataTable, dr, "Role") <= 3)
                                               ? Enum.GetName(typeof(UserRole), GetIntegerValue(_dataTable, dr, "Role"))
                                               : "Dynamic Role"
                                   }
                               }).OrderByDescending(x => x.LoginLogID).ToList());

            return loginLog;
        }

        public List<EmailLog> GetEmailLog(string fromDate = null, string toDate = null)
        {
            _par = new Object[,]
                {
                    {"@TxnType", Tables.EmailLog.ToString(), null}
                    , {"@FromDate", fromDate, null}
                    , {"@ToDate", toDate, null}
                };
            _dataTable = GetDataFromMultipleTables(_par);

            var emailLog = new List<EmailLog>();

            emailLog.AddRange((from DataRow dr in _dataTable.Rows
                               select new EmailLog
                               {
                                   EmailLogID = GetIntegerValue(_dataTable, dr, "EmailLogID"),
                                   Body = GetStringValue(_dataTable, dr, "Body"),
                                   CreatedDate = GetDateTimeValue(_dataTable, dr, "CreatedDate"),
                                   Emails = GetStringValue(_dataTable, dr, "Emails"),
                                   Subject = GetStringValue(_dataTable, dr, "Subject"),
                               }).OrderByDescending(x => x.EmailLogID).ToList());

            return emailLog;
        }

        public List<SMSLog> GetSMSLog(string fromDate = null, string toDate = null)
        {
            _par = new Object[,]
                {
                    {"@TxnType", Tables.SMSLog.ToString(), null}
                    , {"@FromDate", fromDate, null}
                    , {"@ToDate", toDate, null}
                };
            _dataTable = GetDataFromMultipleTables(_par);

            var smsLog = new List<SMSLog>();

            smsLog.AddRange((from DataRow dr in _dataTable.Rows
                                 select new SMSLog
                                 {
                                     CreatedDate = GetDateTimeValue(_dataTable, dr, "CreatedDate"),
                                     Message = GetStringValue(_dataTable, dr, "Message"),
                                     PhoneNos = GetStringValue(_dataTable, dr, "PhoneNos"),
                                     SMSLogID = GetIntegerValue(_dataTable, dr, "SMSLogID")
                                 }).OrderByDescending(x => x.SMSLogID).ToList());

            return smsLog;
        }
    }
}