﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;

#endregion

namespace CLB.BL.Administration
{
    public class CategoryManager : BLBaseClass
    {
        /// <summary>
        /// Save multiple Categories
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveCategories(List<Category> categories, out bool status)
        {
            try
            {
                status = true;
                if (categories == null || categories.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnNamesArray = "CategoryName,MainCategoryID,AliasNames,DisplayOrder,Status,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate";
                var columnValuesArray = categories.Aggregate(string.Empty,
                            (current, category) =>
                            current +
                            ("'" + category.CategoryName.Replace(',', '^').Replace("'", "`") +
                            "','" + category.MainCategory.MainCategoryID +
                            "','" + category.AliasNames.Replace(',', '^').Replace("'", "`") +
                            "','" + category.DisplayOrder +
                            "','" + (int)category.Status +
                            "','" + CurrentUserID +
                            "',GETDATE()" +
                            ",'" + CurrentUserID +
                            "',GETDATE()~"));
                return
                    DbConstants.OutMessage(InsertMultipleRows(Tables.Category.ToString(), columnNamesArray, columnValuesArray.TrimEnd('~')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Update categories
        /// </summary>        
        /// <returns>message to display</returns>
        public string UpdateCategories(List<Category> categories, out bool status)
        {
            try
            {
                status = true;
                if (categories == null || categories.Count == 0)
                    return DbConstants.OutMessage(DbMessage.Success, "Record(s)");

                var columnValuesArray = categories.Aggregate(string.Empty,
                            (current, category) => current + ("'" + category.CategoryName.Replace(',', '^').Replace("'", "`") +
                                                        "','" + category.MainCategory.MainCategoryID +
                                                        "','" + category.AliasNames.Replace(',', '^').Replace("'", "`") +
                                                        "','" + category.DisplayOrder +
                                                        "','" + (int)category.Status +
                                                        "','" + CurrentUserID +
                                                        "',GETDATE()~"));
                var filterColumnValuesArray = categories.Aggregate(string.Empty,
                            (current, category) => current + ("'" + category.CategoryID + "',"));

                return DbConstants.OutMessage(UpdateMultipleRows(Tables.Category.ToString(),
                    "CategoryName,MainCategoryID,AliasNames,DisplayOrder,Status,ModifiedBy,ModifiedDate", columnValuesArray.TrimEnd('~'), "CategoryID",
                    filterColumnValuesArray.TrimEnd(',')), "Record(s)");
            }
            catch (Exception ex)
            {
                status = false;
                LogException(ex);
                return DbConstants.OutMessage(DbMessage.Failed, "Record(s)");
            }
        }

        /// <summary>
        /// Delete category by category id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteCategory(int categoryID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.Category.ToString(), null}
                    , {"@ColumnName", "CategoryID", null}
                    , {"@ColumnValue", categoryID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Category");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "Category", "Other data");
            }
        }

        /// <summary>
        /// Get the list of Category
        /// </summary>        
        /// <returns>list of Categories</returns>
        public List<Category> GetCategories(int? categoryID = null, int? mainCategoryID = null)
        {
            var categories = new List<Category>();
            try
            {
                _par = new Object[,]
                    {
                         {"@TxnType", Tables.Category.ToString(), null}
                    };

                _dataTable = GetDataTable(_par, StoredProcedures.SpGetDataFromMultipleTables);

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    categories.AddRange(from DataRow dataRow in _dataTable.Rows
                                        where (!categoryID.HasValue || categoryID.Value == GetIntegerValue(_dataTable, dataRow, "CategoryID"))
                                        && (!mainCategoryID.HasValue || mainCategoryID.Value == GetIntegerValue(_dataTable, dataRow, "MainCategoryID"))
                                        select new Category
                                        {
                                            CategoryID = GetIntegerValue(_dataTable, dataRow, "CategoryID"),
                                            CategoryName = GetStringValue(_dataTable, dataRow, "CategoryName"),
                                            MainCategory = new MainCategory
                                            {
                                                MainCategoryID = GetIntegerValue(_dataTable, dataRow, "MainCategoryID"),
                                                MainCategoryName = GetStringValue(_dataTable, dataRow, "MainCategoryName")
                                            },
                                            AliasNames = GetStringValue(_dataTable, dataRow, "AliasNames"),
                                            DisplayOrder = GetIntegerValue(_dataTable, dataRow, "DisplayOrder"),
                                            Status = GetEnumValue<Status>(_dataTable, dataRow, "Status"),
                                            CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy"),
                                            CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                            ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy"),
                                            ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                        });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return categories;
        }


        /// <summary>
        /// Get the list of Category to build the menu
        /// </summary>        
        /// <returns>list of Categories</returns>
        public List<Category> GetMenuCategories(int? categoryID = null, int? mainCategoryID = null)
        {
            var categories = new List<Category>();
            try
            {
                _par = new Object[,]
                    {
                         {"@TxnType", Tables.Category.ToString(), null}
                    };

                _dataTable = GetDataSet(null, StoredProcedures.spGetMenuData).Tables[0];

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    categories.AddRange(from DataRow dataRow in _dataTable.Rows
                                        select new Category
                                        {
                                            CategoryID = GetIntegerValue(_dataTable, dataRow, "CategoryID"),
                                            CategoryName = GetStringValue(_dataTable, dataRow, "CategoryName"),
                                            SubCategories = new List<SubCategory>() { 
                                            new SubCategory { SubCategoryID= GetIntegerValue(_dataTable, dataRow, "SubCategoryID"),SubCategoryName= GetStringValue(_dataTable, dataRow, "SubCategoryName") }

                                             }
                                        });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return categories;
        }
    }
}