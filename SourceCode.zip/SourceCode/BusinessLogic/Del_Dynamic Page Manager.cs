﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

#endregion

namespace CLB.BL
{
    public class DynamicPageManager : BLBaseClass
    {

        /// <summary>
        /// Save or update dynamicPage detials
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveDynamicPage(DynamicPage dynamicPage, out bool status)
        {
            try
            {
                status = true;
                //delete existing page and add new content
                if (dynamicPage.DynamicPageID > 0)
                {
                    var result = DeleteDynamicPage(dynamicPage.DynamicPageID, out status);
                }
                //do not insert new record into database if failed to delete existing record
                if (!status)
                    return DbConstants.OutMessage(DbMessage.Failed);

                DataTable dt = new DataTable();
                dt.Columns.AddRange(new[] { new DataColumn("PageName"), new DataColumn("PageContent"),
                                new DataColumn("CreatedBy"),new DataColumn("ModifiedBy") });
                DataRow dr = dt.NewRow();                
                dr["PageName"] = dynamicPage.PageName.ToString();
                dr["PageContent"] = dynamicPage.PageContent.ToString();
                dr["CreatedBy"] = CurrentUserID;
                dr["ModifiedBy"] = CurrentUserID;
                dt.Rows.Add(dr);

                // open the destination data
                using (SqlConnection destinationConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {
                    try
                    {
                        // open the connection
                        destinationConnection.Open();
                        using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                        {
                            // column mappings
                            bulkCopy.ColumnMappings.Add("PageName", "PageName");
                            bulkCopy.ColumnMappings.Add("PageContent", "PageContent");
                            bulkCopy.ColumnMappings.Add("CreatedBy", "CreatedBy");
                            bulkCopy.ColumnMappings.Add("ModifiedBy", "ModifiedBy");
                            bulkCopy.DestinationTableName = "DynamicPages";
                            bulkCopy.WriteToServer(dt);
                            _dbMessage = DbMessage.Success;
                        }
                    }
                    catch (Exception ex)
                    {
                        _dbMessage = DbMessage.Failed;
                        LogException(ex);
                    }
                    finally
                    {
                        destinationConnection.Close();
                        destinationConnection.Dispose();
                    }
                }
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(_dbMessage, "Dynamic Page");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Failed);
            }
        }

        /// <summary>
        /// Delete dynamicPage by thread id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteDynamicPage(int dynamicPageID, out bool status)
        {
            try
            {
                _par = new object[,]
                    {
                      {"@TableName", Tables.DynamicPages.ToString(), null}
                    , {"@ColumnName", "DynamicPageID", null}
                    , {"@ColumnValue", dynamicPageID, null}
                    , {"@OutMessage", null, "Out"}        
                    };

                DeleteData(_par);
                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "Dynamic Page");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = false;
                return DbConstants.OutMessage(DbMessage.Failed, "DynamicPage");
            }
        }

        /// <summary>
        /// Get the list of dynamicPages
        /// </summary>        
        /// <returns>list of DynamicPages</returns>
        public List<DynamicPage> GetDynamicPages(int? dynamicPageID = null)
        {
            var dynamicPages = new List<DynamicPage>();
            try
            {
                _dataTable = GetData(Tables.DynamicPages, null, null);

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    dynamicPages.AddRange(from DataRow dataRow in _dataTable.Rows
                                          where (!dynamicPageID.HasValue || dynamicPageID.Value == GetIntegerValue(_dataTable, dataRow, "DynamicPageID"))
                                          select new DynamicPage
                                              {
                                                  DynamicPageID = GetIntegerValue(_dataTable, dataRow, "DynamicPageID"),
                                                  PageName = GetStringValue(_dataTable, dataRow, "PageName"),
                                                  PageContent = GetStringValue(_dataTable, dataRow, "PageContent"),
                                                  CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate")
                                              });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return dynamicPages;
        }

    }
}