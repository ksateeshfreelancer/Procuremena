﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.DTO;
using CLB.Enums.Database;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Caching;
using CLB.Enums;
using CLB.Util;
using CLB.BL.Administration;
using CLB.DP;

#endregion

namespace CLB.BL
{
    public sealed class AccountManager : BLBaseClass
    {
        #region Public Methods

        /// <summary>
        /// Authenticate user by username and password details and returns a valid message
        /// Used in administration database
        /// </summary>
        public string AuthenticateUser(User user, out DbMessage dbMessage)
        {
            try
            {
                _provider = new DataProviderFacade(dbType, CLB.Util.ConnectionStrings.ConnectionString);
                _par = new Object[,]
                    {
                        {"@Username", string.IsNullOrEmpty(user.Email) ? user.Mobile : user.Email, null}
                        , {"@Password", user.Password, null}
                        ,
                        {
                            "@IPAddress", HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ??
                                          HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"],
                            null
                        }
                        , {"@OutMessage", null, "Out"}
                    };

                _dataSet = _provider.ExecuteDataSet(StoredProcedures.SpAuthenticateUser, _par, CommandType.StoredProcedure);

                if (_dataSet == null || _dataSet.Tables.Count < 3)
                {
                    dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    return DbConstants.OutMessage(dbMessage);
                }

                if (_dataSet.Tables[0].Rows.Count == 0)
                {
                    dbMessage = DbMessage.CredentialsIncorrect;
                    return DbConstants.OutMessage(DbMessage.CredentialsIncorrect);
                }

                //get first row in result set 1 >> user details
                var myDataRow = _dataSet.Tables[0].Rows[0];
                var dtUserDetails = _dataSet.Tables[0];
                var dtAccessibleScreens = _dataSet.Tables[1];                
                var dtLoginInfo = _dataSet.Tables[2];

                /*                 
                 * Table 0 > User Details
                 * Table 1 > Accessible Screens / empty in-case of registered user                 
                 * Table 2 > LoginLog Details
                 */

                #region Status check for admin approval

                var status = GetEnumValue<Enums.Status>(dtUserDetails, myDataRow, "Status");
                if (status == Status.AdminApproval)
                {
                    dbMessage = DbMessage.CustomMessage;
                    return DbConstants.OutMessage(DbMessage.CustomMessage, MessageType.Error.ToString(), "Account not activated");
                }

                #endregion

                #region Subscription Check

                //validation check only for vendor.. logic written in SP
                if (!GetBooleanValue(dtUserDetails, myDataRow, "IsValidSubscription"))
                {
                    dbMessage = DbMessage.CustomMessage;
                    return DbConstants.OutMessage(DbMessage.CustomMessage, MessageType.Error.ToString(), "Subscription Expired. Please contact Administrator");
                }

                #endregion

                #region Single login validation

                //enable single login

                var sessionDetails = HttpRuntime.Cache[Utilities.Encrypt(myDataRow["UserID"])] as string;

                if (string.IsNullOrEmpty(sessionDetails))
                {
                    //store current user id, browser version and windows login username 
                    var sessionTimeOut = (HttpContext.Current == null || HttpContext.Current.Session == null)
                                             ? 20
                                             : HttpContext.Current.Session.Timeout;

                    //cache must be cleared and assigning a new value
                    HttpRuntime.Cache.Remove(Utilities.Encrypt(myDataRow["UserID"]));
                    HttpRuntime.Cache.Add(Utilities.Encrypt(myDataRow["UserID"]),
                                                  Utilities.Encrypt(myDataRow["UserID"]) + "," +
                                                  HttpContext.Current.Request.ServerVariables["REMOTE_PORT"] + "," +
                                                  HttpContext.Current.Request.Browser.Browser, null,
                                                  DateTime.Now.AddMinutes(sessionTimeOut),
                                                  Cache.NoSlidingExpiration, CacheItemPriority.Default, null);
                }
                else
                {
                    //split string to get user id, browser version and windows login username details
                    var array = sessionDetails.Split(',');
                    //check if same user is logging-in from same browser
                    if (array[1] == HttpContext.Current.Request.ServerVariables["REMOTE_PORT"] &&
                        array[2] == HttpContext.Current.Request.Browser.Browser)
                    {
                        //continue
                    }
                    else
                    {
                        //disable single login in dev environment
                        if (!bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
                        {
                            dbMessage = DbMessage.AlreadyLoggedIn;
                            return DbConstants.OutMessage(dbMessage);
                        }
                    }
                }

                #endregion

                List<Screen> screens = null;

                #region Bind Screens
                //Binding screens is applicable 
                if (dtAccessibleScreens != null && dtAccessibleScreens.Rows.Count > 0)
                {
                    //every user must have at least one screen
                    screens = new List<Screen>();
                    screens.AddRange(from DataRow dr in dtAccessibleScreens.Rows
                                     where GetStringValue(dtUserDetails, myDataRow, "Screens")
                                                        .Split('~')
                                                        .Contains(GetStringValue(dtAccessibleScreens, dr, "ScreenID"))
                                     where (GetEnumValue<Status>(dtAccessibleScreens, dr, "Status") == Status.Active)
                                     select new Screen
                                     {
                                         ScreenID = GetIntegerValue(dtAccessibleScreens, dr, "ScreenID"),
                                         ScreenName = GetStringValue(dtAccessibleScreens, dr, "ScreenName"),
                                         DisplayName = GetStringValue(dtAccessibleScreens, dr, "DisplayName"),
                                         Order = GetIntegerValue(dtAccessibleScreens, dr, "Order"),
                                         ShowInMenu = GetBooleanValue(dtAccessibleScreens, dr, "ShowInMenu"),
                                         IsAdminScreen = GetBooleanValue(dtAccessibleScreens, dr, "IsAdminScreen"),
                                         Status = GetEnumValue<CLB.Enums.Status>(dtAccessibleScreens, dr, "Status"),
                                         Category = GetEnumValue<MenuCategory>(dtAccessibleScreens, dr, "Category")
                                     });
                }

                #endregion

                //Store all user details in session/cache instead of storing each property in each session
                var userDetails = MapUserDetails(dtUserDetails, myDataRow, screens);

                #region Store user details in session/cookies

                HttpContext.Current.Session[SessionVariables.UserId] = Utilities.Encrypt(myDataRow["UserID"]);
                HttpContext.Current.Session[SessionVariables.CurrentUser] = userDetails;

                //create cookie object
                HttpCookie cookie = HttpContext.Current.Request.Cookies["Tekkispace"];

                if (cookie != null)
                {
                    /** Remove existing cookie **/
                    //Adding Expire Time of cookies before existing cookies time
                    cookie.Expires = DateTime.Now.AddDays(-1);
                    //Adding cookies to current web response
                    HttpContext.Current.Response.Cookies.Add(cookie);
                }
                else
                {
                    cookie = new HttpCookie("Tekkispace");
                }
                /** Add/override new cookie **/
                cookie["UserInfo"] = Utilities.Encrypt(userDetails);
                cookie.Expires = DateTime.Now.AddDays(5);
                HttpContext.Current.Response.Cookies.Add(cookie);

                #endregion

                #region Store LoginLog Id in cache - Used during logout

                if (dtLoginInfo != null && dtLoginInfo.Rows.Count > 0)
                {
                    //cache must be cleared and assigning a new value
                    HttpRuntime.Cache.Remove("LoginLogId-" + Utilities.Encrypt(userDetails.UserID));

                    //Set cache to expire after 20 minutes,i.e., the object expires 
                    //  and is removed from the cache 20 minutes after it is last accessed.
                    HttpRuntime.Cache.Add("LoginLogId-" + Utilities.Encrypt(userDetails.UserID),
                                          dtLoginInfo.Rows[0][0],
                                          null,
                                          Cache.NoAbsoluteExpiration,
                                          new TimeSpan(0, int.Parse(ConfigurationManager.AppSettings["CacheDuration"]), 0),
                                          CacheItemPriority.Default,
                                          null);
                }

                #endregion

                dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                return DbConstants.OutMessage((DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par)));
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("timeout"))
                {
                    dbMessage = DbMessage.Failed;
                    return Utilities.CustomMessage("Please check your internet connection and try again", MessageType.Error);
                }
                LogException(ex);
                dbMessage = DbMessage.Failed;
                return DbConstants.OutMessage(DbMessage.Failed);
            }
        }

        /// <summary>
        /// Method to save logout information upon logout
        /// </summary>
        /// <param name="loginLogId"></param>
        /// <param name="isClientDatabase"></param>
        /// <returns></returns>
        public DbMessage SaveLogoutInformation(int loginLogId)
        {
            return UpdateField(Tables.LoginLog, "LogoutDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "LoginLogID", loginLogId.ToString());
        }

        /// <summary>
        /// Method to change password for given user by userid
        /// </summary>
        /// <param name="user"></param>
        /// <param name="dbMessage"></param>
        /// <param name="isTransactionPassword"></param>
        /// <returns>Response</returns>
        public DbMessage ChangePassword(ChangePassword user)
        {
            _provider = new DataProviderFacade(dbType, CLB.Util.ConnectionStrings.ConnectionString);
            try
            {
                _par = new object[,]
                        {
                            {"@UserID", user.UserID, null}
                            , {"@Email", user.Email, null}
                            , {"@OldPassword", user.OldPassword, null}
                            , {"@NewPassword", user.NewPassword, null}
                            , {"@OutMessage", null, "Out"}
                        };

                _provider.ExecuteNonQuery(StoredProcedures.SpChangePassword, _par, CommandType.StoredProcedure);
                return (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                //if (dbMessage == DbMessage.OldPasswordIncorrect)
                //    return "Old Password is incorrect";
                //else if (dbMessage == DbMessage.PasswordChanged)
                //    return "Password changed successfully";
                //else if (dbMessage == DbMessage.Failed)
                //    return "Oops !!! some thing went wrong, please try again later";
                //else if (dbMessage == DbMessage.CredentialsIncorrect)
                //    return "Credentials Incorrect";
            }
            catch (Exception ex)
            {
                LogException(ex);
                //return "Oops !!! some thing went wrong, please try again later";
                return DbMessage.Failed;
            }
        }

        #endregion
    }
}
