﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 25-Dec-2015
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using CLB.BL.Administration;
using CLB.DP;
using System.Web;

#endregion

namespace CLB.BL
{
    public class UserManager : BLBaseClass
    {
        /// <summary>
        /// Save users
        /// </summary>        
        /// <returns>message to display</returns>
        public DbMessage SaveUser(User user, out int identity, out bool status)
        {
            status = true;

            try
            {
                var sbColumnNames = new StringBuilder();
                var sbColumnValues = new StringBuilder();

                var propertiestoSkip = new List<string>(new[] { "UserID", "UserDetails", "PasswordChangedDate" });

                //update user
                if (user.UserID > 0)
                {
                    propertiestoSkip.AddRange(new[] { "Password", "IsNewPassword", "InvalidLoginAttempts" });
                    BuildDynamicQuery(user, sbColumnNames, sbColumnValues, propertiestoSkip.ToArray(), false);
                    _par = new object[,]
                            {
                                {"@TableName", Tables.Users.ToString(), null}
                                , {"@ColumnNames", sbColumnNames.ToString().Replace("Role", "RoleID"), null}
                                , {"@ColumnValues", sbColumnValues.ToString()
                                      .Replace("CLB.DTO.Role", user.Role.RoleID.ToString()), null}
                                , {"@UniqueColumns", "Email,Mobile", null}
                                , {"@FilterColumnName", "UserID", null}
                                , {"@FilterColumnValue", user.UserID, null}
                                , {"@OutMessage", null, "Out"}
                            };

                    UpdateData(_par);
                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    identity = user.UserID;
                    status = (_dbMessage == DbMessage.Success);
                    if (status)
                        SaveUserDetails(user, false, out status);
                }
                else
                {
                    //insert user details
                    BuildDynamicQuery(user, sbColumnNames, sbColumnValues, propertiestoSkip.ToArray(), true);

                    _par = new object[,]
                        {
                            {"@Identity", null, "Out"}
                            , {"@TableName", Tables.Users.ToString(), null}
                            , {"@ColumnNames", sbColumnNames.ToString()
                                    .Replace("Role", "RoleID"), null}
                            , {"@ColumnValues", sbColumnValues.ToString()
                                    .Replace("CLB.DTO.Role", user.Role.RoleID.ToString()), null}
                            , {"@UniqueColumns", "Email,Mobile", null}
                            , {"@OutMessage", null, "Out"}
                        };

                    var result = SaveData(_par);
                    user.UserID = int.Parse(_par[0, 1].ToString());
                    identity = user.UserID;
                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    if (status)
                        SaveUserDetails(user, true, out status);
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
                identity = 0;
                status = (_dbMessage == DbMessage.Success);
                return DbMessage.Failed;
            }

            return _dbMessage;
        }

        /// <summary>
        /// Save users
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveUsers(List<User> users, out bool status)
        {
            status = true;
            foreach (User user in users)
            {
                _dbMessage = SaveUser(user, out _identity, out status);
            }
            return DbConstants.OutMessage(_dbMessage, "User(s)");
        }
        /// <summary>
        /// Save user details
        /// </summary>        
        /// <returns>message to display</returns>
        public string SaveUserDetails(User user, bool isInsert, out bool status)
        {            
            try
            {
                var sbColumnNames = new StringBuilder();
                var sbColumnValues = new StringBuilder();

                var propertiestoSkip = new List<string>(new[] { "Addresses" });
                user.UserDetails.UserID = user.UserID;
                //update user details
                /** DONOT REPLACE isInsert CONDITION WITH user.UserID > 0. UserID is always > 0 here **/
                if (!isInsert)
                {
                    propertiestoSkip.AddRange(new[] { "RegisteredIP" });
                    if (user.UserDetails.Country == null) propertiestoSkip.Add("Country");

                    BuildDynamicQuery(user.UserDetails, sbColumnNames, sbColumnValues, propertiestoSkip.ToArray(), false);

                    _par = new object[,]
                        {
                            {"@TableName", Tables.UserDetails.ToString(), null}
                            , {"@ColumnNames", sbColumnNames.ToString()
                                    .Replace("Country", "CountryID"), null}
                            , {"@ColumnValues", user.UserDetails.Country == null ? sbColumnValues.ToString() : sbColumnValues.ToString()
                                    .Replace("CLB.DTO.Country", user.UserDetails.Country.CountryID.ToString()), null}
                            , {"@UniqueColumns", "UserID", null}
                            , {"@FilterColumnName", "UserID", null}
                            , {"@FilterColumnValue", user.UserID, null}
                            , {"@OutMessage", null, "Out"}
                        };

                    UpdateData(_par);

                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    return DbConstants.OutMessage(_dbMessage, "User Details");
                }
                else
                {
                    if (user.UserDetails.Country == null)
                    {
                        user.UserDetails.Country = new Country
                        {
                            CountryID = Convert.ToInt32(HttpContext.Current.Session[SessionVariables.CountryId])
                        };
                    }
                    //insert user details
                    BuildDynamicQuery(user.UserDetails, sbColumnNames, sbColumnValues, propertiestoSkip.ToArray(), true);

                    _par = new object[,]
                    {
                        {"@TableName", Tables.UserDetails.ToString(), null}
                        , {"@ColumnNames", sbColumnNames.ToString()
                                    .Replace("Country", "CountryID"), null}
                            , {"@ColumnValues", sbColumnValues.ToString()
                                    .Replace("CLB.DTO.Country", user.UserDetails.Country.CountryID.ToString()), null}
                        , {"@UniqueColumns", "UserID", null}
                        , {"@OutMessage", null, "Out"}
                    };

                    SaveData(_par);
                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    return DbConstants.OutMessage(_dbMessage, "User Details");
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Failed);
            }
        }
        /// <summary>
        /// Reset user password
        /// </summary>        
        /// <returns>message to display</returns>
        public DbMessage ResetUserPassword(int userID, string newPassword, out bool status)
        {
            try
            {
                var sbColumnNames = new StringBuilder();
                var sbColumnValues = new StringBuilder();

                sbColumnNames.Append("[Password],[PasswordChangedDate],[IsNewPassword],[InvalidLoginAttempts]");
                sbColumnValues.Append("'" + newPassword + "',GETDATE(),1,0");

                _par = new object[,]
                        {
                            {"@TableName", Tables.Users.ToString(), null}
                            , {"@ColumnNames", sbColumnNames.ToString(), null}
                            , {"@ColumnValues", sbColumnValues.ToString(), null}
                            , {"@UniqueColumns", null, null}
                            , {"@FilterColumnName", "UserID", null}
                            , {"@FilterColumnValue", userID, null}
                            , {"@OutMessage", null, "Out"}
                        };

                UpdateData(_par);

                _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                status = (_dbMessage == DbMessage.Success);
                return _dbMessage;
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbMessage.Failed;
            }
        }
        /// <summary>
        /// Delete user by user id
        /// </summary>        
        /// <returns>message to display</returns>
        public string DeleteUser(int userID, out bool status)
        {
            try
            {
                _par = new Object[,]
                {
                    {"@TxnType", "DeleteUser", null}
                    , {"@UserID", userID, null}
                };
                _dataTable = GetDataFromMultipleTables(_par);

                if (_dataTable != null && _dataTable.Rows.Count > 0 && _dataTable.Rows[0]["Status"].ToString() == "SUCCESS")
                    _dbMessage = DbMessage.Delete;
                else
                    _dbMessage = DbMessage.ForeignKeyRelationship;
                status = (_dbMessage == DbMessage.Delete);
                return DbConstants.OutMessage(_dbMessage, "User", "User Data");
            }
            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.ForeignKeyRelationship, "User", "Other Data");
            }
        }
        /// <summary>
        /// Get the list of Users
        /// </summary>        
        /// <returns>list of Users</returns>
        public List<User> GetUsers(int? userID = null, int?[] role = null, string email = null, string mobile = null)
        {
            var users = new List<User>();
            try
            {
                _par = new Object[,]
                {
                    {"@TxnType", "GetUsers", null}
                    , {"@UserID", userID, null}
                    , {"@Email", email, null}
                    , {"@Mobile", mobile, null}
                    , {"@Role", role == null ? null : string.Join(",", role), null}
                };

                _dataTable = GetDataFromMultipleTables(_par);

                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    users.AddRange(from DataRow dataRow in _dataTable.Rows
                                   let userid = GetIntegerValue(_dataTable, dataRow, "UserID")
                                   where (!userID.HasValue || userID.Value == GetIntegerValue(_dataTable, dataRow, "UserID"))                                   
                                   select MapUserDetails(_dataTable, dataRow));
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return users;
        }       
    }
}