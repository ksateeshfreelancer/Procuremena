﻿#region Developer Note
/*
 * Created by       : Suresh
 * Created Date     : 16-Feb-2016
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using CLB.BL;
using CLB.BL.Administration;

#endregion

namespace CLB.BL
{
    public class ConfigManager : BLBaseClass
    {
        public string SaveDetails(Config user, bool isInsert, out bool status)
        {
            try
            {
                var sbColumnNames = new StringBuilder();
                var sbColumnValues = new StringBuilder();
                
                var propertiestoSkip = new List<string>(new[] { "" });
                user.ConfigurationID =1;
                //user.UserDetails.UserID = user.UserID;
                //update user details
                /** DONOT REPLACE isInsert CONDITION WITH user.UserID > 0. UserID is always > 0 here **/
                if (!isInsert)
                {
                   // propertiestoSkip.AddRange(new[] { "ConfigurationID" });
                    //if (!user.UserDetails.DOB.HasValue)
                    //propertiestoSkip.Add("DOB");

                    BuildDynamicQuery(user, sbColumnNames, sbColumnValues, propertiestoSkip.ToArray(), false);

                    _par = new object[,]
                        {
                            {"@TableName", Tables.Configurations.ToString(), null}
                            , {"@ColumnNames", sbColumnNames.ToString(), null}
                            , {"@ColumnValues", sbColumnValues.ToString(), null}
                            , {"@UniqueColumns", "Name", null}
                            , {"@FilterColumnName", "Name", null}
                            , {"@FilterColumnValue", user.Name, null}
                            , {"@OutMessage", null, "Out"}
                        };

                    UpdateData(_par);

                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    return DbConstants.OutMessage(_dbMessage, "Configuration");
                }
                else
                {
                    //insert user details
                    BuildDynamicQuery(user, sbColumnNames, sbColumnValues, propertiestoSkip.ToArray(), true);

                    _par = new object[,]
                    {
                        {"@TableName", Tables.Configurations.ToString(), null}
                        , {"@ColumnNames", sbColumnNames.ToString(), null}
                        , {"@ColumnValues", sbColumnValues.ToString(), null}
                        , {"@UniqueColumns", "ConfigurationID", null}
                        , {"@OutMessage", null, "Out"}
                    };

                    SaveData(_par);
                    _dbMessage = (DbMessage)Enum.Parse(typeof(DbMessage), GetOutputMessage(_par));
                    status = (_dbMessage == DbMessage.Success);
                    return DbConstants.OutMessage(_dbMessage, "Configuration Details");
                }
            }

            catch (Exception ex)
            {
                LogException(ex);
                status = (_dbMessage == DbMessage.Success);
                return DbConstants.OutMessage(DbMessage.Failed);
            }

        }
       /* public string SaveMeeting1(Config meeting, out bool status)
        {
            _dbMessage = Save_Update(meeting, Tables.Configurations, new[] { "ConfigurationID" }, out status,
              out _identity, "ConfigurationID", meeting.ConfigurationID > 0 ? "ConfigurationID" : null, meeting.ConfigurationID> 0 ? meeting.ConfigurationID.ToString() : null);
            return DbConstants.OutMessage(_dbMessage, "Meeting");
       }*/


        /// <summary>
        /// Get the list of Configs
        /// </summary>        
        /// <returns>list of Configs</returns>
        public List<Config> GetConfigs(int? configID = null)
        {
            var configs = new List<Config>();
            try
            {
                _dataTable = GetData(Tables.Configurations, null, null);
                if (_dataTable != null && _dataTable.Rows.Count > 0)
                {
                    configs.AddRange(from DataRow dataRow in _dataTable.Rows
                                      let configid = GetIntegerValue(_dataTable, dataRow, "ConfigurationID")
                                     where (!configID.HasValue || configID.Value == configid)
                                      select new Config
                                      {
                                          ConfigurationID = GetIntegerValue(_dataTable, dataRow, "ConfigurationID"),
                                          DisplayName = GetStringValue(_dataTable, dataRow, "DisplayName"),
                                          Name = GetStringValue(_dataTable, dataRow, "Name"),
                                          Value = GetDoubleValue(_dataTable, dataRow, "Value"),

                                          CreatedBy = GetStringValue(_dataTable, dataRow, "CreatedBy"),
                                          CreatedDate = GetDateTimeValue(_dataTable, dataRow, "CreatedDate"),
                                          ModifiedBy = GetStringValue(_dataTable, dataRow, "ModifiedBy"),
                                          ModifiedDate = GetDateTimeValue(_dataTable, dataRow, "ModifiedDate")
                                      });
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            return configs;
        }
    }
}

