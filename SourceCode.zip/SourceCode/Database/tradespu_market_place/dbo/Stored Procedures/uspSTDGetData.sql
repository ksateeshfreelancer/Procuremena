﻿

-- =============================================
-- Author:		Satya
-- Create date: 17-Jul-2013
-- Description:	GET data in table based on dynamic table name, column names and column values
-- =============================================
/*

declare @Message NVARCHAR(10)
exec uspGetData
'CommissionMarkups',
'Membership,Role,CreatedBy',
'%4%,4,0',null,
@OutMessage = @Message output
print @Message
*/
CREATE PROCEDURE [dbo].[uspSTDGetData]
(
@TableName VARCHAR(30),
@ColumnNames VARCHAR(1000) = NULL, 
@ColumnValues VARCHAR(1000) = NULL,
@ColumnsToRetrieve VARCHAR(200) = NULL,
@OutMessage VARCHAR(30) = 'Success' OUTPUT 
)
AS
BEGIN
IF ((@ColumnNames IS NOT NULL) AND (@ColumnValues IS NOT NULL))
BEGIN
DECLARE @Index INT = 1, @Condition NVARCHAR(500) = '', @tmpColumnName NVARCHAR(50) = '', 
		@tmpColumnNames NVARCHAR(1000) = @ColumnNames + ',', -- add a comma in the end to make the list loopable
		@tmpColumnValues NVARCHAR(1000) = @ColumnValues + ',',-- add a comma in the end to make the list loopable
		@GetQuery NVARCHAR(2000) = '';
		WHILE CHARINDEX(',', @tmpColumnNames) > 0
BEGIN
	--get column name in current index   
	IF ((@ColumnNames IS NOT NULL) AND (@ColumnValues IS NOT NULL))
	BEGIN
		SET @tmpColumnName = SUBSTRING(@tmpColumnNames, 0, CHARINDEX(',',@tmpColumnNames));
		IF (@GetQuery != '')		
			SET @GetQuery += ' AND '
		IF(CHARINDEX('%', SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues)))=0)		
			SET @GetQuery += 'T.[' + @tmpColumnName + '] = ''' + SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues))+'''';		
		ELSE        
			SET @GetQuery += 'T.[' + @tmpColumnName + '] like ''' + SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues))+'''';        	
	END
   --remove current column from columns csv and proceed to next iteration
   SET @tmpColumnNames = SUBSTRING(@tmpColumnNames, CHARINDEX(',',@tmpColumnNames) + 1, LEN(@tmpColumnNames) - @Index);
   SET @tmpColumnValues = SUBSTRING(@tmpColumnValues, CHARINDEX(',',@tmpColumnValues) + 1, LEN(@tmpColumnValues) - @Index);
END
END
DECLARE @QUERY NVARCHAR(3000) = ''
DECLARE @AdditionalColumns NVARCHAR(250) = 
--  add cratedby name, modified by name columns to query
' ,(SELECT U.FirstName + '' '' + U.LastName FROM UserDetails U WHERE U.UserID = T.CreatedBy) [CreatedBy1], ' + 
' (SELECT U.FirstName + '' '' + U.LastName FROM UserDetails U WHERE U.UserID = T.ModifiedBy) [ModifiedBy1] '

IF (@ColumnsToRetrieve IS NOT NULL)
BEGIN
	IF ((@ColumnNames IS NOT NULL) AND (@ColumnValues IS NOT NULL))
	BEGIN
		SET @QUERY='SELECT '+ @ColumnsToRetrieve + @AdditionalColumns + ', T.CreatedDate, T.ModifiedDate FROM ' + @TableName + ' T WHERE ' + @GetQuery
	END
	ELSE
	BEGIN
		SET @QUERY='SELECT ' + @ColumnsToRetrieve + @AdditionalColumns + ', T.CreatedDate, T.ModifiedDate FROM ' + @TableName + ' T'
	END
END

IF(@ColumnsToRetrieve IS NULL)
BEGIN
	IF ((@ColumnNames IS NOT NULL) AND (@ColumnValues IS NOT NULL))
	BEGIN
		SET @QUERY = 'SELECT T.*' + @AdditionalColumns + 'FROM ' + @TableName + ' T WHERE ' + @GetQuery
	END
	ELSE
	BEGIN
		SET @QUERY = 'SELECT  T.*' + @AdditionalColumns + 'FROM ' + @TableName + ' T'
	END
END
--select(@QUERY)
PRINT @Query
EXEC SP_EXECUTESQL @Query, N'@Message NVARCHAR(10) OUT', @OutMessage OUT
END



