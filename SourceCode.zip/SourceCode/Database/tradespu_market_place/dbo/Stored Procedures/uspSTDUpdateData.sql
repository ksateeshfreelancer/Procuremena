﻿

-- =============================================
-- Author:		Satya
-- Create date: 29-Jun-2013
-- Modified date: <>
-- Modified comments: <>
-- Description:	<Update data in table based on dynamic table name, column names and column values>
-- =============================================
/*
declare @Message VARCHAR(10)
exec uspUpdateData
'PopularRecharges',
'[OperatorName],[RechargeType],[Denomination],[TalkTime],[Validity],[Description]',
'Idea,6,100,86,0,Limited Period Offer','OperatorName',
'PopularRechargeID','100', @OutMessage = @Message output
print @Message
*/

CREATE PROCEDURE [dbo].[uspSTDUpdateData]
(
@TableName VARCHAR(30),
@ColumnNames VARCHAR(1000),
@ColumnValues VARCHAR(2000),
@UniqueColumns VARCHAR(200) = NULL,
@FilterColumnName VARCHAR(30),
@FilterColumnValue VARCHAR(50),
@OutMessage VARCHAR(30) = 'Success' OUTPUT 
)
AS
BEGIN

DECLARE @Index INT = 1, @Condition VARCHAR(500) = '', @tmpColumnName VARCHAR(50) = '', 
		@tmpColumnNames VARCHAR(1000) = @ColumnNames + ',', -- add a comma in the end to make the list loopable
		@tmpColumnValues VARCHAR(1000) = @ColumnValues + ',',-- add a comma in the end to make the list loopable
		@UpdateQuery VARCHAR(2000) = '';

--Loop ColumnNames, ColumnValues and build where condition
WHILE CHARINDEX(',', @tmpColumnNames) > 0
BEGIN
	--get column name in current index
   SET @tmpColumnName = SUBSTRING(@tmpColumnNames, 0, CHARINDEX(',',@tmpColumnNames));
   --trim first and last characters only if appended in braces
   IF (LEFT(@tmpColumnName, 1) = '[' AND RIGHT(@tmpColumnName, 1) = ']')
		SET @tmpColumnName = SUBSTRING(@tmpColumnName, 2, LEN(@tmpColumnName)-2);

   IF (@UpdateQuery != '')
		SET @UpdateQuery += ', '
   
   SET @UpdateQuery += '[' + @tmpColumnName + '] = ' + SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues));
   
   --check if at least one column should be unique
	IF @UniqueColumns IS NOT NULL
	BEGIN
	   --check if column name in current index is present in 
		IF((@UniqueColumns = @tmpColumnName) OR (@UniqueColumns LIKE @tmpColumnName + ',%') OR 
			(@UniqueColumns LIKE '%,'+@tmpColumnName+',%') OR (@UniqueColumns LIKE '%,'+ @tmpColumnName))
		BEGIN
			--skip 'AND' if first time
			IF(@Condition != '') SET @Condition += ' AND '
				
			IF (SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues)) = 'null')
				SET @Condition += '['+@tmpColumnName + '] IS NULL';
			ELSE
				SET @Condition += '[' + @tmpColumnName + '] = ' + 
									SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues));
		END  
	END
	--remove current column from columns csv and proceed to next iteration
   SET @tmpColumnNames = SUBSTRING(@tmpColumnNames, CHARINDEX(',',@tmpColumnNames) + 1, LEN(@tmpColumnNames) - @Index);
   SET @tmpColumnValues = SUBSTRING(@tmpColumnValues, CHARINDEX(',',@tmpColumnValues) + 1, LEN(@tmpColumnValues) - @Index);
END


IF(@Condition != '') SET @Condition += ' AND '
SET @Condition += ' [' + @FilterColumnName + '] != ' + @FilterColumnValue;


--build dynamic query
DECLARE @Query NVARCHAR(3000) = '';

	SET @Query = 'IF(Exists(SELECT * FROM [' + @TableName + '] WHERE [' + @FilterColumnName + '] = ' + @FilterColumnValue + '))
					BEGIN 
					'
	IF @UniqueColumns IS NOT NULL
		SET @Query += 'IF(NOT EXISTS(SELECT * FROM ' + @TableName + ' WHERE ' + @Condition + '))';	
			
	SET @Query += '
	BEGIN
		UPDATE ' + @TableName + '
		   SET ' +
			  @UpdateQuery + '
		 WHERE [' + @FilterColumnName + '] = ' + @FilterColumnValue+
		'  
		SELECT @Message = ''Success'' 
		END';
	IF @UniqueColumns IS NOT NULL
		SET @Query += '
			ELSE
			SELECT @Message = ''Duplicate'''
			
	SET @Query += '
		END
	  ELSE
		SELECT @Message = ''NotFound'''
--PRINT @Query
EXEC SP_EXECUTESQL @Query, N'@Message VARCHAR(10) OUT', @OutMessage OUT

END



