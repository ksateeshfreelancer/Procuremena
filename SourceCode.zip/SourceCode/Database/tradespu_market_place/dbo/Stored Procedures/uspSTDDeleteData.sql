﻿

-- =============================================
-- Author:		Satya
-- Create date: 28-Jun-2013
-- Modified date: <>
-- Modified comments: <>
-- Description:	<Delete data based on dynamic table name and columns>
-- =============================================
/*
declare @Message NVARCHAR(10)
exec uspDeleteData 'PopularRecharges', 'PopularRechargeID','1', @OutMessage = @Message output
print @Message
*/
CREATE PROCEDURE [dbo].[uspSTDDeleteData]
(
@TableName VARCHAR(30),
@ColumnName VARCHAR(30) = NULL,
@ColumnValue VARCHAR(50) = NULL,
@OutMessage VARCHAR(30) OUTPUT 
)
AS
BEGIN

SET @OutMessage = 'Delete'

DECLARE @Query NVARCHAR(1000) = ''

IF((@ColumnName IS NOT NULL) AND (@ColumnValue IS NOT NULL))
	BEGIN
		SET @Query=
		'IF(Exists(SELECT * FROM [' + @TableName + '] WHERE [' + @ColumnName + '] = ''' + @ColumnValue + '''))
		BEGIN
			DELETE FROM [' + @TableName + '] WHERE [' + @ColumnName + '] = ''' + @ColumnValue + '''
			 SELECT @Message = ''Delete''
			 END
		 ELSE
			SELECT @Message = ''NotFound'''
	END
ELSE
	BEGIN
		SET @Query=
		'DELETE FROM [' + @TableName + ']
		 SELECT @Message = ''Delete'''
	END	
	
print @Query

EXEC SP_EXECUTESQL @Query, N'@Message NVARCHAR(10) OUT', @OutMessage OUT

END



