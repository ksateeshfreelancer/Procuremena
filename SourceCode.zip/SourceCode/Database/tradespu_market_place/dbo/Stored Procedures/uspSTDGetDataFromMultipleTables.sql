﻿

-- =============================================
-- Author:		Satya
-- Create date: 03-Jan-2016
-- Description:	Get data from multiple tables
-- =============================================
/*
exec uspGetDataFromMultipleTables
'GetCommMarkup',null,null,null,null,null,null,null,58,null,null,1,
null,null,null
*/
CREATE PROCEDURE [dbo].[uspSTDGetDataFromMultipleTables]
	-- Add the parameters for the stored procedure here
	@TxnType VARCHAR(120),
	@ActiveOffers BIT = NULL,
	@BrandID INT = NULL,
	@CategoryID INT = NULL,
	@Email VARCHAR(50) = NULL,
	@Mobile VARCHAR(15) = NULL,
	@OrderIDs VARCHAR(1000) = NULL,
	@Password VARCHAR(50) = NULL,
	@ProductBookingStatus VARCHAR(50) = NULL,
	@ProductID BIGINT = NULL,
	@ProductIDs VARCHAR(1000) = NULL,
	@Role VARCHAR(20) = NULL,
	@SubCategoryID INT = NULL,
	@ThreadID BIGINT = NULL,
	@UserID INT = NULL,
	@FromDate DATE = NULL,
	@ToDate DATE = NULL,
	@Username VARCHAR(50) = NULL,	
	@Output VARCHAR(150) = 'Success' OUTPUT
AS
BEGIN

DECLARE @x XML, @y XML 
DECLARE @tempProductIDs VARCHAR(1000), @tempOrderIDs VARCHAR(1000)     
	IF(@TxnType = 'Brands')
	BEGIN
		SELECT B.*, SC.SubCategoryName, C.CategoryID, C.CategoryName,
		(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = B.CreatedBy) [CreatedBy1],  
		(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = B.ModifiedBy) [ModifiedBy1] 
		FROM Brands B 
			INNER JOIN SubCategory SC ON B.SubCategoryID = SC.SubCategoryID
			INNER JOIN Category C ON SC.CategoryID = C.CategoryID
		WHERE B.SubCategoryID = COALESCE(@SubCategoryID, B.SubCategoryID)
	END
	
	ELSE IF(@TxnType = 'CartItems')
	BEGIN
		--DECLARE @tempProductIDs VARCHAR(1000) 
		--SELECT @tempProductIDs = COALESCE(@Names + ', ', '') + CI.ProductID FROM CartItems CI WHERE CI.UserID = @UserID
		--Resultset1 - Cart Items
		SELECT CI.* FROM CartItems CI WHERE CI.UserID = @UserID
		--Resultset2 - Products
		SELECT PC.*, SC.SubCategoryName, C.CategoryName, B.BrandName FROM ProductCatalog PC 		
			INNER JOIN SubCategory SC ON PC.SubCategoryID = SC.SubCategoryID
			INNER JOIN Category C ON PC.CategoryID = C.CategoryID
			INNER JOIN Brands B ON PC.BrandID = B.BrandID
			WHERE PC.ProductID IN 
			(SELECT ProductID FROM CartItems WHERE UserID = @UserID)
		--Resultset3 - Products features list
		SELECT PF.*, F.FeatureName, F.FeatureValues, F.IsRange, F.[Status] FROM ProductFeatures PF 
			INNER JOIN Features F ON PF.FeatureID = F.FeatureID			
			WHERE PF.ProductID IN (SELECT ProductID FROM CartItems WHERE UserID = @UserID)
	END
	
	ELSE IF(@TxnType = 'DeleteUser')
	BEGIN
		BEGIN TRY
		BEGIN TRANSACTION
			DELETE FROM Referrals WHERE UserID = @UserID
			DELETE FROM UserDetails WHERE UserID = @UserID
			DELETE FROM UserBalanceLog WHERE UserID = @UserID
			DELETE FROM Users WHERE UserID = @UserID
			SELECT 'SUCCESS' [Status]
			COMMIT TRAN -- Transaction Success!	
		END TRY
		BEGIN CATCH
			ROLLBACK TRAN
			INSERT INTO DbErrorLog (ErrorNumber, ErrorSeverity, ErrorState, 
									ErrorProcedure, ErrorLine, ErrorMessage)
					SELECT ERROR_NUMBER(), ERROR_SEVERITY(),ERROR_STATE(),
							'uspSTDGetDataFromMultipleTables-DeleteUser',ERROR_LINE(), ERROR_MESSAGE()
			SELECT 'FAILED' [Status]
		END CATCH
	END

	ELSE IF(@TxnType = 'DeleteProduct')
	BEGIN
		BEGIN TRY
		BEGIN TRANSACTION
			IF(Exists(SELECT OrderID FROM Orders WHERE ProductID = @ProductID))
				SELECT 'FAILED' [Status]
			ELSE
			BEGIN				
				DELETE FROM ProductFeatures WHERE ProductID = @ProductID
				DELETE FROM ProductInventoryLog WHERE ProductID = @ProductID			
				DELETE FROM ProductPriceChangeLog WHERE ProductID = @ProductID
				DELETE FROM ProductReviews WHERE ProductID = @ProductID
				DELETE FROM ProductCatalog WHERE ProductID = @ProductID
				SELECT 'SUCCESS' [Status]
			END		
			COMMIT TRAN -- Transaction Success!		
		END TRY
		BEGIN CATCH
			ROLLBACK TRAN
			INSERT INTO DbErrorLog (ErrorNumber, ErrorSeverity, ErrorState, 
									ErrorProcedure, ErrorLine, ErrorMessage)
					SELECT ERROR_NUMBER(), ERROR_SEVERITY(),ERROR_STATE(),
							'uspSTDGetDataFromMultipleTables-DeleteProduct',ERROR_LINE(), ERROR_MESSAGE()
			SELECT 'FAILED' [Status]
		END CATCH
	END
	
	ELSE IF(@TxnType = 'Features')
	BEGIN
		SELECT F.*, SC.SubCategoryName, C.CategoryID, C.CategoryName,
		(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = F.CreatedBy) [CreatedBy1],  
		(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = F.ModifiedBy) [ModifiedBy1] 
		FROM Features F
			INNER JOIN SubCategory SC ON F.SubCategoryID = SC.SubCategoryID
			INNER JOIN Category C ON SC.CategoryID = C.CategoryID
		WHERE F.SubCategoryID = COALESCE(@SubCategoryID, F.SubCategoryID)
	END

	ELSE IF(@TxnType='DbErrorLog')
	BEGIN
		SELECT * FROM dbo.DbErrorLog 
		WHERE LogDate BETWEEN COALESCE(@FromDate,LogDate) AND COALESCE(@ToDate,GETDATE())
		ORDER BY LogDate DESC
	END

	ELSE IF(@TxnType='ErrorLog')
	BEGIN
		SELECT * FROM dbo.ErrorLog
		WHERE LogDate BETWEEN COALESCE(@FromDate,LogDate) AND COALESCE(@ToDate,GETDATE())
		ORDER BY LogDate DESC
	END

	ELSE IF(@TxnType='LoginLog')
	BEGIN
		SELECT LL.*,UD.FirstName +' '+UD.LastName as [UserName], U.Email, U.Mobile ,U.[RoleID]
		FROM dbo.LoginLog LL 
		INNER JOIN UserDetails UD ON LL.UserID = UD.UserID
		INNER JOIN Users U ON LL.UserID = U.UserID
		WHERE LoginDate BETWEEN COALESCE(@FromDate,LoginDate) AND COALESCE(@ToDate,GETDATE())
		ORDER BY LL.LoginDate DESC
	END	

	ELSE IF(@TxnType = 'Offers')
	BEGIN		
		--Resultset1 - Cart Items
		SELECT O.*, SC.SubCategoryName, C.CategoryName, B.BrandName, PC.ProductName FROM Offers O
			LEFT JOIN ProductCatalog PC ON PC.ProductID = O.ProductID
			LEFT JOIN SubCategory SC ON O.SubCategoryID = SC.SubCategoryID
			LEFT JOIN Category C ON O.CategoryID = C.CategoryID
			LEFT JOIN Brands B ON O.BrandID = B.BrandID
		WHERE 
			(@ActiveOffers IS NULL OR O.ValidTill > GETDATE())			
			/*
		--Resultset2 - Products
		SELECT PC.*, SC.SubCategoryName, C.CategoryName, B.BrandName FROM ProductCatalog PC 		
			INNER JOIN SubCategory SC ON PC.SubCategoryID = SC.SubCategoryID
			INNER JOIN Category C ON PC.CategoryID = C.CategoryID
			INNER JOIN Brands B ON PC.BrandID = B.BrandID
			WHERE PC.ProductID IN 
			(SELECT ProductID FROM Offers WHERE ValidTill < (CASE WHEN @ActiveOffers = 1 THEN GETDATE() ELSE ValidTill END))
			AND PC.SubCategoryID = COALESCE(@SubCategoryID, PC.SubCategoryID)
			AND PC.CategoryID = COALESCE(@CategoryID, PC.CategoryID)			
			AND PC.ProductID = COALESCE(@ProductID, PC.ProductID)*/
	END

	IF(@TxnType = 'Orders')
	BEGIN		
	--Convert csv values in role variable to list
		IF @OrderIDs IS NOT NULL
			SELECT @y = CAST('<A>'+ REPLACE(@OrderIDs,',','</A><A>')+ '</A>' AS XML)
		--Convert csv values in role variable to list
		IF @ProductBookingStatus IS NOT NULL
			SELECT @x = CAST('<A>'+ REPLACE(@ProductBookingStatus,',','</A><A>')+ '</A>' AS XML)
		--Convert list values in products variable to csv
		SELECT @tempProductIDs = COALESCE(@tempProductIDs + ', ', '') + CAST(O.ProductID AS VARCHAR(20)),
				@tempOrderIDs = COALESCE(@tempOrderIDs + ', ', '') + CAST(O.OrderID AS VARCHAR(20))
		FROM Orders O
			WHERE O.UserID = COALESCE(@UserID, O.UserID) 
				AND (@ProductBookingStatus IS NULL OR O.BookingStatus IN 
						(SELECT t.value('.', 'int') AS inVal FROM @x.nodes('/A') AS x(t)))
				AND (@OrderIDs IS NULL OR O.OrderNo IN (SELECT t.value('.', 'varchar(30)') AS inVal FROM @y.nodes('/A') AS x(t)))
				AND O.CreatedDate BETWEEN COALESCE(@FromDate, O.CreatedDate) AND COALESCE(@ToDate, O.CreatedDate)
		--Convert csv values in role variable to list
		SELECT @y = CAST('<A>'+ REPLACE(@tempProductIDs,',','</A><A>')+ '</A>' AS XML)
		SELECT @x = CAST('<A>'+ REPLACE(@tempOrderIDs,',','</A><A>')+ '</A>' AS XML)
		--Resultset1 - Orders
		SELECT O.*, U.Email, U.Mobile, UD.FirstName, UD.LastName,
		(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = O.CreatedBy) [CreatedBy1],  
		(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = O.ModifiedBy) [ModifiedBy1] 
		FROM Orders O
		INNER JOIN UserDetails UD ON O.UserID = UD.UserID
		INNER JOIN Users U ON O.UserID = U.UserID
		WHERE O.OrderID IN (SELECT t.value('.', 'varchar(30)') AS inVal FROM @x.nodes('/A') AS x(t))			
		--Resultset2 - Products
		SELECT PC.*, SC.SubCategoryName, C.CategoryName, B.BrandName FROM ProductCatalog PC 		
			INNER JOIN SubCategory SC ON PC.SubCategoryID = SC.SubCategoryID
			INNER JOIN Category C ON PC.CategoryID = C.CategoryID
			INNER JOIN Brands B ON PC.BrandID = B.BrandID
			WHERE PC.ProductID IN (SELECT t.value('.', 'bigint') AS inVal FROM @y.nodes('/A') AS x(t))
		--Resultset3 - Products features list
		SELECT PF.*, F.FeatureName, F.FeatureValues, F.IsRange, F.[Status] FROM ProductFeatures PF 
			INNER JOIN Features F ON PF.FeatureID = F.FeatureID			
			WHERE PF.ProductID IN (SELECT t.value('.', 'bigint') AS inVal FROM @y.nodes('/A') AS x(t))
		--Resultset4 - delivery status
		SELECT DS.* FROM DeliveryStatus DS INNER JOIN Orders O ON DS.OrderID = O.OrderID 
		WHERE O.OrderID IN (SELECT t.value('.', 'varchar(30)') AS inVal FROM @x.nodes('/A') AS x(t))			
		--Resultset5 - Delivery address
		SELECT DA.* FROM DeliveryAddress DA INNER JOIN Orders O ON DA.DeliveryAddressID = O.DeliveryAddressID
		WHERE O.OrderID IN (SELECT t.value('.', 'varchar(30)') AS inVal FROM @x.nodes('/A') AS x(t))
		--Resultset6 - User balance log
		SELECT UBL.* FROM UserBalanceLog UBL INNER JOIN Orders O ON UBL.ReferenceID = O.OrderID
		WHERE O.OrderID IN (SELECT t.value('.', 'varchar(30)') AS inVal FROM @x.nodes('/A') AS x(t))
	END

	ELSE IF(@TxnType = 'ProductCatalog')
	BEGIN
		--Convert csv values in role variable to list
		SELECT @x = CAST('<A>'+ REPLACE(@ProductIDs,',','</A><A>')+ '</A>' AS XML)
		--Resultset1 - Products
		SELECT PC.*, SC.SubCategoryName, C.CategoryName, B.BrandName FROM ProductCatalog PC
			INNER JOIN SubCategory SC ON PC.SubCategoryID = SC.SubCategoryID
			INNER JOIN Category C ON PC.CategoryID = C.CategoryID
			INNER JOIN Brands B ON PC.BrandID = B.BrandID
			WHERE 
			(@ProductIDs IS NULL OR 
				PC.ProductID IN (SELECT t.value('.', 'int') AS inVal FROM @x.nodes('/A') AS x(t)))
			AND PC.SubCategoryID = COALESCE(@SubCategoryID, PC.SubCategoryID)
			AND PC.CategoryID = COALESCE(@CategoryID, PC.CategoryID)
			AND PC.BrandID = COALESCE(@BrandID, PC.BrandID)
		--Resultset2 - Products features list
		SELECT PF.*, F.FeatureName, F.FeatureValues, F.IsRange, F.[Status] FROM ProductFeatures PF 
			INNER JOIN Features F ON PF.FeatureID = F.FeatureID			
			WHERE 
			(@ProductIDs IS NULL OR 
			PF.ProductID IN (SELECT t.value('.', 'int') AS inVal FROM @x.nodes('/A') AS x(t)))
	END

	ELSE IF(@TxnType = 'ProductFeatures')
	BEGIN
		--Convert csv values in role variable to list
		SELECT @x = CAST('<A>'+ REPLACE(@ProductIDs,',','</A><A>')+ '</A>' AS XML)		
		--Resultset2 - Products features list
		SELECT PF.*, F.FeatureName, F.FeatureValues, F.IsRange, F.[Status] FROM ProductFeatures PF 
			INNER JOIN Features F ON PF.FeatureID = F.FeatureID			
			WHERE (@ProductIDs IS NULL OR 
			PF.ProductID IN (SELECT t.value('.', 'int') AS inVal FROM @x.nodes('/A') AS x(t)))
	END
	
	ELSE IF(@TxnType = 'ProductReviews')
	BEGIN
		SELECT PR.*, U.Email, UD.FirstName, UD.LastName FROM ProductReviews PR 
		INNER JOIN UserDetails UD ON PR.UserID = UD.UserID
		INNER JOIN Users U ON PR.UserID = U.UserID
		WHERE PR.ProductID = @ProductID
	END

	ELSE IF(@TxnType = 'EmailQueries')
	BEGIN
		SELECT EQ.*, UD.FirstName, UD.LastName FROM EmailQueries EQ
		INNER JOIN UserDetails UD ON EQ.UserID = UD.UserID
		WHERE EQ.ThreadID = COALESCE(@ThreadID, EQ.ThreadID)
			AND EQ.UserID = COALESCE(@UserID, EQ.UserID)
	END
	
	ELSE IF(@TxnType = 'GetUsers')
	BEGIN
		SELECT U.*, UD.*, R.*, RA.*, RO.*,
		(SELECT USD.FirstName + ' ' + USD.LastName FROM UserDetails USD WHERE USD.UserID = U.CreatedBy) [CreatedBy1],  
		(SELECT USD.FirstName + ' ' + USD.LastName FROM UserDetails USD WHERE USD.UserID = U.ModifiedBy) [ModifiedBy1] 
		FROM Users U 
		INNER JOIN [Roles] RO ON U.RoleID = RO.RoleID
		INNER JOIN UserDetails UD ON U.UserID = UD.UserID 
		LEFT JOIN Referrals R ON U.UserID = R.UserID
		LEFT JOIN Ranking RA ON R.RankID = RA.RankID
		WHERE U.UserID = COALESCE(@UserID, u.UserID) AND
				((@Role IS NOT NULL AND U.[RoleID] IN 
					(SELECT t.value('.', 'int') AS inVal FROM @x.nodes('/A') AS x(t)))OR 
					(@Role IS NULL AND U.[RoleID] = U.[RoleID])) AND
				U.Email = COALESCE(@Email, u.Email) AND
				U.Mobile = COALESCE(@Mobile, u.Mobile)
	END

	ELSE IF(@TxnType='ForgotPassword')
	BEGIN
		IF(EXISTS(SELECT UserID FROM dbo.Users WHERE Email=@Username)) 
		BEGIN
		SET @UserID=(SELECT UserID FROM dbo.Users WHERE Email=@Username)
		   UPDATE dbo.Users SET [Password] = @Password, PasswordChangedDate = GETDATE(), 
			InvalidLoginAttempts = 0 WHERE UserID = @UserID
			SET @Output = 'Success'
		END	
		ELSE
			SET @Output = 'Failed'
    END	

	ELSE IF(@TxnType = 'SubCategory')
	BEGIN
		SELECT SC.*, C.CategoryID, C.CategoryName, C.DisplayOrder as [CDisplayOrder],
			(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = SC.CreatedBy) [CreatedBy1],  
			(SELECT U.FirstName + ' ' + U.LastName FROM UserDetails U WHERE U.UserID = SC.ModifiedBy) [ModifiedBy1] 
			FROM SubCategory SC 
				LEFT JOIN Category C ON SC.CategoryID = C.CategoryID
		WHERE SC.SubCategoryID = COALESCE(@SubCategoryID, SC.SubCategoryID)
	END

	ELSE IF(@TxnType = 'UserBalanceLog')
	BEGIN
		SELECT * FROM UserBalanceLog WHERE UserID = COALESCE(@UserID, UserID)
	END		
END



