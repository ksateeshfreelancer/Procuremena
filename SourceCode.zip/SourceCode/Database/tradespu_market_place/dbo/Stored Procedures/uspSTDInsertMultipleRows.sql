﻿

-- =============================================
-- Author:		<SRUJAN>
-- Create date: <13/08/2013>
-- Description:	<INSERT MULTIPLE ROWS>
-- =============================================

-- INSERT INTO MULTIPLE ROWS
/*
declare @Message VARCHAR(10)  
exec uspInsertMultipleRows  
'APIProviders',  
'[APIProviderName],[ServiceType],[Order],[Status],[CreatedBy],[ModifiedBy]',  
'''freeRecharge - PrepaidDTH'',''7'',''0'',''1'',''64'',''64''~''freeRecharge - PostpaidDTH'',''7'',''0'',''1'',''64'',''64''',  
@OutMessage = @Message output  
print @Message    
*/

CREATE PROCEDURE [dbo].[uspSTDInsertMultipleRows] 
 @TableName VARCHAR(30),   
 @ColumnNamesArray VARCHAR(1000),  
 @ColumnValuesArray VARCHAR(MAX),
 @OutMessage VARCHAR(30) = 'Success' OUTPUT   
AS
BEGIN

BEGIN TRY
	BEGIN TRANSACTION
	
	DECLARE @Index INT = 1, @Condition VARCHAR(500) = '', @tmpColumnName VARCHAR(50) = '',   
	  @tmpColumnValuesArray VARCHAR(MAX) = '', @tmpColumnValue VARCHAR(2000) = '',   
	  @tmpColumnValues VARCHAR(MAX) = '';-- add a comma in the end to make the list loopable  
	--build dynamic query  
	DECLARE @Query NVARCHAR(MAX) = '';  
	DECLARE @tmpIndex TINYINT = 0;  
	SET @tmpColumnValues = @ColumnValuesArray + '~'  
	  
	--Loop multiple rows  
	WHILE CHARINDEX('~', @tmpColumnValues) > 0  
	BEGIN 
	SET @tmpColumnValuesArray = SUBSTRING(@tmpColumnValues, 0, CHARINDEX('~',@tmpColumnValues));

	SET @Query += '
	INSERT INTO '+@TableName+' ('+@ColumnNamesArray+') VALUES('+@tmpColumnValuesArray+')';

	SET @tmpColumnValues = SUBSTRING(@tmpColumnValues, CHARINDEX('~',@tmpColumnValues) + 1, LEN(@tmpColumnValues) - @Index);
	END

	SET @Query += '  
		SELECT @Message = ''Success''';

	PRINT(@Query)
	EXEC SP_EXECUTESQL @Query, N'@Message VARCHAR(10) OUT', @OutMessage OUT
	COMMIT TRAN
	SET @OutMessage='Success'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	INSERT INTO DbErrorLog (ErrorNumber, ErrorSeverity, ErrorState, 
							ErrorProcedure, ErrorLine, ErrorMessage)
			SELECT ERROR_NUMBER(), ERROR_SEVERITY(),ERROR_STATE(),
					'uspInsertMultipleRows',ERROR_LINE(), ERROR_MESSAGE()
	SET @OutMessage='Failed'
END CATCH
END



