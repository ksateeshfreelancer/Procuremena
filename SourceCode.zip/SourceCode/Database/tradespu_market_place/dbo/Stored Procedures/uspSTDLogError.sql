﻿

-- =============================================
-- Author:		Satya
-- Create date: 1-Jul-2013
-- Modified date: <>
-- Modified comments: <>
-- Description:	<STORED PROCECURE TO SAVE ERRORS>
-- =============================================
CREATE PROCEDURE [dbo].[uspSTDLogError]		
	@Page	VARCHAR(100),
	@Method	VARCHAR(200),
	@ErrorMessage VARCHAR(1000),
	@DetailedMessage VARCHAR(3000),	
	@IPAddress VARCHAR(15),	
	@UserID		INT = NULL
AS
BEGIN
	INSERT INTO ErrorLog
                (Page
                , Method
                , ErrorMessage
                , DetailedMessage                
                , IPAddress
                , UserID)
	VALUES     (@Page
                , @Method
                , @ErrorMessage
                , @DetailedMessage                
                , @IPAddress
                , @UserID)
	
END

SET ANSI_NULLS OFF



