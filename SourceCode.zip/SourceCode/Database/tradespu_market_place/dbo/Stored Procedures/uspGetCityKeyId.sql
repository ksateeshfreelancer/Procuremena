﻿
-- =============================================
-- Author:		Satya
-- Create date: 2-Jan-2014
-- Description:	Check if City exists by City name. If so, return Citykeyid else insert new row
-- =============================================
/*
declare @tmpCityKeyId int
EXEC uspGetAreaKeyId 'Malkajgiri', 0, 2, 1,@tmpCityKeyId OUTPUT
SELECT @tmpCityKeyId
*/
CREATE PROCEDURE [dbo].[uspGetCityKeyId]
(	
	@CityName VARCHAR(50),
	@PIN CHAR(6) = NULL,	
	@CreatedBy INT,
	@CityKeyId INT OUTPUT
)
AS
BEGIN

IF @PIN IS NULL SET @PIN = ''

	--check if area with this name already exists
	IF EXISTS(SELECT * FROM City WHERE CityName = @CityName)
		SELECT TOP 1 @CityKeyId = CityKeyId FROM City WHERE CityName = @CityName
	ELSE
	BEGIN
		--insert new area details to areas table and get the areakeyid
		SELECT TOP 1 @CityKeyId = (CityKeyId + 1) FROM City ORDER BY CityKeyId DESC
		INSERT INTO City (CityName, CityId, IsAlias, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
			VALUES (@CityName, @CityKeyId, 0, @CreatedBy, GETDATE(), @CreatedBy, GETDATE()) 
		SET @CityKeyId = @@IDENTITY
	END	
END

