﻿

-- =============================================  
-- Author:  SATYA  
-- Create date: 29-Jul-2013  
-- Description: Update multiple rows/multiple columns  

/** 
--UPDATE SINGLE ROW SINGLE COLUMN 
declare @Message VARCHAR(10)  
exec uspUpdateMultipleRows  
'PopularRecharges',  
'OperatorName',  
'Idea',  
'PopularRechargeID','100', @OutMessage = @Message output  
print @Message  
  
-- UPDATE MULTIPLE ROWS SINGLE COLUMN 
declare @Message VARCHAR(10)  
exec uspUpdateMultipleRows  
'PopularRecharges',  
'OperatorName',  
'Idea~Airtel~Voda',  
'PopularRechargeID','100,101,102', @OutMessage = @Message output  
print @Message  
  
-- UPDATE SINGLE ROW MULTIPLE COLUMNS 
declare @Message VARCHAR(10)  
exec uspUpdateMultipleRows  
'PopularRecharges',  
'OperatorName,RechargeType,Denomination',  
'Idea,2,100',  
'PopularRechargeID','100', @OutMessage = @Message output  
print @Message  
  
-- UPDATE MULTIPLE ROWS MULTIPLE COLUMNS 
declare @Message VARCHAR(10)  
exec uspUpdateMultipleRows  
'ServiceswiseBalance',  
'Balance,BalanceAlert',  
'10000.00,1000.00~12000.00,1000.00~11000.00,1000.00~15000.00,1000.00~19000.00,1000.00~20000.00,1000.00~16000.00,2000.00',  
'BalanceID','1,2,3,4,5,6,7', @OutMessage = @Message output  
print @Message 
**/  
  
-- =============================================  
  
CREATE PROCEDURE [dbo].[uspSTDUpdateMultipleRows]  
 -- Add the parameters for the stored procedure here  
 @TableName VARCHAR(30),   
 @ColumnNames VARCHAR(500),  
 @ColumnValuesArray VARCHAR(MAX),
 @FilterColumnName VARCHAR(100),  
 @FilterColumnValues VARCHAR(500),   
 @OutMessage VARCHAR(30) = 'Success' OUTPUT   
AS  
BEGIN  

BEGIN TRY
	BEGIN TRANSACTION	
	DECLARE @Index INT = 1, @Condition VARCHAR(500) = '', @tmpColumnName VARCHAR(50) = '',   
	  @tmpColumnValuesArray VARCHAR(MAX) = '', @tmpColumnValue VARCHAR(2000) = '',   
	  @tmpColumnNames VARCHAR(1000) = '', -- add a comma in the end to make the list loopable  
	  @tmpColumnValues VARCHAR(MAX) = '',-- add a comma in the end to make the list loopable  
	  @tmpFilterColumnValues VARCHAR(MAX) = @FilterColumnValues + ',', @UpdateQuery VARCHAR(2000) = '';  
	--build dynamic query  
	DECLARE @Query NVARCHAR(MAX) = '';  
	DECLARE @tmpIndex TINYINT = 0;  
	SET @tmpColumnValues = @ColumnValuesArray + '~'  
	  
	--Loop multiple rows  
	WHILE CHARINDEX(',', @tmpFilterColumnValues) > 0  
	BEGIN   
	 SET @tmpColumnValuesArray = SUBSTRING(@tmpColumnValues, 0, CHARINDEX('~',@tmpColumnValues)) + ',';   
	 --reset column names to start from beginning  
	 SET @tmpColumnNames = @ColumnNames + ','   
	   
	 --Loop ColumnNames, ColumnValues and build where condition   
	 WHILE CHARINDEX(',', @tmpColumnNames) > 0  
	 BEGIN   
	  --get column name in current index  
		SET @tmpColumnName = SUBSTRING(@tmpColumnNames, 0, CHARINDEX(',',@tmpColumnNames));  
		SET @tmpColumnValue = SUBSTRING(@tmpColumnValuesArray, 0, CHARINDEX(',',@tmpColumnValuesArray));  
	      
		IF (@UpdateQuery != '')  
	   SET @UpdateQuery += ', '  
	      
		 SET @UpdateQuery += '[' + @tmpColumnName + '] = ' + @tmpColumnValue;  
	       
	  SET @tmpIndex += 1   
	  --remove current column from columns csv and proceed to next iteration  
		SET @tmpColumnNames = SUBSTRING(@tmpColumnNames, CHARINDEX(',',@tmpColumnNames) + 1, LEN(@tmpColumnNames) - @Index);      
		SET @tmpColumnValuesArray = SUBSTRING(@tmpColumnValuesArray, CHARINDEX(',',@tmpColumnValuesArray) + 1, LEN(@tmpColumnValuesArray) - @Index);      
	 END  
	   
	 IF(@Condition != '') SET @Condition += ' AND '  
	 SET @Condition += ' [' + @FilterColumnName + '] != ' +   
		SUBSTRING(@tmpFilterColumnValues, 0, CHARINDEX(',',@tmpFilterColumnValues));  
	      
	 SET @Query += '
	 UPDATE ' + @TableName + ' SET ' + @UpdateQuery + ' WHERE [' +   
		 @FilterColumnName + '] = ' + SUBSTRING(@tmpFilterColumnValues, 0, CHARINDEX(',',@tmpFilterColumnValues));  
	 set @UpdateQuery=''  
	 --remove current filter column from columns csv and proceed to next iteration  
	 SET @tmpColumnValues = SUBSTRING(@tmpColumnValues, CHARINDEX('~',@tmpColumnValues) + 1, LEN(@tmpColumnValues) - @Index);  
	 SET @tmpFilterColumnValues = SUBSTRING(@tmpFilterColumnValues, CHARINDEX(',',@tmpFilterColumnValues) + 1, LEN(@tmpFilterColumnValues) - @Index);  
	  
	END   
	  
	SET @Query += '  
		SELECT @Message = ''Success''';  
	       
		 --PRINT @Query  
	EXEC SP_EXECUTESQL @Query, N'@Message VARCHAR(10) OUT', @OutMessage OUT  
	COMMIT TRAN
	SET @OutMessage='Success'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	INSERT INTO DbErrorLog (ErrorNumber, ErrorSeverity, ErrorState, 
							ErrorProcedure, ErrorLine, ErrorMessage)
			SELECT ERROR_NUMBER(), ERROR_SEVERITY(),ERROR_STATE(),
					'uspUpdateMultipleRows',ERROR_LINE(), ERROR_MESSAGE()
	SET @OutMessage='Failed'
END CATCH
END



