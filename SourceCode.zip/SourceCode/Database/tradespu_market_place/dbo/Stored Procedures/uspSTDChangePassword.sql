﻿

-- =============================================
-- Author:		Satya
-- Create date: 2-Jul-2013
-- Modified date: <>
-- Modified comments: <>
-- Description:	<SP to Change Password>
-- =============================================
--select * from tbl_users
--BD588F5F88EAA29A0E4F620B03800765
CREATE PROCEDURE [dbo].[uspSTDChangePassword]
(
    @UserID INT = NULL, -- userid or email is required
    @Email VARCHAR(50) = NULL, -- userid or email is required
    @OldPassword VARCHAR(50),
	@NewPassword VARCHAR(50),
	@OutMessage VARCHAR(30) OUTPUT 
	)
AS

BEGIN

DECLARE @tempOldPassword VARCHAR(50), @tmpUserID INT = 0

IF(@UserID IS NOT NULL)
	SET @tmpUserID = @UserID
IF(@Email IS NOT NULL)
	SELECT @tmpUserID = [UserID] FROM Users WHERE (Email = @Email)

IF @tmpUserID > 0
BEGIN
	SELECT @tempOldPassword = [Password] FROM Users WHERE ([UserID] = @tmpUserID)	

	IF (@tempOldPassword = @OldPassword)
        BEGIN
		UPDATE Users SET
			  [Password] = @NewPassword
			  ,PasswordChangedDate = GETDATE()
			  ,InvalidLoginAttempts = 0
		 WHERE      (UserID = @UserID OR Email = @Email)
        
        SET @OutMessage = 'PasswordChanged'        
        END
	ELSE
		SET @OutMessage = 'OldPasswordIncorrect'
END
ELSE
        SET @OutMessage = 'NotFound'
END



