﻿
-- =============================================
-- Author:		Satya
-- Create date: 29-Jun-2013
-- Modified date: <>
-- Modified comments: <>
-- Description:	<Insert data in to a table based on dynamic table name, column names and column values>
-- =============================================
/*
declare @Message VARCHAR(10),@IdentityOut INT
exec uspInsertData
'RoomAmenities',
'[PropertyId],[RoomTypeId],[AmenitiesDetailId],[CreatedBy],[CreatedDate],[ModifiedBy],[ModifiedDate]',
'2,3,3,1,GETDATE(),1,GETDATE()', @OutMessage = @Message output,@Identity = @IdentityOut output
print @Message print @IdentityOut
*/
CREATE PROCEDURE [dbo].[uspSTDInsertData]
(
@TableName VARCHAR(30),
@ColumnNames VARCHAR(1000),
@ColumnValues VARCHAR(2000),
@UniqueColumns VARCHAR(200) = NULL,
@OutMessage VARCHAR(30) OUTPUT,
@Identity INT = NULL OUTPUT 
)
AS
BEGIN

DECLARE @Index INT = 1, @Condition VARCHAR(500) = '', @tmpColumnName VARCHAR(50) = '', 
		@tmpColumnNames VARCHAR(1000) = @ColumnNames + ',', -- add a comma in the end to make the list loopable
		@tmpColumnValues VARCHAR(1000) = @ColumnValues + ','-- add a comma in the end to make the list loopable
		
--check if at least one column should be unique
IF @UniqueColumns IS NOT NULL
BEGIN
--Loop ColumnNames, ColumnValues and build where condition
WHILE CHARINDEX(',', @tmpColumnNames) > 0
BEGIN
	--get column name in current index
   SET @tmpColumnName = SUBSTRING(@tmpColumnNames, 0, CHARINDEX(',',@tmpColumnNames));
   --trim first and last characters only if appended in braces
	IF (LEFT(@tmpColumnName, 1) = '[' AND RIGHT(@tmpColumnName, 1) = ']')
		SET @tmpColumnName = SUBSTRING(@tmpColumnName, 2, LEN(@tmpColumnName)-2);
   --check if column name in current index is present in 
	IF((@UniqueColumns = @tmpColumnName) OR (@UniqueColumns LIKE @tmpColumnName + ',%') OR 
		(@UniqueColumns LIKE '%,'+@tmpColumnName+',%') OR (@UniqueColumns LIKE '%,'+ @tmpColumnName))
	BEGIN
		--skip 'AND' if first time
		IF(@Condition != '') SET @Condition += ' AND '
			
		IF (SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues)) = 'null')
			SET @Condition += '['+@tmpColumnName + '] IS NULL';
		ELSE
			SET @Condition += '['+@tmpColumnName + '] = ' + 
								SUBSTRING(@tmpColumnValues, 0, CHARINDEX(',',@tmpColumnValues));
	END  
	--remove current column from columns csv and proceed to next iteration
   SET @tmpColumnNames = SUBSTRING(@tmpColumnNames, CHARINDEX(',',@tmpColumnNames) + 1, LEN(@tmpColumnNames) - @Index);
   SET @tmpColumnValues = SUBSTRING(@tmpColumnValues, CHARINDEX(',',@tmpColumnValues) + 1, LEN(@tmpColumnValues) - @Index);
END
END

--build dynamic query
DECLARE @Query NVARCHAR(3500) = '';
--print @TableName
--print 'and'
--print @ColumnNames 
--print 'and'
--print @ColumnValues 
	IF @UniqueColumns IS NOT NULL
		SET @Query = 'IF(NOT EXISTS(SELECT * FROM ' + @TableName + ' WHERE ' + @Condition + '))';	
			
	SET @Query += '
	BEGIN
		INSERT INTO ' + @TableName + ' (' + @ColumnNames + ')
		VALUES     (' + @ColumnValues + ')
		SELECT @Message = ''Success''
		SELECT @IdentityOut = SCOPE_IDENTITY() 
	END	';
	
	IF @UniqueColumns IS NOT NULL
		SET @Query += '
		ELSE
		BEGIN
			SELECT @Message = ''Duplicate''
			SELECT @IdentityOut = 0
		END	'
--SELECT @Query	
EXEC SP_EXECUTESQL @Query, N'@Message VARCHAR(10) OUT,@IdentityOut INT OUT', @OutMessage OUT,@Identity OUT

END


