﻿

-- =============================================
-- Author:		Satya
-- Create date: 1-Jul-2013
-- Description:	Perform CRUD operations on users and userdetails tables
-- =============================================

CREATE PROCEDURE [dbo].[uspSTDUsers]
(
@UserID INT, 
@Parent INT = 0,
@IsNewPassword bit=0,
@Membership TINYINT=0,
@Role TINYINT=0,
@Password VARCHAR(250)=NULL, 
@Companyname VARCHAR(50)=NULL,
@Address VARCHAR(150)=NULL,
@PAN VARCHAR(10)=NULL,
@Pincode VARCHAR(6)=null,
@Telephone VARCHAR(15)=null,
@Status TINYINT = NULL, 

@FirstName VARCHAR(50)=NULL,
@LastName VARCHAR(50)=NULL,
@Gender INT=0,
@DOB VARCHAR(10)=NULL,  
@Email VARCHAR(50)=NULL,
@AlternateEmail VARCHAR(50)=NULL,
@Mobile VARCHAR(15)=NULL,
@AlternateMobile VARCHAR(15)=NULL,
@City VARCHAR(30)=NULL,  
@State VARCHAR(50)=NULL,
@RegisteredIP VARCHAR(20)=NULL,
@TxnType VARCHAR(10)=NULL,

@CreatedBy INT=0,
@ModifiedBy INT=0,
@OutMessage VARCHAR(30) OUTPUT 
)
AS
BEGIN

DECLARE @tmpEmail VARCHAR(50), @tmpMobile VARCHAR(10), @ReturnID INT

--Check if User already exists
IF(EXISTS(SELECT UserID FROM Users WHERE (UserID = @UserID)) AND @TxnType = 'Update')
	BEGIN
		--Retrieve respective email and mobile of User
		SELECT @tmpEmail = [Email] FROM Users WHERE (UserID = @UserID)
		SELECT @tmpMobile = [Mobile] FROM Users WHERE (UserID = @UserID)
		--Check if User with same Name 
		IF(Exists(SELECT UserID FROM Users WHERE 
			(([Email] = @Email AND @Email != @tmpEmail) OR 
			([Mobile] = @Mobile AND @Mobile != @tmpMobile))))			
			SET @OutMessage = 'Duplicate'
		ELSE
			BEGIN
			--Start the Try Block..
				BEGIN TRY 
				-- Start the transaction..
					BEGIN TRANSACTION 					 
					--Update User if User already exists
						UPDATE [Users]
						   SET  [RoleID]=@Role
							   ,[Status]=@Status
							   ,[ModifiedBy]=@ModifiedBy
							   ,[ModifiedDate]=GETDATE()
						 WHERE      (UserID = @UserID)
						UPDATE [UserDetails]
						   SET  [FirstName]=@FirstName
								   ,[LastName]=@LastName
								   ,[Gender]=@Gender
								   ,[DOB]=@DOB								   
								   ,[Telephone]=@Telephone
								   ,[Address]=@Address
								   ,[Pincode]=@Pincode
								   ,[City]=@City
								   ,[State]=@State 
								   ,[RegisteredIP]=@RegisteredIP
								   ,[ModifiedBy]=@ModifiedBy
								   ,[ModifiedDate]=GETDATE()
						 WHERE [UserID] = @UserID							
					select @UserID
					COMMIT TRAN -- Transaction Success!	
					SET @OutMessage = 'Success'
				END TRY
				BEGIN CATCH
					IF @@TRANCOUNT > 0
						ROLLBACK TRAN --RollBack in case of Error						
						-- Log exception details 
						PRINT 'Error Message is : '+ ERROR_MESSAGE()
						INSERT INTO DbErrorLog (ErrorNumber, ErrorSeverity, ErrorState, 
										ErrorProcedure, ErrorLine, ErrorMessage)
						SELECT ERROR_NUMBER(), ERROR_SEVERITY(),ERROR_STATE(),
								ERROR_PROCEDURE(),ERROR_LINE(), ERROR_MESSAGE()
						SET @OutMessage = 'Failed'
				END CATCH
			END
	END
--Check if new User is Inserted
ELSE IF(@TxnType = 'INSERT')
	BEGIN
		--Check if User with same Name Already Exists
		IF(Exists(SELECT [UserID] FROM Users WHERE (Email = @Email OR Mobile = @Mobile)))
			SET @OutMessage = 'Duplicate'
		--Insert User if User doesnot exist
		ELSE 
		--Start the Try Block..
				 BEGIN TRY 
				-- Start the transaction..
				 BEGIN TRANSACTION 
						INSERT INTO [Users]
							   ([IsNewPassword] 
							   ,[Email]
							   ,[Mobile]
							   ,[Password]
							   ,[InvalidLoginAttempts]
							   ,[RoleID]
							   ,[Status]
							   ,[CreatedBy] 
							   ,[CreatedDate]
							   ,[ModifiedBy] )
						 VALUES
							   (@IsNewPassword
							   ,@Email
							   ,@Mobile
							   ,@Password
							   ,0
							   ,@Role
							   ,@Status
							   ,@CreatedBy
							   ,GETDATE()
							   ,@ModifiedBy)

						SELECT @ReturnID = SCOPE_IDENTITY()
						select @ReturnID
						
						INSERT INTO [UserDetails]
								   ([UserID]
								   ,[FirstName]
								   ,[LastName]
								   ,[Gender]
								   ,[DOB]								   								   
								   ,[Telephone]
								   ,[City]
								   ,[State]
								   ,[Address]
								   ,[Pincode]
								   ,[RegisteredIP]
								   ,[CreatedBy]
								   ,[CreatedDate]
								   ,[ModifiedBy])
							 VALUES
								   (@ReturnID
								   ,@FirstName
								   ,@LastName
								   ,@Gender
								   ,@DOB								   
								   ,@Telephone
								   ,@City
							       ,@State
							       ,@Address
							       ,@Pincode
								   ,@RegisteredIP
								   ,@CreatedBy
								   ,GETDATE()
								   ,@ModifiedBy)
           COMMIT TRAN -- Transaction Success!	
           SET @OutMessage = 'Success'
				END TRY
				BEGIN CATCH
					IF @@TRANCOUNT > 0
						ROLLBACK TRAN --RollBack in case of Error
						-- Log exception details 						
						PRINT 'Error Message is : '+ ERROR_MESSAGE()
						INSERT INTO DbErrorLog (ErrorNumber, ErrorSeverity, ErrorState, 
										ErrorProcedure, ErrorLine, ErrorMessage)
						SELECT ERROR_NUMBER(), ERROR_SEVERITY(),ERROR_STATE(),
								ERROR_PROCEDURE(),ERROR_LINE(), ERROR_MESSAGE()
						SET @OutMessage = 'Failed'
				END CATCH
			
	END
--Check if Existing User is Deleted
ELSE IF(@TxnType = 'DELETE')
	BEGIN
		--** DONOT DELETE TRANSACTION LOG **
        --DELETE FROM LoginLog WHERE UserID = @UserID		        
		--DELETE FROM UserDetails WHERE UserID = @UserID
		UPDATE Users SET [Status] = 2 WHERE UserID = @UserID		
		--DELETE FROM Users WHERE UserID = @UserID		
		SET @OutMessage = 'Delete'
	END
ELSE 
	SET @OutMessage = 'NotFound'
		
END



