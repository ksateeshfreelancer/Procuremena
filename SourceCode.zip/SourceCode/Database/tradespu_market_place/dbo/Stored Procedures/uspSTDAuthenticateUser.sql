﻿

-- =============================================
-- Author:		Satya
-- Create date: 1-Jul-2013
-- Description:	Authenticate user 
-- =============================================
/*
select * from users
declare @Message varchar(100)
exec uspSTDAuthenticateUser
'9999999999','704E8810D5608A2C4EA8D89CD9C43462','127.0.0.1',@OutMessage = @Message output
print @Message 
*/
CREATE PROCEDURE [dbo].[uspSTDAuthenticateUser]  
(  
	@Username VARCHAR(50),  
	@Password VARCHAR(50),
	@IPAddress VARCHAR(20),
	@OutMessage VARCHAR(30) OUTPUT 
)    
AS  
DECLARE @tmpUserID INT, @tmpLoginStatus TINYINT = 0, @tmpIsNewPassword BIT, @tmpInvalidLoginAttempts TINYINT
--Login_Status = 1 - Succcess
--Login_Status = 2 - Inactive
--Login_Status = 3 - Failed
BEGIN
	--select * from Users
	--Check if User exists with given username
	IF(Exists(SELECT UserID FROM Users WHERE Email = @Username OR Mobile = @Username))
	BEGIN
		--store user id to log user details
		SELECT @tmpUserID = UserID FROM Users WHERE (Email = @Username OR Mobile = @Username)		
		
		SELECT @tmpInvalidLoginAttempts = InvalidLoginAttempts FROM Users WHERE 
									(Email = @Username OR Mobile = @Username)
		--Check if user exceeded invalid login attempts
		IF(@tmpInvalidLoginAttempts >= 5)
			SET @OutMessage = 'Locked'
		ELSE
		BEGIN	
			--Check if User exists with given username and password
			IF(Exists(SELECT UserID FROM Users WHERE (Email = @Username OR Mobile = @Username) AND ([Password] = @Password)))
			BEGIN			
				IF((SELECT [Status] FROM Users WHERE (Email = @Username OR Mobile = @Username) AND [Password] = @Password) = 0)
				BEGIN
					SET @OutMessage = 'InActive'
					SET @tmpLoginStatus = 2
				END
				ELSE
				BEGIN
					
					--store isnewpassword status to @tmpIsNewPassword
					SET @tmpLoginStatus = 1
					SELECT @tmpIsNewPassword = IsNewPassword FROM Users WHERE (Email = @Username OR Mobile = @Username)
					
					--result set 1 > get user details
					SELECT U.UserID, U.Email, U.Mobile,UD.*, U.PasswordChangedDate, 
						U.IsNewPassword, U.RoleID, R.Screens, U.[Status], 
						U.AmountBalance, RE.CurrentPointBalance, RE.IsLeftOrg, 
						RE.LeftOrgCount, RE.[Level], RE.RefID, RE.RightOrgCount, RE.TotalPointsEarned,
						RA.RankID, RA.RankName
					FROM Users U INNER JOIN UserDetails UD ON U.UserID = UD.UserID
					 INNER JOIN [Roles] R ON R.RoleID = U.RoleID
					 LEFT JOIN Referrals RE ON U.UserID = RE.UserID
					 LEFT JOIN Ranking RA ON RE.RankID = RA.RankID
					 WHERE (U.Email = @Username OR U.Mobile = @Username) AND (U.Password = @Password)
					
					--result set 2 > get all screens					 
					SELECT * FROM Screens					

					 SET @OutMessage = 'Success'
					 
					 --Reset invalid login attempts to 0
					 UPDATE Users SET InvalidLoginAttempts = 0 WHERE (Email = @Username OR Mobile = @Username)
						
					 --Update record only if IsNewPassword is true
					 IF(@tmpIsNewPassword = 1)
					 BEGIN
						UPDATE Users SET IsNewPassword = 0 WHERE (Email = @Username OR Mobile = @Username)
						SET @OutMessage = 'PasswordChanged'
					END
				END
			END
			ELSE	
			BEGIN				
				SET @tmpInvalidLoginAttempts += 1
				IF (SELECT [RoleID] FROM Users WHERE Email = @Username OR Mobile = @Username) != 1
					UPDATE Users SET InvalidLoginAttempts = @tmpInvalidLoginAttempts WHERE 
					(Email = @Username OR Mobile = @Username)
				SET @OutMessage = 'CredentialsIncorrect'
				SET @tmpLoginStatus = 3
			END
		END
	END
	ELSE
	BEGIN
		SET @OutMessage = 'CredentialsIncorrect'
		SET @tmpLoginStatus = 3
	END
END

IF(@tmpUserID IS NOT NULL AND @tmpLoginStatus > 0)
BEGIN
	INSERT INTO [LoginLog]
           (UserID
           ,[LoginDate]
           ,[IPAddress]
           ,[Status])
	     VALUES (@tmpUserID, GETDATE(), @IPAddress, @tmpLoginStatus)

	--Result set 3
	SELECT * FROM LoginLog WHERE LoginLogID = SCOPE_IDENTITY()
END



