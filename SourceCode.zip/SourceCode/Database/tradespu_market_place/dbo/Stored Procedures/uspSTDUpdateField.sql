﻿

-- =============================================
-- Author:		Satya
-- Create date: 28-Jun-2013
-- Modified date: <>
-- Modified comments: <>
-- Description:	<Update single field in a table based on dynamic table name and column>
-- =============================================
/*
declare @Message VARCHAR(10)
exec uspUpdateField 'Users', 'Services','1,2,3,4,5,6,7', 'Username','dfdf', @OutMessage = @Message output
print @Message
*/
CREATE PROCEDURE [dbo].[uspSTDUpdateField]
(
@TableName VARCHAR(30),
@ColumnName VARCHAR(30),
@ColumnValue VARCHAR(50),
@FilterColumnName VARCHAR(30),
@FilterColumnValue VARCHAR(50),
@OutMessage VARCHAR(30) OUTPUT 
)
AS
BEGIN

SET @OutMessage = 'Success'

DECLARE @Query NVARCHAR(1000) = 
'IF(Exists(SELECT * FROM [' + @TableName + '] WHERE [' + @FilterColumnName + '] = ''' + @FilterColumnValue + '''))
BEGIN
	UPDATE [' + @TableName + '] SET [' + @ColumnName + '] = ''' + @ColumnValue + ''' WHERE [' + @FilterColumnName + '] = ''' + @FilterColumnValue + '''
	SELECT @Message = ''Success''
END
ELSE
	SELECT @Message = ''NotFound'''


print @query
EXEC SP_EXECUTESQL @Query, N'@Message VARCHAR(10) OUT', @OutMessage OUT

END



