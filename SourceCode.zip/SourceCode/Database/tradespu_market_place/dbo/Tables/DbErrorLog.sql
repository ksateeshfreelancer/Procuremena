﻿CREATE TABLE [dbo].[DbErrorLog] (
    [DbErrorLogID]   INT            IDENTITY (1, 1) NOT NULL,
    [ErrorNumber]    INT            NOT NULL,
    [ErrorSeverity]  TINYINT        NOT NULL,
    [ErrorState]     TINYINT        NOT NULL,
    [ErrorProcedure] VARCHAR (50)   NOT NULL,
    [ErrorLine]      INT            NOT NULL,
    [ErrorMessage]   VARCHAR (1000) NOT NULL,
    [LogDate]        SMALLDATETIME  CONSTRAINT [DF_DbErrorLog_LogDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_DbErrorLog] PRIMARY KEY CLUSTERED ([DbErrorLogID] ASC)
);

