﻿CREATE TABLE [dbo].[Country] (
    [CountryID]    TINYINT       IDENTITY (1, 1) NOT NULL,
    [CountryName]  VARCHAR (50)  NOT NULL,
    [IsActive]     BIT           CONSTRAINT [DEF_Country_IsActive] DEFAULT ((1)) NOT NULL,
    [CreatedBy]    INT           NOT NULL,
    [CreatedDate]  SMALLDATETIME CONSTRAINT [DF_Country_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]   INT           NOT NULL,
    [ModifiedDate] SMALLDATETIME CONSTRAINT [DF_Country_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Country] PRIMARY KEY CLUSTERED ([CountryID] ASC)
);

