﻿CREATE TABLE [dbo].[SubCategory] (
    [SubCategoryID]   INT           IDENTITY (100, 1) NOT NULL,
    [CategoryID]      INT           NOT NULL,
    [SubCategoryName] VARCHAR (100) NOT NULL,
    [DisplayOrder]    TINYINT       CONSTRAINT [DF_SubCategory_DisplayOrder] DEFAULT ((0)) NOT NULL,
    [Status]          BIT           CONSTRAINT [DEF_SubCategory_Status] DEFAULT ((1)) NOT NULL,
    [CreatedBy]       INT           NOT NULL,
    [CreatedDate]     SMALLDATETIME CONSTRAINT [DF_SubCategory_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]      INT           NOT NULL,
    [ModifiedDate]    SMALLDATETIME CONSTRAINT [DF_SubCategory_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_SubCategory] PRIMARY KEY CLUSTERED ([SubCategoryID] ASC),
    CONSTRAINT [FK_SubCategory_Category] FOREIGN KEY ([CategoryID]) REFERENCES [dbo].[Category] ([CategoryID])
);

