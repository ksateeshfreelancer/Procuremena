﻿CREATE TABLE [dbo].[EmailQueries] (
    [QueryID]       BIGINT         IDENTITY (1, 1) NOT NULL,
    [UserID]        INT            NOT NULL,
    [ThreadID]      BIGINT         NOT NULL,
    [IsParent]      BIT            NOT NULL,
    [IsRead]        BIT            NOT NULL,
    [QueryCategory] TINYINT        NOT NULL,
    [Subject]       VARCHAR (100)  NOT NULL,
    [Body]          VARCHAR (2000) NOT NULL,
    [CreatedDate]   SMALLDATETIME  NOT NULL,
    CONSTRAINT [PK_EmailQueries] PRIMARY KEY CLUSTERED ([QueryID] ASC),
    CONSTRAINT [FK_EmailQueries_Users] FOREIGN KEY ([UserID]) REFERENCES [dbo].[Users] ([UserID])
);

