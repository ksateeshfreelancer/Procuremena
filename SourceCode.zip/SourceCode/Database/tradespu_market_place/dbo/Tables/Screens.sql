﻿CREATE TABLE [dbo].[Screens] (
    [ScreenID]      INT           NOT NULL,
    [ScreenName]    VARCHAR (100) NOT NULL,
    [DisplayName]   VARCHAR (100) NOT NULL,
    [Order]         TINYINT       NOT NULL,
    [Category]      TINYINT       NOT NULL,
    [Status]        TINYINT       NOT NULL,
    [Accessibility] BIT           CONSTRAINT [DF_Screens_Accessibility] DEFAULT ((1)) NOT NULL,
    [CreatedBy]     INT           NOT NULL,
    [CreatedDate]   SMALLDATETIME CONSTRAINT [DF_Screens_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]    INT           NOT NULL,
    [ModifiedDate]  SMALLDATETIME CONSTRAINT [DF_Screens_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Screens] PRIMARY KEY CLUSTERED ([ScreenID] ASC)
);

