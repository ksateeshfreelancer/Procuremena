﻿CREATE TABLE [dbo].[Category] (
    [CategoryID]   INT           IDENTITY (100, 1) NOT NULL,
    [CategoryName] VARCHAR (100) NOT NULL,
    [DisplayOrder] TINYINT       CONSTRAINT [DF_Category_DisplayOrder] DEFAULT ((0)) NOT NULL,
    [Status]       BIT           CONSTRAINT [DEF_Category_Status] DEFAULT ((1)) NOT NULL,
    [CreatedBy]    INT           NOT NULL,
    [CreatedDate]  SMALLDATETIME CONSTRAINT [DF_Category_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]   INT           NOT NULL,
    [ModifiedDate] SMALLDATETIME CONSTRAINT [DF_Category_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Category] PRIMARY KEY CLUSTERED ([CategoryID] ASC)
);

