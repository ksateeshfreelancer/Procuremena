﻿CREATE TABLE [dbo].[Brands] (
    [BrandID]       INT           IDENTITY (1, 1) NOT NULL,
    [GroupID]       INT           NOT NULL,
    [SubCategoryID] INT           NOT NULL,
    [BrandName]     VARCHAR (100) NOT NULL,
    [Status]        BIT           CONSTRAINT [DF_Brand_Status] DEFAULT ((1)) NOT NULL,
    [CreatedBy]     INT           NOT NULL,
    [CreatedDate]   SMALLDATETIME CONSTRAINT [DF_Brand_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]    INT           NOT NULL,
    [ModifiedDate]  SMALLDATETIME CONSTRAINT [DF_Brand_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Brand] PRIMARY KEY CLUSTERED ([BrandID] ASC),
    CONSTRAINT [FK_Brand_SubCategory] FOREIGN KEY ([SubCategoryID]) REFERENCES [dbo].[SubCategory] ([SubCategoryID])
);

