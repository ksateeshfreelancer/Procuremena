﻿CREATE TABLE [dbo].[CartItems] (
    [CartItemID]   INT           IDENTITY (1, 1) NOT NULL,
    [UserID]       INT           NOT NULL,
    [ProductID]    BIGINT        CONSTRAINT [DF_Table_1_Status] DEFAULT ((1)) NOT NULL,
    [Quantity]     TINYINT       NOT NULL,
    [CreatedBy]    INT           NOT NULL,
    [CreatedDate]  SMALLDATETIME CONSTRAINT [DF_CartItems_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]   INT           NOT NULL,
    [ModifiedDate] SMALLDATETIME CONSTRAINT [DF_CartItems_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_CartItems] PRIMARY KEY CLUSTERED ([CartItemID] ASC),
    CONSTRAINT [FK_CartItems_ProductCatalog] FOREIGN KEY ([ProductID]) REFERENCES [dbo].[ProductCatalog] ([ProductID]),
    CONSTRAINT [FK_CartItems_Users] FOREIGN KEY ([UserID]) REFERENCES [dbo].[Users] ([UserID])
);

