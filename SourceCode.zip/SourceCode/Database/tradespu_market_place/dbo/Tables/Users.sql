﻿CREATE TABLE [dbo].[Users] (
    [UserID]               INT             IDENTITY (1, 1) NOT NULL,
    [Email]                VARCHAR (50)    NOT NULL,
    [Mobile]               VARCHAR (10)    NOT NULL,
    [Password]             VARCHAR (50)    NOT NULL,
    [PasswordChangedDate]  DATETIME        NULL,
    [IsNewPassword]        BIT             CONSTRAINT [DF_Users_IsNewPassword] DEFAULT ((0)) NULL,
    [InvalidLoginAttempts] TINYINT         CONSTRAINT [DF_Users_InvalidLoginAttempts] DEFAULT ((0)) NOT NULL,
    [RoleID]               INT             NOT NULL,
    [Status]               TINYINT         NOT NULL,
    [AmountBalance]        DECIMAL (10, 2) CONSTRAINT [DF_Users_AmountBalance] DEFAULT ((0.00)) NOT NULL,
    [CreatedBy]            INT             NOT NULL,
    [CreatedDate]          SMALLDATETIME   CONSTRAINT [DF_Users_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]           INT             NOT NULL,
    [ModifiedDate]         SMALLDATETIME   CONSTRAINT [DF_Users_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [pk_Users_uid] PRIMARY KEY CLUSTERED ([UserID] ASC),
    CONSTRAINT [FK_Users_Roles] FOREIGN KEY ([RoleID]) REFERENCES [dbo].[Roles] ([RoleID])
);

