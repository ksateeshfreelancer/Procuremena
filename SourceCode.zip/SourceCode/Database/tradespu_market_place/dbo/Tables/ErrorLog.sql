﻿CREATE TABLE [dbo].[ErrorLog] (
    [ErrorLogID]      INT            IDENTITY (1, 1) NOT NULL,
    [Page]            VARCHAR (100)  NOT NULL,
    [Method]          VARCHAR (200)  NOT NULL,
    [ErrorMessage]    VARCHAR (1000) NOT NULL,
    [DetailedMessage] VARCHAR (4000) NOT NULL,
    [IPAddress]       VARCHAR (15)   NOT NULL,
    [LogDate]         SMALLDATETIME  CONSTRAINT [DF_ErrorLog_LogDate] DEFAULT (getdate()) NOT NULL,
    [UserID]          INT            NULL,
    CONSTRAINT [PK_ErrorLog] PRIMARY KEY CLUSTERED ([ErrorLogID] ASC)
);

