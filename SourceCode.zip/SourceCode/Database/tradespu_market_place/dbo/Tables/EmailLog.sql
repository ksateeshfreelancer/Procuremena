﻿CREATE TABLE [dbo].[EmailLog] (
    [EmailLogID]  INT            IDENTITY (1, 1) NOT NULL,
    [Emails]      VARCHAR (500)  NOT NULL,
    [Subject]     VARCHAR (100)  NOT NULL,
    [Body]        VARCHAR (2000) NOT NULL,
    [CreatedDate] SMALLDATETIME  CONSTRAINT [DF_EmailLog_CreatedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_EmailLog] PRIMARY KEY CLUSTERED ([EmailLogID] ASC)
);

