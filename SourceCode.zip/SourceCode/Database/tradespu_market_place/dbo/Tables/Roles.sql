﻿CREATE TABLE [dbo].[Roles] (
    [RoleID]       INT            IDENTITY (100, 1) NOT NULL,
    [RoleName]     VARCHAR (50)   NOT NULL,
    [Level]        TINYINT        NOT NULL,
    [Screens]      NVARCHAR (500) NULL,
    [CreatedBy]    INT            NOT NULL,
    [CreatedDate]  SMALLDATETIME  CONSTRAINT [DF_Roles_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]   INT            NOT NULL,
    [ModifiedDate] SMALLDATETIME  CONSTRAINT [DF_Roles_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Roles] PRIMARY KEY CLUSTERED ([RoleID] ASC)
);

