﻿CREATE TABLE [dbo].[City] (
    [CityKeyID]    SMALLINT      IDENTITY (100, 1) NOT NULL,
    [CityName]     VARCHAR (50)  NOT NULL,
    [CityID]       SMALLINT      NOT NULL,
    [IsAlias]      BIT           CONSTRAINT [DEF_City_IsAlias] DEFAULT ((0)) NOT NULL,
    [CreatedBy]    INT           NOT NULL,
    [CreatedDate]  SMALLDATETIME CONSTRAINT [DF_City_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]   INT           NOT NULL,
    [ModifiedDate] SMALLDATETIME CONSTRAINT [DF_City_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_City] PRIMARY KEY CLUSTERED ([CityKeyID] ASC)
);

