﻿CREATE TABLE [dbo].[SMSLog] (
    [SMSLogID]    INT           IDENTITY (1, 1) NOT NULL,
    [PhoneNos]    VARCHAR (100) NOT NULL,
    [Message]     VARCHAR (200) NOT NULL,
    [CreatedDate] SMALLDATETIME CONSTRAINT [DF_SMSLog_CreatedDate] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_SMSLog] PRIMARY KEY CLUSTERED ([SMSLogID] ASC)
);

