﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PopupMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Hide export buttons as there is not requirement
        var ibtnExcelExport = (ImageButton)ContentPlaceHolder1.FindControl("ibtnExcelExport");
        if (ibtnExcelExport != null) ibtnExcelExport.Visible = false;

        var ibtnPDFExport = (ImageButton)ContentPlaceHolder1.FindControl("ibtnPDFExport");
        if (ibtnPDFExport != null) ibtnPDFExport.Visible = false;

        var ibtnWordExport = (ImageButton)ContentPlaceHolder1.FindControl("ibtnWordExport");
        if (ibtnWordExport != null) ibtnWordExport.Visible = false;
    }
}
