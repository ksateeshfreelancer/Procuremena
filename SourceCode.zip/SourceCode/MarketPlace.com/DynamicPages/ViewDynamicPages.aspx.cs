﻿using CLB.BL;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class DynamicPages_ViewDynamicPages : BasePage
{
    #region Global Variables

    private DynamicPageManager _dynamicPageManager = new DynamicPageManager();

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        var pageNames = _dynamicPageManager.GetData(Tables.DynamicPages, null, null, "DynamicPageID,PageName");
        ViewState["PageNames"] = pageNames;
        Utilities.BindControl(pageNames, "PageName", "DynamicPageID", rblPages);
        divContent.Visible = false;
    }
    protected void btnNewPage_Click(object sender, EventArgs e)
    {
        if (rblPages.Items.Count > 5)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("A maximum of only 5 pages can be added.", CLB.Enums.MessageType.Info);
            divContent.Visible = false;
            return;
        }
        divContent.Visible = true;
        btnDelete.Visible = false;
        ViewState["ID"] = null;
        rblPages.SelectedIndex = -1;
        txtPageContent.InnerHtml = txtpageName.Text = "";
    }
    protected void rblPages_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rblPages.SelectedIndex > -1)
        {
            divContent.Visible = true;
            btnDelete.Visible = true;
            var dynamicPage = _dynamicPageManager.GetDynamicPages(int.Parse(rblPages.SelectedValue)).FirstOrDefault();
            ViewState["ID"] = dynamicPage.DynamicPageID;
            txtpageName.Text = dynamicPage.PageName;
            txtPageContent.InnerHtml = HttpUtility.HtmlDecode(dynamicPage.PageContent);
        }
        else
        {
            btnDelete.Visible = false;
            divContent.Visible = false;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtPageContent.InnerHtml.Length > 100000)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Description cannot exceed 100000 characters (" + txtPageContent.InnerHtml.Length + ")", MessageType.Warning);
            return;
        }

        var pageNames = ViewState["PageNames"] as DataTable;

        if (pageNames != null && pageNames.Rows.Count > 0)
        {
            var drArray = pageNames.Select("PageName='" + txtpageName.Text + "'");
            if (drArray != null && drArray.Length > 1)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Page Name already exists.", MessageType.Warning);
                return;
            }
        }

        var dynamicPage = new DynamicPage
        {
            DynamicPageID = ViewState["ID"] == null ? 0 : int.Parse(ViewState["ID"].ToString()),
            PageContent = txtPageContent.InnerHtml.Trim(),
            PageName = txtpageName.Text.Trim()
        };
        lblStatusMessage.InnerHtml = _dynamicPageManager.SaveDynamicPage(dynamicPage, out _status);

        if (_status)
        {
            var data = _dynamicPageManager.GetData(Tables.DynamicPages, null, null, "DynamicPageID,PageName");
            ViewState["PageNames"] = data;
            Utilities.BindControl(data, "PageName", "DynamicPageID", rblPages);
            divContent.Visible = false;
            btnDelete.Visible = false;
            ClearControls(this);
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = _dynamicPageManager.DeleteDynamicPage(int.Parse(rblPages.SelectedValue), out _status);
        if (_status)
        {
            var data = _dynamicPageManager.GetData(Tables.DynamicPages, null, null, "DynamicPageID,PageName");
            ViewState["PageNames"] = data;
            Utilities.BindControl(data, "PageName", "DynamicPageID", rblPages);
            divContent.Visible = false;
            btnDelete.Visible = false;
            ClearControls(this);
        }
    }
}