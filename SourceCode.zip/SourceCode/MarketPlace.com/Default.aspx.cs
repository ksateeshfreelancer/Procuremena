﻿using CLB.DTO;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Text;

public partial class _Default : System.Web.UI.Page
{
    RedirectPage _redirectPage = new RedirectPage();
    public BasePage _base = new BasePage();
    public string slideCategoryString;    

    protected void Page_Load(object sender, EventArgs e)
    {
        string temp = Utilities.Encrypt("Data Source=.; Initial Catalog=tradespu_MARKET_PLACE_UAT; UID=sa;pwd=sa123456SA;Connect Timeout=200; pooling='true'; Max Pool Size=2000;");
        AjaxService objService = new AjaxService();
        Session["CategoryHierarchies"] = objService.GetCategoryHierarchyList();
        var x = objService.GetMenuCategories();
        slideCategoryString = GetPopularCategoryDiv();       
    }

    private string GetPopularCategoryDiv()
    {
        Dictionary<string, Category> catImagesInfo = (Dictionary<string, Category>)Session["CategoryImagesInfo"];

        #region
        /*<!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p1.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Industrial Plant & Machine</a>
                                            </figure>
                                        </li>
                                        <!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p2.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Electronics & Electrical</a>
                                            </figure>
                                        </li>
                                        <!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p3.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Building & Construction</a>
                                            </figure>
                                        </li>
                                        <!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p4.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Industrial Suppliers</a>
                                            </figure>
                                        </li>
                                        <!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p1.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Industrial Plant & Machine</a>
                                            </figure>
                                        </li>
                                        <!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p2.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Electronics & Electrical</a>
                                            </figure>
                                        </li>
                                        <!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p3.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Building & Construction</a>
                                            </figure>
                                        </li>
                                        <!-- start single product item -->
                                        <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/p4.jpg' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='#'>Industrial Supplier22222s</a>
                                            </figure>
                                        </li>*/

        #endregion

        StringBuilder sb = new StringBuilder();
        foreach (var eachObj in catImagesInfo)
        {
            string liItem = @"<!--start single product item-->
                                            <li>
                                            <figure>
                                                <a class='aa-product-img' href='#'>
                                                    <img src = 'images/" + eachObj.Value.ImagePath + @"' alt='ProcureMENA' class='img-responsive'></a>
                                                <a class='aa-add-card-btn' href='/AllProductCategories?CategoryID=" + eachObj.Value.CategoryID + @"'>" + eachObj.Value.CategoryName + @"</a>
                                            </figure>
                                        </li>";
            sb = sb.Append(liItem).AppendLine();
        }

        string htmlString = @"<div class='tab - pane fade in active' id='popular'>
                                      <ul class='aa-product-catg aa-popular-slider'>" + sb.ToString() +
                                    @"</ul>
                                    <a class='aa-browse-btn' href='AllProductCategories' target='_newTab'>More<span class='fa fa-long-arrow-right'></span></a>
                                </div>";
        return htmlString;
    }   
}