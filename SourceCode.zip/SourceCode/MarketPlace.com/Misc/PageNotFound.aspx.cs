﻿using CLB.BL;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PageNotFound : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
}