﻿#region "Developer Notes"
// Program         :   Default
//Objective        :  
//*******************************************************************************************************************
//Date           Version         Developed/Modified By               Reasons for mods
//*******************************************************************************************************************
//07/01/2012    1.0             Developed By: PRAMOD
//*******************************************************************************************************************
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Security;
using System.Drawing;

using System.Web.UI.HtmlControls;
//using SchoolMgtSystemBAL;

public partial class Error : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        //HtmlMeta meta = new HtmlMeta();

        //meta.HttpEquiv = "Refresh";

        ////meta.Content = Convert.ToString(Session.Timeout * 60) + ";url=Default.aspx";
        //meta.Content = 5 + ";url=Default.aspx";

        //this.Page.Header.Controls.Add(meta);  

        //Exception ex = Server.GetLastError();
        //if (ex != null)
        //{
        //    lblError.Text = "Error Details: " + ex.Message;
        //}

    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        //HtmlMeta meta = new HtmlMeta();

        //meta.HttpEquiv = "Refresh";

        ////meta.Content = Convert.ToString(Session.Timeout * 60) + ";url=Default.aspx";
        //meta.Content = 5 + ";url=Default.aspx";

        //this.Page.Header.Controls.Add(meta);  

        Exception ex = Server.GetLastError();
        if (ex != null)
        {
            
        }

    }

}