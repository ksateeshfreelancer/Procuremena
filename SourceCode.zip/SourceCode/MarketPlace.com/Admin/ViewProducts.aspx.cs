﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;
using Newtonsoft.Json;

public partial class ViewProducts : BasePage
{
    #region Global Variables

    private ProductCatalogManager _productCatalogManager = new ProductCatalogManager();
    public string ProductNames { get; set; }
    public string Categories { get; set; }
    public string SubCategories { get; set; }
    public string AliasProductNames { get; set; }

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {        
        if (IsPostBack) return;
        BindProducts();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtProductNameSearch.Value = txtCategorySearch.Value = txtSubCategorySearch.Value = "";
        BindProducts();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        var products = ((List<ProductCatalog>)ViewState["List"]);
        if (products == null) return;
        var control = ((Control)sender).NamingContainer;
        products = (from item in products
                    where
                        (item.ProductName.ToLower().Contains(txtProductNameSearch.Value.ToLower().Trim()) ||
                        (!string.IsNullOrEmpty(item.AliasNames) && item.AliasNames.Split(',').Any(x => x.ToLower().Contains(txtProductNameSearch.Value.ToLower()))))
                        && item.SubCategory.SubCategoryName.ToLower().Contains(txtSubCategorySearch.Value.ToLower().Trim())
                        && item.Category.CategoryName.ToLower().Contains(txtCategorySearch.Value.ToLower().Trim())
                    select item).ToList();

        gridview.DataSource = ViewState["FilterList"] = products;
        gridview.DataBind();
    }
    protected void cboxStatus_CheckedChanged(object sender, EventArgs e)
    {
        var row = (CheckBox)sender;
        var cboxStatus = (CheckBox)row.FindControl("cboxStatus");
        var hdnProductID = (HiddenField)row.FindControl("hdnProductID");
        var status = (cboxStatus.Checked) ? 1 : 0;
        var dbMessage = _productCatalogManager.UpdateField(Tables.ProductCatalog, "Status", status.ToString(), "ProductID", hdnProductID.Value);

        if (dbMessage == DbMessage.Success)
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Product status is changed to " + ((Status)status).ToString() + " successfully", MessageType.Success);
        else
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update status. Please try again later.", MessageType.Error);
        BindProducts();
    }

    #region Grid Events
    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _productCatalogManager.DeleteProductCatalog(long.Parse(gridview.DataKeys[e.RowIndex].Values["ProductID"].ToString()), out _status);
        BindProducts();
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<ProductCatalog>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Categories",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "ProductName", "AliasNames", "Category.CategoryName", "SubCategory.SubCategoryName", "CreatedDate", "ModifiedDate" });
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindProducts()
    {
        var products = _productCatalogManager.GetProductCatalog(countryID: int.Parse(Session[SessionVariables.CountryId].ToString()));

        var categories = GetCachedCategories();
        var subCategories = GetCachedSubCategories();

        var aliasNames = from item in products
                         from name in item.AliasNames.Split(',')
                            select ValidAutoCompleteString(name);

        ProductNames = JsonConvert.SerializeObject((from item in products select ValidAutoCompleteString(item.ProductName)).Concat(aliasNames).ToArray());
        Categories = JsonConvert.SerializeObject((from item in categories select ValidAutoCompleteString(item.CategoryName)).ToArray());
        SubCategories = JsonConvert.SerializeObject((from item in subCategories select ValidAutoCompleteString(item.SubCategoryName)).ToArray());

        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = products;
        gridview.DataBind();
    }

    #endregion
}