﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;

public partial class ViewCountries : BasePage
{
    #region Global Variables

    private CountryManager _countryManager = new CountryManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindCountries();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            var duplicates = "";
            var isLoopBreak = false;
            var counter = 0;
            var countries = new List<Country>();
            var allCountries = (List<Country>)ViewState["List"];
            foreach (GridViewRow item in gridview.Rows)
            {
                counter++;
                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var categoryID = int.Parse(dataKeyArray.Values["CountryID"].ToString());
                var txtCountryName = (TextBox)item.FindControl("txtCountryName");
                var cboxStatus = (CheckBox)item.FindControl("cboxStatus");
                //skip empty strings
                if (IsEmpty(txtCountryName)) continue;
                //skip duplicates
                if (countries.Any(x => x.CountryName.ToLower().Equals(txtCountryName.Text.ToLower().Trim())))
                {
                    if (!string.IsNullOrEmpty(duplicates)) duplicates += ", ";
                    duplicates += txtCountryName.Text.Trim();
                }
                else if (allCountries.Count(x => x.CountryName == txtCountryName.Text.Trim()) >= 1 && 
                    allCountries.FirstOrDefault(x => x.CountryName == txtCountryName.Text.Trim()).CountryID != categoryID)
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Country " + txtCountryName.Text + " already exists.", MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                //skip unchanged records
                var existingCountry = allCountries.FirstOrDefault(x => x.CountryID == categoryID);
                if (existingCountry != null && existingCountry.CountryName == txtCountryName.Text.Trim() &&
                    existingCountry.Status == (cboxStatus.Checked ? Status.Active : Status.InActive))
                {
                    //indicates no changes are done here
                    continue;
                }

                countries.Add(new Country
                {
                    CountryID = categoryID,
                    CountryName = txtCountryName.Text.Trim(),
                    Status = cboxStatus.Checked ? Status.Active : Status.InActive
                });
            }

            if (countries.Count == 0 && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("No changes were done.", MessageType.Info);
                return;
            }

            if (!string.IsNullOrEmpty(duplicates))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate Country names found. " + duplicates, MessageType.Warning);
                return;
            }

            if (!isLoopBreak)
            {
                lblStatusMessage.InnerHtml = _countryManager.UpdateCountries(countries.Where(x => x.CountryID > 0).ToList(), out _status);
                lblStatusMessage.InnerHtml = _countryManager.SaveCountries(countries.Where(x => x.CountryID == 0).ToList(), out _status);
            }
            if (_status)
            {
                GetCachedCountries(true);
                ClearControls(this);
                BindCountries();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #region Grid Events
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _countryManager.DeleteCountry(int.Parse(gridview.DataKeys[e.RowIndex].Values["CountryID"].ToString()), out _status);
        BindCountries();
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Country>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Countries",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "CountryName", "Status", "CreatedDate", "ModifiedDate" });
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindCountries()
    {
        var countries = _countryManager.GetCountries();

        var newcountries = new List<Country>();
        //create empty grid with no of countries
        for (int i = 1; i <= 5; i++)
        {
            countries.Add(new Country
            {
                CountryID = 0,
                CountryName = string.Empty,
                Status = Status.Active
            });
        }
        countries.AddRange(newcountries);
        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = countries;
        gridview.DataBind();
    }

    #endregion
}