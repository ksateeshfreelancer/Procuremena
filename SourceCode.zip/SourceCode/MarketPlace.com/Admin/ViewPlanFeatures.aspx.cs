﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;

public partial class ViewPlanFeatures : BasePage
{
    #region Global Variables

    private PricePlanManager _pricePlanManager = new PricePlanManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        hdnPlanFeatureID.Value = "0";
        BindPlanFeatures();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            _pricePlanManager = new PricePlanManager();
            var _planFeature = new PlanFeature
            {
                PlanFeatureID = int.Parse(hdnPlanFeatureID.Value),
                FeatureName = txtFeatureName.Value.Trim(),
                Description = txtDescription.Value.Trim(),
                ControlType = int.Parse(rbtnControlType.SelectedItem.Value)
            };
            lblStatusMessage.InnerHtml = _pricePlanManager.SavePlanFeature(_planFeature, out _status);
            if (_status)
            {                
                ClearPlanFeatures();
                BindPlanFeatures();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void btnCancelFeature_Click(object sender, EventArgs e)
    {
        ClearPlanFeatures();
    }

    #region Grid Events
    protected void gridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            _pricePlanManager = new PricePlanManager();
            if (e.CommandName == "DeleteItem")
            {
                lblStatusMessage.InnerHtml = _pricePlanManager.DeletePlanFeature(int.Parse(e.CommandArgument.ToString()));
                BindPlanFeatures();
            }
            if (e.CommandName == "EditItem")
            {   
                var planFeature = _pricePlanManager.GetPlanFeatures(int.Parse(e.CommandArgument.ToString())).FirstOrDefault();
                txtFeatureName.Value = planFeature.FeatureName;
                txtDescription.Value = planFeature.Description;
                rbtnControlType.SelectedIndex = rbtnControlType.Items.IndexOf(rbtnControlType.Items.FindByValue(planFeature.ControlType.ToString()));
                hdnPlanFeatureID.Value = planFeature.PlanFeatureID.ToString(); 
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<PlanFeature>(gridview, ((LinkButton)sender).CommandArgument);
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindPlanFeatures()
    {
        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = _pricePlanManager.GetPlanFeatures();
        gridview.DataBind();
    }
    private void ClearPlanFeatures()
    {        
        txtDescription.Value = txtFeatureName.Value = ""; rbtnControlType.SelectedIndex = 0;
        hdnPlanFeatureID.Value = "0";
    }

    #endregion
}