﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;

public partial class ViewCities : BasePage
{
    #region Global Variables

    private CityManager _cityManager = new CityManager();
    public string Cities { get; set; }
    public string AliasCities { get; set; }

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindCities();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtCitySearch.Value = "";
        BindCities();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        var cities = ((List<City>)ViewState["List"]);
        if (cities == null) return;
        var control = ((Control)sender).NamingContainer;
        cities = (from item in cities
                         where item.CityName.ToLower().Contains(txtCitySearch.Value.ToLower().Trim()) ||
                         (!string.IsNullOrEmpty(item.AliasNames) && item.AliasNames.Split(',').Any(x => x.ToLower().Contains(txtCitySearch.Value.ToLower())))
                         select item).ToList();

        gridview.DataSource = ViewState["FilterList"] = cities;
        gridview.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            var duplicates = "";
            var isLoopBreak = false;
            var counter = 0;
            var cities = new List<City>();
            var allCities = (List<City>)ViewState["List"];

            foreach (GridViewRow item in gridview.Rows)
            {
                counter++;
                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var cityID = int.Parse(dataKeyArray.Values["CityID"].ToString());
                var txtCityName = (TextBox)item.FindControl("txtCityName");
                var txtAliasNames = (TextBox)item.FindControl("txtAliasNames");
                var txtDisplayOrder = (TextBox)item.FindControl("txtDisplayOrder");
                var ddlCountry = (DropDownList)item.FindControl("ddlCountry");
                var cboxStatus = (CheckBox)item.FindControl("cboxStatus");
                //skip empty strings
                if (IsEmpty(txtCityName) && ddlCountry.SelectedIndex == 0) continue;
                if (IsEmpty(txtCityName) || ddlCountry.SelectedIndex == 0 || (!IsEmpty(txtDisplayOrder) && !IsValidNumber(txtDisplayOrder)))                
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid entries in Row: " + counter + ".",
                        MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }
                //skip duplicates
                if (cities.Any(x => x.CityName.ToLower().Equals(txtCityName.Text.ToLower().Trim()) &&
                       x.Country.CountryID == int.Parse(ddlCountry.SelectedValue)))
                {
                    if (!string.IsNullOrEmpty(duplicates)) duplicates += ", ";
                    duplicates += txtCityName.Text.Trim();
                }
                var duplicateCities = allCities.Where(x => (x.CityName.ToLower().Equals(txtCityName.Text.ToLower().Trim())
                    || x.AliasNames.Split(',').Any(y => y.ToLower().Trim().Equals(txtCityName.Text.ToLower().Trim()))) &&
                      x.Country.CountryID == int.Parse(ddlCountry.SelectedValue));
                if (duplicateCities.Count() >= 1 && duplicateCities.Any(x=> x.CityID != cityID))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("City " + txtCityName.Text + " already exists.", MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                //skip unchanged records
                var existingCat = allCities.FirstOrDefault(x => x.CityID == cityID);
                if (existingCat != null && existingCat.CityName == txtCityName.Text.Trim() &&
                    existingCat.AliasNames == txtAliasNames.Text.Trim() &&
                    existingCat.DisplayOrder == int.Parse(txtDisplayOrder.Text) &&
                    existingCat.Country.CountryID == int.Parse(ddlCountry.SelectedValue) &&
                    existingCat.Status == (cboxStatus.Checked ? Status.Active : Status.InActive))
                {
                    //indicates no changes are done here
                    continue;
                }

                cities.Add(new City
                {
                    CityID = cityID,
                    Country = new Country
                    {
                        CountryID = int.Parse(ddlCountry.SelectedValue)
                    },
                    CityName = txtCityName.Text.Trim(),
                    DisplayOrder = int.Parse(txtDisplayOrder.Text),
                    AliasNames = txtAliasNames.Text.Trim(),
                    Status = cboxStatus.Checked ? Status.Active : Status.InActive
                });
            }

            if (cities.Count == 0 && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("No changes were done.", MessageType.Info);
                return;
            }

            if (!string.IsNullOrEmpty(duplicates))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate City names found. " + duplicates, MessageType.Warning);
                return;
            }

            if (!isLoopBreak)
            {
                lblStatusMessage.InnerHtml = _cityManager.UpdateCities(cities.Where(x => x.CityID > 0).ToList(), out _status);
                lblStatusMessage.InnerHtml = _cityManager.SaveCities(cities.Where(x => x.CityID == 0).ToList(), out _status);
            }
            if (_status)
            {
                //This is mandatory to clear cache as data is altered in database
                GetCachedCities(true);
                ClearControls(this);
                BindCities();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #region Grid Events
    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var ddlCountry = (DropDownList)e.Row.FindControl("ddlCountry");
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                Utilities.BindControl(GetCachedCountries(), "CountryName", "CountryID", ddlCountry);
                var country = (Country)dataKeyArray.Values["Country"];
                if (country != null)
                    ddlCountry.SelectedValue = country.CountryID.ToString();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _cityManager.DeleteCity(int.Parse(gridview.DataKeys[e.RowIndex].Values["CityID"].ToString()), out _status);
        BindCities();
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<City>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Cities",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "CityName", "DisplayOrder", "AliasNames", "Country.CountryName", "Status", "CreatedDate", "ModifiedDate" });
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindCities()
    {
        var cities = _cityManager.GetCities(null);

        var newccities = new List<City>();
        //create empty grid with no of cities
        for (int i = 1; i <= 5; i++)
        {
            cities.Add(new City
            {
                CityID = 0,
                CityName = string.Empty,
                AliasNames = string.Empty,
                Status = Status.Active
            });
        }
        
        var aliasNames = from item in cities
                         from name in item.AliasNames.Split(',')
                            select ValidAutoCompleteString(name);

        Cities = Newtonsoft.Json.JsonConvert.SerializeObject((from item in cities select ValidAutoCompleteString(item.CityName))
            .Concat(aliasNames));

        cities.AddRange(newccities);
        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = cities;
        gridview.DataBind();
    }

    #endregion
}