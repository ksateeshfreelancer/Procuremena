﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.BL;
using Newtonsoft.Json;
using System.IO;

public partial class ManageProduct : BasePage
{
    #region Global Variables

    ProductCatalogManager _productCatalogManager = new ProductCatalogManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (IsPostBack) return;

            Utilities.BindControl(GetCachedCategories(), "CategoryName", "CategoryID", ddlCategory);
            ddlCategory.Focus();
            long id = 0;
            long.TryParse(Utilities.Decrypt(Request.QueryString["ID"]), out id);
            hdnID.Value = id.ToString();
            LoadProductDetails(id);
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            var allProducts = (List<ProductCatalog>)ViewState["List"];
            var productID = long.Parse(hdnID.Value);

            //check duplicates
            var duplicateProducts = allProducts.Where(x => (x.ProductName.ToLower().Equals(txtProductName.Text.ToLower().Trim())
                    || x.AliasNames.Split(',').Any(y => y.ToLower().Trim().Equals(txtProductName.Text.ToLower().Trim()))));
            if (duplicateProducts.Count() >= 1 && duplicateProducts.Any(x => x.ProductID != productID))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Product " + txtProductName.Text + " already exists.", MessageType.Warning);
                return;
            }

            var productDetails = new ProductCatalog
            {
                AliasNames = txtAliasNames.Text,
                Category = new Category
                {
                    CategoryID = int.Parse(ddlCategory.SelectedValue)
                },
                Country = new Country
                {
                    CountryID = Convert.ToInt32(Session[SessionVariables.CountryId])
                },
                ProductName = txtProductName.Text.Trim(),
                ProductID = productID,
                SubCategory = new SubCategory
                {
                    SubCategoryID = int.Parse(ddlSubCategory.SelectedValue)
                }
            };

            lblStatusMessage.InnerHtml = _productCatalogManager.SaveProduct(productDetails, out productID, out _status);

            if (_status)
            {
                //clear cache as product details are changed
                GetCachedProducts(true);
                CreatedDate.Text = ModifiedDate.Text = "";
                ClearControls(this);
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCategory.SelectedIndex > 0)
        {
            var subCategories = GetCachedSubCategories(categoryID: int.Parse(ddlCategory.SelectedValue));
            Utilities.BindControl(subCategories, "SubCategoryName", "SubCategoryID", ddlSubCategory);
            ddlSubCategory.Focus();
        }
        else
        {
            ddlSubCategory.DataSource = null;
            ddlSubCategory.DataBind();
        }
    }

    #endregion

    #region Private Methods
    private void LoadProductDetails(long id)
    {
        var products = _productCatalogManager.GetProductCatalog(countryID: Convert.ToInt32(Session[SessionVariables.CountryId].ToString()));
        //save list to viewstate
        ViewState["List"] = products;

        if (id > 0)
        {
            var productDetails = products.FirstOrDefault(x => x.ProductID == id);
            if (productDetails == null)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load product details. Please try later.", CLB.Enums.MessageType.Error);
                return;
            }

            hdnID.Value = productDetails.ProductID.ToString();
            txtProductName.Text = productDetails.ProductName;
            txtAliasNames.Text = productDetails.AliasNames;
            ddlCategory.SelectedValue = productDetails.Category.CategoryID.ToString();
            ddlCategory_SelectedIndexChanged(ddlCategory, null);
            ddlSubCategory.SelectedValue = productDetails.SubCategory.SubCategoryID.ToString();
            CreatedDate.Text = FormatDateTime(productDetails.CreatedDate);
            ModifiedDate.Text = FormatDateTime(productDetails.ModifiedDate);
        }
    }
    #endregion
}