﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;

public partial class ViewPricePlans : BasePage
{
    #region Global Variables

    private PricePlanManager _pricePlanManager = new PricePlanManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        hdnPricePlanID.Value = "0";
        Utilities.BindControl<Frequency>(ddlPlanSubscription, new[] { Frequency.Others.ToString(), Frequency.Onetime.ToString() });
        BindPricePlans();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            _pricePlanManager = new PricePlanManager();
            var _pricePlan = new PricePlan
            {
                PlanID = int.Parse(hdnPricePlanID.Value),
                PlanName = txtPlanName.Value,
                PlanPrice = double.Parse(txtPlanPrice.Value),
                PlanSubscription = (Frequency)int.Parse(ddlPlanSubscription.SelectedItem.Value)
            };
            lblStatusMessage.InnerHtml = _pricePlanManager.SavePricePlan(_pricePlan, out _status);
            if (_status)
            {
                ClearPricePlan();
                BindPricePlans();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void btnCancelPlan_Click(object sender, EventArgs e)
    {
        ClearPricePlan();
    }

    #region Grid Events
    protected void gridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            _pricePlanManager = new PricePlanManager();
            if (e.CommandName == "DeleteItem")
            {
                lblStatusMessage.InnerHtml = _pricePlanManager.DeletePricePlan(int.Parse(e.CommandArgument.ToString()));
                BindPricePlans();
            }
            if (e.CommandName == "EditItem")
            {
                var pricePlan = _pricePlanManager.GetPricePlans(int.Parse(e.CommandArgument.ToString())).FirstOrDefault();
                txtPlanName.Value = pricePlan.PlanName;
                txtPlanPrice.Value = pricePlan.PlanPrice.ToString();
                ddlPlanSubscription.SelectedIndex = ddlPlanSubscription.Items.IndexOf(ddlPlanSubscription.Items.FindByValue(pricePlan.PlanSubscription.ToString()));
                hdnPricePlanID.Value = pricePlan.PlanID.ToString();                 
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<PricePlan>(gridview, ((LinkButton)sender).CommandArgument);
    }
   
    #endregion

    #endregion

    #region Private Methods
    private void BindPricePlans()
    {
        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = _pricePlanManager.GetPricePlans();
        gridview.DataBind();
    }
    private void ClearPricePlan()
    {
        hdnPricePlanID.Value = "0";
        txtPlanName.Value = txtPlanPrice.Value = ""; ddlPlanSubscription.SelectedIndex = 0;        
    }

    #endregion
}