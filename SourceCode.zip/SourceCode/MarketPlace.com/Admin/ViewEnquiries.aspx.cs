﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;
using Newtonsoft.Json;
using System.Text;

public partial class ViewEnquiries : BasePage
{
    #region Global Variables

    private EnquiryManager _enquiryManager = new EnquiryManager();
    private VendorInventoryManager _vendorInventoryManager = new VendorInventoryManager();
    public string UserNames { get; set; }

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        var enquiryStatuses = GetCachedEnquiryStatuses();
        /*foreach (var value in enquiryStatuses)
        {
            int[] statuses = new[] { 1, 2, 8, 9, 10, 11 };
            if (statuses.Any(x => x == value.StatusID))
                ddlEnquiryStatusSearch.Items.Add(new ListItem(value.StatusName, value.StatusID.ToString()));
        }*/

        Utilities.BindControl(enquiryStatuses, "StatusName", "StatusID", ddlEnquiryStatusSearch);
        BindEnquiries();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtEnquiryLabelSearch.Value = txtUserEmailMobileSearch.Value = txtFromDateSearch.Value = txtToDateSearch.Value = "";
        ddlEnquiryStatusSearch.SelectedIndex = 0;
        BindEnquiries();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        BindEnquiries();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //button hidden in ui as logic has become complex due to multi item enquiry
        return;
        try
        {
            var isLoopBreak = false;
            var counter = 0;
            var enquiries = new List<Enquiry>();
            var enquiryList = (List<Enquiry>)ViewState["UnalteredList"];
            foreach (GridViewRow item in gridview.Rows)
            {
                counter++;
                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var ddlEnquiryStatus = (DropDownList)item.FindControl("ddlEnquiryStatus");
                var enquiryID = long.Parse(dataKeyArray.Values["EnquiryID"].ToString());
                var productID = long.Parse(dataKeyArray.Values["ProductID"].ToString());

                //skip unchanged/unselected orders
                if (ddlEnquiryStatus.SelectedIndex == 0) continue;
                if (enquiryList.FirstOrDefault(x => x.EnquiryID == enquiryID).EnquiryStatus.StatusID == int.Parse(ddlEnquiryStatus.SelectedValue)) continue;
                if (ddlEnquiryStatus.SelectedIndex == 0)
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid entries in Row: " + counter + ".",
                        MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                enquiries.Add(new Enquiry
                {
                    EnquiryID = enquiryID,
                    EnquiryStatus = new EnquiryStatus
                    {
                        StatusID = int.Parse(ddlEnquiryStatus.SelectedValue)
                    },
                    ProductID = productID
                });
            }

            if (enquiries.Count == 0 && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("No enquiries were updated. At least one enquiry status must be changed.", MessageType.Warning);
                return;
            }

            if (!isLoopBreak)
            {
                var successfullOrders = string.Empty;
                var failedOrders = string.Empty;
                foreach (var enquiry in enquiries)
                {
                    //check if status is changed from initiated to admin approved
                    if (enquiry.EnquiryStatus.StatusID == 2)
                    {
                        var dbMessage = _vendorInventoryManager.SendEnquirytoVendors(enquiry.EnquiryID);
                        if (dbMessage != DbMessage.Success)
                        {
                            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update Enquiry " + enquiry.EnquiryLabel + ". Please try agian later", MessageType.Error);
                            return;
                        }
                        SendEnquirytoVendors(enquiry.EnquiryID);
                    }

                    //if admin has changed the status to closed (value > 8) in enquiry table, same has to be updated for corresponding
                    //records in Quotations table.
                    if (enquiry.EnquiryStatus.StatusID > 8)
                    {
                        var result1 = _enquiryManager.UpdateField(Tables.Quotation, "StatusID", enquiry.EnquiryStatus.StatusID.ToString(), "EnquiryID", enquiry.EnquiryID.ToString());
                    }

                    var result = _enquiryManager.UpdateField(Tables.Enquiry, "StatusID", enquiry.EnquiryStatus.StatusID.ToString(), "EnquiryID", enquiry.EnquiryID.ToString());
                    if (result == DbMessage.Success)
                    {
                        if (string.IsNullOrEmpty(successfullOrders)) successfullOrders += ", ";
                        successfullOrders += enquiry.EnquiryLabel;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(failedOrders)) failedOrders += ", ";
                        failedOrders += enquiry.EnquiryLabel;
                    }
                }

                if (string.IsNullOrEmpty(failedOrders))
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Record(s) status updated successfully", MessageType.Success);
                else
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Record(s) " + successfullOrders + " status is updated successfully," +
                                                                        " but failed to update Records(s) " + failedOrders, MessageType.Info);
            }
            if (_status)
            {
                ClearControls(this);
                BindEnquiries();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #region Grid Events
    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                var isMultiProduct = (bool)dataKeyArray.Values["IsMultiProduct"];
                var currentEnquiryStatus = ((EnquiryStatus)dataKeyArray.Values["EnquiryStatus"]).StatusID;
                var enquiryLabel = dataKeyArray.Values["EnquiryLabel"].ToString();
                var ddlEnquiryStatus = (DropDownList)e.Row.FindControl("ddlEnquiryStatus");
                var lblEnquiryStatus = (Label)e.Row.FindControl("lblEnquiryStatus");
                var lbtnSaveRecord = (LinkButton)e.Row.FindControl("lbtnSaveRecord");
                var lnkLog = (HtmlAnchor)e.Row.FindControl("lnkLog");

                //bind dropdown such that admin does not select enquiry status in reverse order.
                //allow only fwd status change
                //don't bind dropdown for 2nd item in multi item enquiry
                if (currentEnquiryStatus > 0)
                {
                    foreach (var value in GetCachedEnquiryStatuses().
                        Where(value => value.StatusID > 0 && value.StatusID >= currentEnquiryStatus))
                    {
                        //int[] statuses = new[] { 1, 2, 8, 9, 10, 11 };
                        //if (statuses.Any(x => x == value.StatusID))
                        ddlEnquiryStatus.Items.Add(new ListItem(value.StatusName, value.StatusID.ToString()));
                    }
                }
                //disable dropdown selection once enquiry is closed
                lblEnquiryStatus.Visible = (currentEnquiryStatus > 8);
                ddlEnquiryStatus.Visible = !(currentEnquiryStatus > 8);
                lbtnSaveRecord.Visible = !(currentEnquiryStatus > 8);

                if (string.IsNullOrEmpty(enquiryLabel))
                {
                    lnkLog.Visible = false; 
                }
                else
                {
                    lnkLog.HRef = "~/" + _redirectPage.ViewEnquiryLog.Key + "?T=P&ID=" + enquiryLabel;
                    lnkLog.Visible = (currentEnquiryStatus > 2);
                }

                #region Multi Item Enquiries Logic

                if (isMultiProduct && currentEnquiryStatus == 0)
                {
                    ddlEnquiryStatus.Visible = false;
                    lbtnSaveRecord.Visible = false;
                    lblEnquiryStatus.Visible = false;
                    ((LinkButton)e.Row.FindControl("lbtnSaveRecord")).Visible = false;
                }

                #endregion
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void gridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "SaveEnquiry")
            {
                bool isEnquiryChanged = true;
                var enquiries = (List<Enquiry>)ViewState["UnalteredList"];

                GridViewRow item = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);

                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var ddlEnquiryStatus = (DropDownList)item.FindControl("ddlEnquiryStatus");
                var enquiryID = long.Parse(dataKeyArray.Values["EnquiryID"].ToString());
                var enquiryLabel = dataKeyArray.Values["EnquiryLabel"].ToString();
                var isMultiProduct = (bool)dataKeyArray.Values["IsMultiProduct"];
                var enquiryStatusID = int.Parse(ddlEnquiryStatus.SelectedValue);

                //skip unchanged/unselected orders
                if (ddlEnquiryStatus.SelectedIndex == 0) isEnquiryChanged = false;
                if (enquiries.FirstOrDefault(x => x.EnquiryID == enquiryID).EnquiryStatus.StatusID == enquiryStatusID) isEnquiryChanged = false;

                var successfullOrders = string.Empty;
                var failedOrders = string.Empty;

                if (isEnquiryChanged)
                {
                    //check if status is changed from initiated to admin approved
                    if (enquiryStatusID == 2)
                    {
                        var dbMessage = DbMessage.Failed;
                        if (isMultiProduct)
                        {
                            //loop for multi product
                            foreach (var mlEnquiry in enquiries.Where(x => x.EnquiryLabel == enquiryLabel))
                            {
                                dbMessage = _vendorInventoryManager.SendEnquirytoVendors(mlEnquiry.EnquiryID);
                            } 
                        }
                        else
                        {
                            dbMessage = _vendorInventoryManager.SendEnquirytoVendors(enquiryID);
                        }
                        if (dbMessage != DbMessage.Success)
                        {
                            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update Enquiry " + enquiryLabel + ". Please try agian later", MessageType.Error);
                            return;
                        }
                        if (isMultiProduct)
                            SendEnquirytoVendors(enquiryLabel);
                        else
                            SendEnquirytoVendors(enquiryID);

                        lblStatusMessage.InnerHtml = Utilities.CustomMessage("Enquiry " + enquiryLabel + " status updated successfully", MessageType.Success);
                    }
                    else
                    {
                        //if admin has changed the status to closed (value > 8) in enquiry table, same has to be updated for corresponding
                        //records in Quotations table.
                        if (enquiryStatusID > 8)
                        {
                            var quotations = (from enquiry in enquiries
                                                 where enquiry.EnquiryLabel == enquiry.EnquiryLabel
                                                 select new Quotation
                                                 {
                                                     Enquiry = new Enquiry
                                                     {
                                                         EnquiryID = enquiry.EnquiryID
                                                     },
                                                     EnquiryStatus = new EnquiryStatus
                                                     {
                                                         StatusID = enquiryStatusID
                                                     }
                                                 }).ToList();
                            var result1 = _enquiryManager.UpdateQuotationsStatus(quotations, false);
                        }

                        var result = _enquiryManager.UpdateField(Tables.Enquiry, "StatusID", enquiryStatusID.ToString(), "EnquiryLabel", enquiryLabel);
                        if (result == DbMessage.Success)
                        {
                            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Enquiry " + enquiryLabel + " status updated successfully", MessageType.Success);
                        }
                        else
                        {
                            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update Enquiry " + enquiryLabel + ". Please try agian later", MessageType.Error);
                        }
                    }
                    BindEnquiries();
                }
                else
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("No changes were done to Enquiry " + enquiryLabel + ".", MessageType.Warning);
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _enquiryManager.DeleteEnquiry(int.Parse(gridview.DataKeys[e.RowIndex].Values["EnquiryID"].ToString()), out _status);
        BindEnquiries();
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Enquiry>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Enquiries",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "EnquiryLabel", "EnquiryStatus.StatusName", "IsGeneralEnquiry", "CreatedDate", "ProductName", "Quantity", "UOM.UnitName", "DeliveryLocation", "ModifiedDate" });
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindEnquiries()
    {
        var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Customer });        
        var enquiries = new List<Enquiry>();

        //check if atleast one filter is set
        if ((!string.IsNullOrEmpty(txtFromDateSearch.Value) && !string.IsNullOrEmpty(txtToDateSearch.Value)) ||
            !string.IsNullOrEmpty(txtUserEmailMobileSearch.Value) || !string.IsNullOrEmpty(txtEnquiryLabelSearch.Value) ||
            ddlEnquiryStatusSearch.SelectedIndex > 0)
        {
            int? enquiryStatusID = null;
            if (ddlEnquiryStatusSearch.SelectedIndex > 0)
                enquiryStatusID = int.Parse(ddlEnquiryStatusSearch.SelectedValue);

            enquiries = _enquiryManager.GetEnquiries(enquiryStatusID: enquiryStatusID,
               enquiryLabel: (!string.IsNullOrEmpty(txtEnquiryLabelSearch.Value.Trim()) ? txtEnquiryLabelSearch.Value : null),
               fromDate: GetSqlDate(txtFromDateSearch.Value), toDate: GetSqlDate(txtToDateSearch.Value));
        }
        else
        {
            enquiries = _enquiryManager.GetEnquiries(fromDate: GetSqlDate(DateTime.Now.AddMonths(-2).ToString("dd-MM-yyyy")),
                   toDate: GetSqlDate(DateTime.Now.AddDays(1).ToString("dd-MM-yyyy")));
        }

        //USER DETAILS ARE FETCHED FROM DB. DONT Bind the details here
        //enquiries.ForEach(x => x.User = users.FirstOrDefault(y => y.UserID == x.User.UserID));

        ViewState["UnalteredList"] = enquiries.ToList();

        var tmpEnquiries = CloneEntity.Clone<List<Enquiry>>(enquiries);

        //group enquiries for multi item view
        foreach (var items in tmpEnquiries.GroupBy(x => x.EnquiryLabel))
        {
            //loop only those enquiries that have multi items
            if (items.Count() > 1)
            {
                foreach (var enquiry in items.Skip(1))
                {
                    enquiry.EnquiryLabel = "";
                    enquiry.EnquiryStatus = new EnquiryStatus();
                }
            }
        }

        ViewState["FilterList"] = ViewState["List"] = tmpEnquiries.ToList();

        gridview.DataSource = tmpEnquiries.OrderByDescending(x => x.CreatedDate).ToList();
        gridview.DataBind();

        var userNames = (from item in users
                         select ValidAutoCompleteString(item.UserDetails.FirstName + " " +
                             item.UserDetails.LastName + " (" + item.Email + " - " + item.Mobile + ")")).ToList();
        UserNames = JsonConvert.SerializeObject(userNames.ToArray());
    }
    private void SendEnquirytoVendors(long enquiryID)
    {
        try
        {
            var enquiry = _enquiryManager.GetEnquiries(enquiryID: enquiryID).FirstOrDefault();
            var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor, (int)UserRole.Customer });
            var vendors = _vendorInventoryManager.GetVendorInventory(productID: enquiry.ProductID);
            //user details are fetched from cache and bound here
            vendors.ForEach(x => x.User = users.FirstOrDefault(y => y.UserID == x.UserID));

            var userDetails = users.FirstOrDefault(x => x.UserID == enquiry.User.UserID);
            if (vendors != null)
            {
                foreach (var vendor in vendors)
                {
                    string body = "Hi " + vendor.User.UserDetails.FirstName + " " + vendor.User.UserDetails.LastName + ",  <br/><br/> You have a new enquiry from " +
                               userDetails.UserDetails.FirstName + " " + userDetails.UserDetails.LastName + ". <br/><br/> Please reply with your quotation. <br/><br/> Details: <br/><br/>" +
                               "<br/>Customer Email: " + userDetails.Email +
                               "<br/>Phone: " + userDetails.Mobile +
                               "<br/>Product Name: " + enquiry.ProductName +
                               "<br/>Product Specification: " + enquiry.ProductSpecification +
                               "<br/>Quantity: " + enquiry.Quantity + enquiry.UOM.UnitName +
                               "<br/>delivery Location: " + enquiry.DeliveryLocation;

                    Utilities.SendEmail(users.FirstOrDefault(x => x.UserID == vendor.UserID).Email, "New enquiry received", body);
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            //supress exception5
            //throw;
        }
    }    
    private void SendEnquirytoVendors(string enquiryLabel)
    {
        try
        {
            var enquiries = _enquiryManager.GetEnquiries(enquiryLabel: enquiryLabel);
            var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor, (int)UserRole.Customer });
            var userDetails = users.FirstOrDefault(x => x.UserID == enquiries.FirstOrDefault().User.UserID);

            var vendorList = new List<VendorInventory>();
            foreach (var enquiry in enquiries)
            {
                var vendors = _vendorInventoryManager.GetVendorInventory(productID: enquiry.ProductID);
                //user details are fetched from cache and bound here
                vendors.ForEach(x => x.User = users.FirstOrDefault(y => y.UserID == x.UserID));

                foreach (var vendor in vendors)
                {
                    //check if vendor is already in list
                    if (!vendorList.Any(x => x.UserID == vendor.UserID))
                        vendorList.Add(vendor);
                }
            }

            if (vendorList.Count > 0)
            {
                foreach (var vendor in vendorList)
                {
                    StringBuilder sbBody = new StringBuilder();
                    sbBody.Append("<br/><br/><table style='text-align: left;'><thead><tr><th>Product</th><th>Quantity</th><th>Product Specification</th></thead><tbody>");

                    foreach (var enquiry in enquiries)
                    {
                        sbBody.Append("<tr><td>" + enquiry.ProductName + "</td>");
                        sbBody.Append("<td>" + enquiry.Quantity + " " + enquiry.UOM.UnitName + "</td>");
                        sbBody.Append("<td>" + enquiry.ProductSpecification + "</td></tr>");
                    }
                    sbBody.Append("</tbody></table>");

                    string body = "Hi " + vendor.User.UserDetails.FirstName + " " + vendor.User.UserDetails.LastName + ",  <br/><br/> You have a new enquiry from " +
                               userDetails.UserDetails.FirstName + " " + userDetails.UserDetails.LastName + ". <br/><br/> Please reply with your quotation. <br/><br/> Details: <br/><br/>" +
                               "<br/>Customer Email: " + userDetails.Email +
                               "<br/>Phone: " + userDetails.Mobile +
                               "<br/>Delivery Location: " + enquiries.FirstOrDefault().DeliveryLocation +
                               sbBody.ToString();

                    Utilities.SendEmail(users.FirstOrDefault(x => x.UserID == vendor.UserID).Email, "New enquiry received", body);
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            //supress exception
            //throw;
        }
    }
    #endregion
}