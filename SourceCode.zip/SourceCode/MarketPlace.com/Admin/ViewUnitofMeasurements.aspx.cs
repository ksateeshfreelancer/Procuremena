﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;

public partial class ViewUOM : BasePage
{
    #region Global Variables

    private UnitofMeasurementManager _uomManager = new UnitofMeasurementManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindUnits();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            var duplicates = "";
            var isLoopBreak = false;
            var counter = 0;
            var units = new List<UnitofMeasurement>();
            var allUnits = (List<UnitofMeasurement>)ViewState["List"];
            foreach (GridViewRow item in gridview.Rows)
            {
                counter++;
                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var categoryID = int.Parse(dataKeyArray.Values["UnitID"].ToString());
                var txtUnitName = (TextBox)item.FindControl("txtUnitName");
                var cboxStatus = (CheckBox)item.FindControl("cboxStatus");
                //skip empty strings
                if (IsEmpty(txtUnitName)) continue;
                //skip duplicates
                if (units.Any(x => x.UnitName.ToLower().Equals(txtUnitName.Text.ToLower().Trim())))
                {
                    if (!string.IsNullOrEmpty(duplicates)) duplicates += ", ";
                    duplicates += txtUnitName.Text.Trim();
                }
                else if (allUnits.Count(x => x.UnitName == txtUnitName.Text.Trim()) >= 1 && 
                    allUnits.FirstOrDefault(x => x.UnitName == txtUnitName.Text.Trim()).UnitID != categoryID)
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Unit " + txtUnitName.Text + " already exists.", MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                //skip unchanged records
                var existingUnit = allUnits.FirstOrDefault(x => x.UnitID == categoryID);
                if (existingUnit != null && existingUnit.UnitName == txtUnitName.Text.Trim() &&
                    existingUnit.Status == (cboxStatus.Checked ? Status.Active : Status.InActive))
                {
                    //indicates no changes are done here
                    continue;
                }

                units.Add(new UnitofMeasurement
                {
                    UnitID = categoryID,
                    UnitName = txtUnitName.Text.Trim(),
                    Status = cboxStatus.Checked ? Status.Active : Status.InActive
                });
            }

            if (units.Count == 0 && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("No changes were done.", MessageType.Info);
                return;
            }

            if (!string.IsNullOrEmpty(duplicates))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate Unit names found. " + duplicates, MessageType.Warning);
                return;
            }

            if (!isLoopBreak)
            {
                lblStatusMessage.InnerHtml = _uomManager.UpdateUnitofMeasurements(units.Where(x => x.UnitID > 0).ToList(), out _status);
                lblStatusMessage.InnerHtml = _uomManager.SaveUnitofMeasurements(units.Where(x => x.UnitID == 0).ToList(), out _status);
            }
            if (_status)
            {
                GetCachedUOMs(true);
                ClearControls(this);
                BindUnits();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #region Grid Events
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _uomManager.DeleteUnitofMeasurement(int.Parse(gridview.DataKeys[e.RowIndex].Values["UnitID"].ToString()), out _status);
        BindUnits();
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Unit>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Units",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "UnitName", "Status", "CreatedDate", "ModifiedDate" });
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindUnits()
    {
        var units = _uomManager.GetUnitofMeasurements();

        var newunits = new List<UnitofMeasurement>();
        //create empty grid with no of units
        for (int i = 1; i <= 5; i++)
        {
            units.Add(new UnitofMeasurement
            {
                UnitID = 0,
                UnitName = string.Empty,
                Status = Status.Active
            });
        }
        units.AddRange(newunits);
        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = units;
        gridview.DataBind();
    }

    #endregion
}