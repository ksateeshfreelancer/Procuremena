﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using Newtonsoft.Json;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;

public partial class ViewSubCategories : BasePage
{
    #region Global Variables

    private SubCategoryManager _subCategoryManager = new SubCategoryManager();
    public string Categories { get; set; }
    public string SubCategories { get; set; }
    public string AliasCategories { get; set; }

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindSubCategories();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtSubCategorySearch.Value = "";
        BindSubCategories();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        var subCategories = ((List<SubCategory>)ViewState["List"]);
        if (subCategories == null) return;
        var control = ((Control)sender).NamingContainer;
        subCategories = (from item in subCategories
                         where (!string.IsNullOrEmpty(txtSubCategorySearch.Value) && (item.SubCategoryName.ToLower().Contains(txtSubCategorySearch.Value.ToLower().Trim())) ||
                         (!string.IsNullOrEmpty(item.AliasNames) && item.AliasNames.Split(',').Any(x => x.ToLower().Contains(txtSubCategorySearch.Value.ToLower())))) ||
                         (!string.IsNullOrEmpty(txtCategorySearch.Value) && item.Category.CategoryName.ToLower().Contains(txtCategorySearch.Value.ToLower().Trim())) ||
                         (!string.IsNullOrEmpty(item.Category.AliasNames) && item.Category.AliasNames.Split(',').Any(x => x.ToLower().Contains(txtCategorySearch.Value.ToLower())))
                         select item).ToList();

        gridview.DataSource = ViewState["FilterList"] = subCategories;
        gridview.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            var duplicates = "";
            var isLoopBreak = false;
            var counter = 0;
            var subCategories = new List<SubCategory>();
            var allsubCategories = (List<SubCategory>)ViewState["List"];
            foreach (GridViewRow item in gridview.Rows)
            {
                counter++;
                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var subCategoryID = int.Parse(dataKeyArray.Values["SubCategoryID"].ToString());
                var txtSubCategoryName = (TextBox)item.FindControl("txtSubCategoryName");
                var txtAliasNames = (TextBox)item.FindControl("txtAliasNames");
                var txtDisplayOrder = (TextBox)item.FindControl("txtDisplayOrder");
                var ddlCategory = (DropDownList)item.FindControl("ddlCategory");
                var cboxStatus = (CheckBox)item.FindControl("cboxStatus");
                //skip empty strings
                if (IsEmpty(txtSubCategoryName) && ddlCategory.SelectedIndex == 0) continue;
                if (IsEmpty(txtSubCategoryName) || ddlCategory.SelectedIndex == 0 || (!IsEmpty(txtDisplayOrder) && !IsValidNumber(txtDisplayOrder)))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid entries in Row: " + counter + ".",
                        MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }
                //skip duplicates
                if (subCategories.Any(x => x.SubCategoryName.ToLower().Equals(txtSubCategoryName.Text.ToLower().Trim()) &&
                       x.Category.CategoryID == int.Parse(ddlCategory.SelectedValue)))
                {
                    if (!string.IsNullOrEmpty(duplicates)) duplicates += ", ";
                    duplicates += txtSubCategoryName.Text.Trim();
                }
                
                var duplicateCategories = allsubCategories.Where(x => (x.SubCategoryName.ToLower().Equals(txtSubCategoryName.Text.ToLower().Trim())
                    || x.AliasNames.Split(',').Any(y => y.ToLower().Trim().Equals(txtSubCategoryName.Text.ToLower().Trim()))) &&
                      x.Category.CategoryID == int.Parse(ddlCategory.SelectedValue));
                if (duplicateCategories.Count() >= 1 && duplicateCategories.Any(x => x.SubCategoryID != subCategoryID))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Subcategory " + txtSubCategoryName.Text + "(" + ddlCategory.SelectedItem.Text + ") already exists.", MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                //skip unchanged records
                var existingSubCat = allsubCategories.FirstOrDefault(x => x.SubCategoryID == subCategoryID);
                if (existingSubCat != null && existingSubCat.SubCategoryName == txtSubCategoryName.Text.Trim() &&
                    existingSubCat.DisplayOrder == int.Parse(txtDisplayOrder.Text) &&
                    existingSubCat.Category.CategoryID == int.Parse(ddlCategory.SelectedValue) &&
                    existingSubCat.Status == (cboxStatus.Checked ? Status.Active : Status.InActive))
                {
                    //indicates no changes are done here
                    continue;
                }

                subCategories.Add(new SubCategory
                {
                    SubCategoryID = subCategoryID,
                    Category = new Category
                    {
                        CategoryID = int.Parse(ddlCategory.SelectedValue)
                    },
                    SubCategoryName = txtSubCategoryName.Text.Trim(),
                    DisplayOrder = int.Parse(txtDisplayOrder.Text),
                    AliasNames = txtAliasNames.Text.Trim(),
                    Status = cboxStatus.Checked ? Status.Active : Status.InActive
                });
            }

            if (subCategories.Count == 0 && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("No changes were done.", MessageType.Warning);
                return;
            }

            if (!string.IsNullOrEmpty(duplicates))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate Sub Category names found. " + duplicates, MessageType.Warning);
                return;
            }
            if (!isLoopBreak)
            {
                lblStatusMessage.InnerHtml = _subCategoryManager.UpdateSubCategories(subCategories.Where(x => x.SubCategoryID > 0).ToList(), out _status);
                lblStatusMessage.InnerHtml = _subCategoryManager.SaveSubCategories(subCategories.Where(x => x.SubCategoryID == 0).ToList(), out _status);
            }

            if (_status)
            {
                //This is mandatory to clear cache as data is altered in database
                GetCachedSubCategories(true);
                ClearControls(this);
                BindSubCategories();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #region Grid Events

    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var ddlCategory = (DropDownList)e.Row.FindControl("ddlCategory");
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                Utilities.BindControl(GetCachedCategories(), "CategoryName", "CategoryID", ddlCategory);
                var category = (Category)dataKeyArray.Values["Category"];
                if (category != null)
                    ddlCategory.SelectedValue = category.CategoryID.ToString();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _subCategoryManager.DeleteSubCategory(int.Parse(gridview.DataKeys[e.RowIndex].Values["SubCategoryID"].ToString()), out _status);
        BindSubCategories();
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<SubCategory>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "SubCategories",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "CategoryName", "SubCategoryName", "Status", "CreatedDate", "ModifiedDate" });
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindSubCategories()
    {
        var subCategories = _subCategoryManager.GetSubCategories(null);

        var newsubcategories = new List<SubCategory>();
        //create empty grid with no of categories
        for (int i = 1; i <= 5; i++)
        {
            subCategories.Add(new SubCategory
            {
                SubCategoryID = 0,
                SubCategoryName = string.Empty,
                Category = new Category
                {
                    CategoryID = 0,
                    CategoryName = string.Empty,
                },
                AliasNames = string.Empty,
                Status = Status.Active
            });
        }

        var categories = GetCachedCategories();
        var aliasNames = from item in subCategories
                         from name in item.AliasNames.Split(',')
                         select ValidAutoCompleteString(name);

        Categories = JsonConvert.SerializeObject((from item in categories select ValidAutoCompleteString(item.CategoryName)).ToArray());
        SubCategories = JsonConvert.SerializeObject((from item in subCategories select ValidAutoCompleteString(item.SubCategoryName))
            .Concat(aliasNames));

        subCategories.AddRange(newsubcategories);
        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = subCategories;
        gridview.DataBind();        
    }

    #endregion
}