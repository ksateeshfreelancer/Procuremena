﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using Table = System.Web.UI.WebControls.Table;
using System.IO;

public partial class MapPlanFeatures : BasePage
{
    #region Global Variables

    private PricePlanManager _pricePlanManager = new PricePlanManager();
    
    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        //Build martix on every page load
        BindPlanFeatures();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            var PricePlans = new List<PricePlan>();
            var pricePlanManagementTable = (Table)plhPriceManagement.FindControl("tblPricePlan");

            _pricePlanManager = new PricePlanManager();

            foreach (TableRow tableRow in pricePlanManagementTable.Rows)
            {
                foreach (TableCell tableCell in tableRow.Cells)
                {
                    if (tableRow.Cells.GetCellIndex(tableCell) > 0 && tableCell.Controls.Count > 0)
                    {
                        var hdnField = (HiddenField)tableCell.Controls[0];
                        var pricePlanId = int.Parse(hdnField.Value.Split('~')[0]);
                        var planFeatureId = int.Parse(hdnField.Value.Split('~')[1]);

                        if (tableCell.Controls[1].GetType().Name == "TextBox")
                        {
                            var textBox = (TextBox)tableCell.Controls[1];

                            if (PricePlans.FirstOrDefault(x => x.PlanID == pricePlanId) != null)
                            {
                                PricePlans.FirstOrDefault(x => x.PlanID == pricePlanId)
                                    .PlanFeatures.Add(new PlanFeature
                                    {
                                        ControlValue = textBox.Text,
                                        PlanFeatureID = planFeatureId,
                                    });
                            }
                            else
                            {
                                PricePlans.Add(new PricePlan
                                {
                                    PlanID = pricePlanId,
                                    PlanFeatures = new List<PlanFeature>(),
                                    CreatedBy = CurrentUser.UserID.ToString(),
                                    ModifiedBy = CurrentUser.UserID.ToString()
                                });
                                PricePlans.FirstOrDefault(x => x.PlanID == pricePlanId)
                                    .PlanFeatures.Add(new PlanFeature
                                    {
                                        ControlValue = textBox.Text,
                                        PlanFeatureID = planFeatureId,
                                    });
                            }

                        }
                        else
                        {
                            if (PricePlans.FirstOrDefault(x => x.PlanID == pricePlanId) != null)
                            {
                                PricePlans.FirstOrDefault(x => x.PlanID == pricePlanId)
                                    .PlanFeatures.Add(new PlanFeature
                                    {
                                        ControlValue = (((CheckBox)tableCell.Controls[1]).Checked) ? "1" : "0",
                                        PlanFeatureID = planFeatureId,
                                    });
                            }
                            else
                            {
                                PricePlans.Add(new PricePlan
                                {
                                    PlanID = pricePlanId,
                                    PlanFeatures = new List<PlanFeature>(),
                                    CreatedBy = CurrentUser.UserID.ToString(),
                                    ModifiedBy = CurrentUser.UserID.ToString(),
                                });
                                PricePlans.FirstOrDefault(x => x.PlanID == pricePlanId)
                                    .PlanFeatures.Add(new PlanFeature
                                    {
                                        ControlValue = (((CheckBox)tableCell.Controls[1]).Checked) ? "1" : "0",
                                        PlanFeatureID = planFeatureId,
                                    });
                            }
                        }
                    }
                }
            }

            lblStatusMessage.InnerHtml = _pricePlanManager.UpdatePricePlanManagement(PricePlans);
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #region Grid Events
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {   
        var tbl = plhPriceManagement.FindControl("tblPricePlan");
        Response.Clear();
        Response.Buffer = true;
        var exportType = (ExportType)Enum.Parse(typeof(ExportType), ((ImageButton)sender).CommandName);
        switch (exportType)
        {
            case ExportType.PDF:
                Response.AddHeader("content-disposition", "attachment;filename=Price Plans And Features.pdf");
                Response.ContentType = "application/pdf";
                break;
            case ExportType.Excel:
                Response.AddHeader("content-disposition", "attachment;filename=Price Plans And Features.xls");
                Response.ContentType = "application/vnd.ms-excel";
                break;
            case ExportType.Word:
                Response.AddHeader("content-disposition", "attachment;filename=Price Plans And Features.doc");
                Response.ContentType = "application/vnd.ms-word";
                break;
        }
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Charset = "";
        var sw = new StringWriter();
        var hw = new HtmlTextWriter(sw);
        var form = new HtmlForm();
        form.Attributes.Add("runat", "server");
        form.Controls.Add(tbl);
        this.Controls.Add(form);
        form.RenderControl(hw);
        //style to format numbers to string
        string style = @"<style> .textmode { mso-number-format:\@; } </style>";
        Response.Write(style);
        if (exportType == ExportType.PDF)
        {
            var sr = new StringReader(sw.ToString());
            var pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            var htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            htmlparser.Parse(sr);
            pdfDoc.Close();
            Response.Write(pdfDoc);
        }
        else
        {
            Response.Output.Write(sw.ToString());
        }

        Response.Flush();
        Response.End();
    }
    #endregion

    #endregion

    #region Private Methods
    private void BindPlanFeatures()
    {
        ViewState["List"] = _pricePlanManager.GetPlanFeatures();
        ViewState["List1"] = _pricePlanManager.GetPricePlans();

        var tbl = new Table();
        var planFeatures = (List<PlanFeature>)ViewState["List"];
        var pricePlans = (List<PricePlan>)ViewState["List1"];

        tbl.CssClass = "gridtable";
        tbl.ID = "tblPricePlan";
        tbl.Attributes.Add("runat", "server");
        var tbHeader = new TableHeaderRow();
        tbHeader.CssClass = "gridtr";
        var headercell = new TableHeaderCell
        {
            Width = new System.Web.UI.WebControls.Unit(100, UnitType.Pixel),
            Text = "Plan Features"
        };
        tbHeader.Cells.Add(headercell);

        //build header
        foreach (PricePlan pricePlan in pricePlans)
        {
            var tblCell = new TableHeaderCell
                 {
                     Width= new System.Web.UI.WebControls.Unit(100, UnitType.Pixel),
                     Text = pricePlan.PlanName                     
                 };
            tblCell.Style.Add("text-align", "center");
            tbHeader.Cells.Add(tblCell);
        }        
        tbl.Rows.Add(tbHeader);

        //build export feature

        var exporttr = new TableRow();
        exporttr.CssClass = "gridtrsearchpanel";
        var exporttd1 = new TableCell();
        exporttd1.Attributes.Add("align", "center");
        foreach (var name in Enum.GetNames(typeof(ExportType)))
        {
            var exportImg = new ImageButton
            {
                ImageUrl = "../images/" + name.ToLower() + "-export.png",
                CommandName = name,
                ToolTip = "Export to " + name,
                CssClass = "cancel std_hdn"
            };
            exportImg.Load += PostBackBind_DataBinding;
            exportImg.Attributes.Add("required", "false");
            exportImg.Style.Add("margin", "0 5px 0 5px;");
            exportImg.Click += ibtnExport_Click;
            exporttd1.Controls.Add(exportImg);
        }
        var exporttd2 = new TableCell();
        exporttd2.Attributes.Add("colspan", pricePlans.Count.ToString());
        exporttr.Cells.Add(exporttd1); exporttr.Cells.Add(exporttd2);
        tbl.Rows.Add(exporttr);

        foreach (var planFeature in planFeatures)
        {
            var tr = new TableRow();// <tr>
            var tdfeatureHeading = new TableCell { Text = (planFeature.FeatureName.Length > 40) ? planFeature.FeatureName.Substring(0, 40) + "...." : planFeature.FeatureName };//Plan Feature Headings <td>
            tdfeatureHeading.Attributes.Add("align", "left");
            tr.Cells.Add(tdfeatureHeading);
            foreach (var pricePlan in pricePlans)//Adding Controls (<td>)
            {
                var tc = new TableCell();
                tc.Attributes.Add("align", "center");
                //storing plan id and planfeatureid in hidden field '~' saperator
                var hdnplanIDFeatureID = new HiddenField
                {
                    Value = pricePlan.PlanID + "~" + planFeature.PlanFeatureID
                };
                tc.Controls.Add(hdnplanIDFeatureID);//adding control to tablecell <td> :-Control[0]

                if (planFeature.ControlType == 0) //indicates textbox :-Control[1]
                {
                    var txt = new TextBox
                    {
                        CssClass = "std_input std_imedium",
                        Text = pricePlan.PlanFeatures.Count(x => x.PlanFeatureID == planFeature.PlanFeatureID) == 0
                        ? ""
                        : pricePlan.PlanFeatures.FirstOrDefault(x => x.PlanFeatureID == planFeature.PlanFeatureID)
                          .ControlValue
                    };                    
                    txt.Attributes.Add("onkeypress", "return jsFns.IsNumberKey(event)");
                    txt.Attributes.Add("maxlength", "50");
                    txt.Style.Add("width", "50px !important");
                    tc.Controls.Add(txt);
                }
                else // indicates checkbox :-Control[1]
                {
                    tc.Controls.Add(new CheckBox
                    {
                        Checked =
                        pricePlan.PlanFeatures.Count(x => x.PlanFeatureID == planFeature.PlanFeatureID) == 0
                        ? false
                        : (pricePlan.PlanFeatures.FirstOrDefault(x => x.PlanFeatureID == planFeature.PlanFeatureID)
                          .ControlValue == "1")
                    });
                }
                tr.Cells.Add(tc);
            }
            tbl.Rows.Add(tr);
        }
        plhPriceManagement.Controls.Clear();
        plhPriceManagement.Controls.Add(tbl);
    }
    #endregion
}