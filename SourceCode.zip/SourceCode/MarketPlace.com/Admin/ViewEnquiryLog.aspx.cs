﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;
using Newtonsoft.Json;

public partial class ViewEnquiryLog : BasePage
{
    #region Global Variables

    private EnquiryLogManager _enquiryLogManager = new EnquiryLogManager();
    private EnquiryManager _enquiryManager = new EnquiryManager();
    private QuotationManager _quotationManager = new QuotationManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindEnquiryLog();
    }

    #endregion

    #region Grid Events
    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                var quotationID = long.Parse(dataKeyArray.Values["QuotationID"].ToString());
                var vendorID = int.Parse(dataKeyArray.Values["VendorID"].ToString());
                var enquiry = (Enquiry)dataKeyArray.Values["Enquiry"];
                var dataListEnquiryLog = (DataList)e.Row.FindControl("dataListEnquiryLog");
                var enquiryLog = (List<EnquiryLog>)ViewState["EnquiryLog"];
                var data = enquiryLog.Where(x => x.Enquiry.EnquiryLabel == enquiry.EnquiryLabel &&
                    x.User.UserID == vendorID).OrderByDescending(x => x.CreatedDate).ToList(); //x.QuotationID == quotationID
                dataListEnquiryLog.Visible = data.Count > 0;
                dataListEnquiryLog.DataSource = data;
                dataListEnquiryLog.DataBind();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Quotation>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Enquiries",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "EnquiryLabel", "EnquiryStatus.StatusName", "IsGeneralEnquiry", "CreatedDate", "ProductName", "Quantity", "UOM.UnitName", "DeliveryLocation", "ModifiedDate" });
    }

    #endregion

    #region Private Methods
    private void BindEnquiryLog()
    {
        string enquiryLabel = "";
        if (!string.IsNullOrEmpty(Request.QueryString["ID"]))
            enquiryLabel = Request.QueryString["ID"].ToString();
        else
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid request.", CLB.Enums.MessageType.Info);
            return;
        }

        var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor });

        var quotations = _quotationManager.GetQuotations(enquiryLabel: enquiryLabel).OrderByDescending(x => x.CreatedDate).ToList();
        var enquiryLog = _enquiryLogManager.GetEnquiryLog(enquiryLabel: enquiryLabel).OrderByDescending(x => x.CreatedDate).ToList();
        var enquiryList = _enquiryManager.GetEnquiries(enquiryLabel: enquiryLabel);

        //ENQUIRY DETAILS ARE FETCHED FROM DB. DONT Bind the details here
        enquiryLog.ForEach(x => x.Enquiry = enquiryList.FirstOrDefault(y => y.EnquiryID == x.EnquiryID));

        //User details are not fetched from db. Bind the details here
        quotations.ForEach(x => x.Vendor = users.FirstOrDefault(y => y.UserID == x.VendorID));

        ViewState["EnquiryLog"] = enquiryLog;

        //var groupedQuotations = new List<Quotation>();

        //group enquiries for multi item view
        var groupedQuotations = from quotation in quotations
                                    group quotation by new
                                    {
                                        quotation.Enquiry.EnquiryLabel,
                                        quotation.VendorID
                                    } into gql
                                    select gql.FirstOrDefault();

        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = groupedQuotations.ToList();
        gridview.DataBind();
    }

    #endregion
}