﻿/* 
Tekkispace Copyright (C) 2015
Satya
All Righs reserved
*/
/*
    $("span[id^=foo]") >> selector matches all spans that have an id attribute and it starts with foo (e.g. fooblah)
    $("span[id$=foo]") >> selector matches all spans that have an id attribute and it ends with foo (e.g. blahfoo)
    $("span[id*=foo]") >> selector matches all spans that have an id attribute and it has foo somewhere within in it (e.g. blahfooblah)
*/
var validchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890:,.!'+)(-@*_-$/%& ";


/* **************************************** */
/* Function to build auto complete dropdown */
/* **************************************** */
(function ($) {
    $.widget("ui.combobox", {
        _create: function () {

            var self = this,
					select = this.element.hide(),
					selected = select.children(":selected"),
					value = selected.val() ? selected.text() : "";

            //set an attribute to dropdownlist to identify the control during validations
            $(select).attr({ 'isAutoSuggest': 'true' });
            var input = this.input = $("<input>")
                .attr({ id: 'txt' + $(select).attr('id'), disabled: $(select).attr('disabled') })
                .insertAfter(select)
                .val(value)
                .autocomplete({
                    delay: 0,
                    minLength: 0,
                    source: function (request, response) {
                        var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), "i");
                        response(select.children("option").map(function () {
                            var text = $(this).text();
                            if (this.value && (!request.term || matcher.test(text)))
                                return {
                                    label: text.replace(
                                        new RegExp(
                                            "(?![^&;]+;)(?!<[^<>]*)(" +
                                                $.ui.autocomplete.escapeRegex(request.term) +
                                                ")(?![^<>]*>)(?![^&;]+;)", "gi"
                                        ), "<b>$1</b>"),
                                    value: text,
                                    option: this
                                };
                        }));
                    },
                    select: function (event, ui) {
                        ui.item.option.selected = true;
                        self._trigger("selected", event, {
                            item: ui.item.option
                        });
                        //check if function is declared in the page where combobox function is called
                        if (typeof (fnAutoDropdownChange) != "undefined") {
                            fnAutoDropdownChange(select);
                        }
                    },
                    change: function (event, ui) {
                        if (!ui.item) {
                            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex($(this).val()) + "$", "i"),
                                valid = false;
                            select.children("option").each(function () {
                                if ($(this).text().match(matcher)) {
                                    this.selected = valid = true;
                                    return false;
                                }
                            });
                            if (!valid) {
                                /* dont ptompt user with message invalid input 10-Jun-2014 */
                                //alert('Invalid input');
                                // remove invalid value, as it didn't match anything
                                $(this).val("");
                                select.val("");
                                input.data("ui-autocomplete").term = "";
                                return false;
                            }
                        }
                    }
                })
                .addClass('std_select std_smedium')
                .css({ 'width': select.width(), 'height': select.height() });


            input.data("ui-autocomplete")._renderItem = function (ul, item) {
                return $("<li></li>")
						.data("ui-autocomplete-item", item)
						.append("<a>" + item.label + "</a>")
						.appendTo(ul);
            };

            this.button = $("<button>&nbsp;</button>")
                       .attr("tabIndex", -1)
                       .attr("title", "Show All Items")
                       .insertAfter(input)
                       .css({ '-moz-appearance': 'menulist', '-webkit-appearance': 'menulist' })
                       .click(function () {
                           if ($(select).attr('disabled') == 'disabled') return false;
                           // close if already visible
                           if (input.autocomplete("widget").is(":visible")) {
                               input.autocomplete("close");
                               return false;
                           }

                           // pass empty string as value to search for, displaying all results
                           input.autocomplete("search", "");
                           input.focus();
                           return false;
                       });
            //apply only on chrome
            if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1)
                this.button.button({
                    icons: {
                        primary: "ui-icon-triangle-1-s"
                    },
                    text: false
                }).css({ 'height': '17px', 'width': '17px', 'margin-left': '-25px', 'vertical-align': 'sub' })
                        .addClass("ui-corner-right ui-button-icon");
            else {
                this.button.css({
                    'height': '20px', 'width': '19px', 'background': 'url("../images/dropdown.png") no-repeat center center',
                    'background-size': '20px 20px',
                    'border': 'none', 'margin-left': '-25px'
                });
            }
        },
        destroy: function () {
            this.input.remove();
            this.button.remove();
            this.element.show();
            $.Widget.prototype.destroy.call(this);
        }
    });
})(jQuery);

var jsFns = {
    ClearAuditCookie: function () {
        // Delete a cookie by setting the date of expiry to yesterday
        var date = new Date();
        date.setDate(date.getDate() - 1);
        document.cookie = escape('auditColumnState') + '=;expires=' + date;
    },
    ClearFields: function (hdnId, page) { //function to clear all fields
        //clear radio buttons
        $('input[type=radio]').attr('checked', false);
        $('td.radio').css('border', 'none');
        //clear textboxes, remove error class and set default css class
        $('input[type=text]').val('');
        //loop each textbox and set back existing class
        $('input[type=text]').each(function (index, item) {
            $(item).addClass('std_input');
        });

        $('input[type=text]').removeClass("std_errorcontrol std_ierror");

        //clear text area
        $('textarea').val('');
        $('textarea').text('');
        $('textarea').removeClass("std_errorcontrol std_ierror");
        $('textarea').addClass('std_input');

        //clear password fields, remove error class and set default css class
        $('input[type=password]').val('');
        $('input[type=password]').removeClass("std_errorcontrol std_ierror");
        $('input[type=password]').addClass('std_input');

        if (hdnId != null)
            $('input[id*=' + hdnId + ']').val('');

        //clear dropdowns, remove error class and set default css class
        $('select').val('');
        $('select').removeAttr('disabled');
        $('select').each(function (index, element) {
            //check if dropdown type is autosuggest and clear associated textbox
            if ($(element).attr('isAutoSuggest') != undefined) {
                $('#txt' + $(element).attr('id')).val('');
            }
            $(element).addClass('std_select');
        });
        $('select').removeClass("std_serror");
        return false;
    },
    CheckString: function () { /* Special character */
        //get the keycode when the user pressed any key in application
        var exp = String.fromCharCode(window.event.keyCode);
        if (validchars.indexOf(exp) < 0 || validchars.indexOf(exp) > validchars.length) {
            window.event.keyCode = 0;
            return false;
        }
    },
    ConfirmDelete: function (arg) {
        return (confirm("Are you sure you want to delete " + arg + " ?"));
    },
    ConfirmSubmit: function (arg) {
        return (confirm("Are you sure you want to " + arg + " !"));
    },
    DatePicker: function (controltoload, mindate, maxdate) {
        var currentTime = new Date();
        var month = currentTime.getMonth();
        var day = currentTime.getDate();
        var year = currentTime.getFullYear();
        var fSDate = new Date(year, month, day);
        var fEDate = new Date(year, (month - 2), day);
        controltoload.datepicker({
            showStatus: true,
            numberOfMonths: 2,
            showOtherMonths: false,
            dateFormat: 'dd-mm-yy',
            showOn: "both",
            buttonImage: "images/calendar.png",
            buttonImageOnly: true,
            showAnim: 'fadeIn',
            minDate: (mindate == undefined ? fEDate : mindate),
            maxDate: (maxdate == undefined ? fSDate : maxdate),
            showButtonPanel: true,
            closeText: 'Clear',
            onClose: function (dateText, inst) {
                if ($(window.event.srcElement).hasClass('ui-datepicker-close')) {
                    $(this).val('');
                }
            }
        });
    },
    DatePickers: function (fromdatecontrol, todatecontrol, minday, maxday) {
        fromdatecontrol.datepicker({
            showStatus: true,
            numberOfMonths: 2,
            showOtherMonths: false,
            dateFormat: 'dd-mm-yy',
            minDate: minday,
            maxDate: maxday,
            showOn: "both",
            buttonImage: "images/calendar.png",
            buttonImageOnly: true,
            showAnim: 'fadeIn',
            onSelect: function (dateStr) {
                var min = $(fromdatecontrol).datepicker('getDate') || new Date(); // Selected date or today if none
                min.setDate(min.getDate() + 1);
                todatecontrol.datepicker('option', { minDate: min, maxDate: maxday });
                //todatecontrol.focus();
            },
            showButtonPanel: true,
            closeText: 'Clear',
            onClose: function (dateText, inst) {
                if ($(window.event.srcElement).hasClass('ui-datepicker-close')) {
                    $(this).val('');
                }
            }
        });

        todatecontrol.datepicker({
            showStatus: true,
            numberOfMonths: 2,
            dateFormat: 'dd-mm-yy',
            showOn: "both",
            buttonImage: "images/calendar.png",
            buttonImageOnly: true,
            showAnim: 'fadeIn',
            maxDate: maxday,
            showButtonPanel: true,
            closeText: 'Clear',
            onClose: function (dateText, inst) {
                if ($(window.event.srcElement).hasClass('ui-datepicker-close')) {
                    $(this).val('');
                }
            }
        });

    },
    EncryptPassword: function (element) {
        $.ajax({
            async: false,
            type: "POST",
            url: "AjaxService.asmx/EncryptPassword",
            data: "{password: '" + $.trim($(':input[name$=txtPassword]').val()) + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                //alert(msg.d);
                $(element).val(msg.d);
                return true;
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText + " \n " + status + " \n " + error);
            }
        });
        return true;
    },
    HideProcessing: function () {
        $('#divProcessing').hide();
    },
    HighlightControl: function (element) {
        $(element).addClass("std_errorcontrol");
        if ($(element).is("input[type=text]") || $(element).is("input[type=password]") || $(element).is("textarea")) {
            $(element).removeClass('std_input');
            $(element).removeClass('std_ifilled');
            $(element).addClass('std_ierror');
        } else if ($(element).is("input[type=radio]")) {
            $('#' + $(element).attr('id').split('_')[0]).css({ 'border': '1px Solid Red', 'padding': '5px' });
            //$(element).css({ 'border': '1px Solid Red', 'padding': '5px' });
        } else if ($(element).is("input[type=checkbox]")) {
            $('#' + $(element).attr('id').split('_')[0]).css({ 'outline': '2px Solid Red' });
        } else if ($(element).is("select")) {
            //check if dropdown type is autosuggest and highlight associated textbox
            if ($(element).attr('isAutoSuggest') != undefined) {
                $('#txt' + $(element).attr('id')).removeClass('std_input');
                $('#txt' + $(element).attr('id')).removeClass('std_ifilled');
                $('#txt' + $(element).attr('id')).addClass('std_ierror');
            }
            $(element).removeClass('std_select');
            $(element).addClass('std_serror');
        }
    },
    /* set css class for fields and add validation check on events */
    InitializeControls: function (controlstoSkip, parentControlId) {
        var controlstoSkipArray;
        if (controlstoSkip != null)
            controlstoSkipArray = controlstoSkip.split(',');
        var parentControls = (parentControlId == null) ? $('.std_fieldset') : $('#' + parentControlId);

        parentControls.each(function (index, parentControl) {
            //normal text fields
            $(parentControl).find(':input[type=text]').each(function (i, item) {
                var found = $.inArray($(item).attr('id'), controlstoSkipArray) > -1;
                //skip next lines of code and continue the loop
                if (!found) {
                    $(item).keypress(function () { jsFns.CheckString(); });
                    $(item).blur(function () { $(item).val(jsFns.RemoveSpecialChar(item)); });
                }
            });

            //password text fields
            $(parentControl).find(':input[type=password]').each(function (i, item) {
                var found = $.inArray($(item).attr('id'), controlstoSkipArray) > -1;
                if (found)
                    //skip next lines of code and continue the loop
                    return true;

                //add special character check on keypress event
                $(item).keypress(function () { jsFns.ValidPasswordChars(item) });
                //add special character check on blur event-specially when copy-paste is done
                $(item).blur(function () { jsFns.ValidPasswordChars(item) });
            });

            //select fields
            $(parentControl).find('select').each(function (i, item) {

            });

            //span tooltip fields    
            $(parentControl).find('span[id*=tooltip]').each(function (i, item) {
                $(item).addClass('std_tooltip');
            });

            //find datepicker controls
            $(parentControl).find('.std_idate').each(function (i, item) {
                $(item).attr({ readonly: 'readonly', maxlength: '10', clientidmode: 'static' });
            });
        });

        /* audit can be applied on a  maximum of 5 grids in a single page  
        value can be increased by changing the value of auditLimit variable
        */
        var auditLimit = 5;
        for (var p = 0; p < auditLimit; p++) {
            var ctrlSfx = p > 0 ? p.toString() : '';
            //check if control exits, skip loop if not
            if ($('#cboxAudit' + ctrlSfx).length == 0)
                continue;
            //show/hide audit fields in grid view
            $('#cboxAudit' + ctrlSfx).click(function () {
                var tmpSfx = $.trim($(this).attr('id').replace('cboxAudit', ''));
                if (tmpSfx.length > 0) tmpSfx = '.' + tmpSfx;
                $('.std_audit' + tmpSfx).toggle();
                var now = new Date();
                //set cookie expiry time
                var time = now.getTime() + (3600 * 1000);
                now.setTime(time);
                document.cookie = 'auditColumnState' + tmpSfx + '=' + escape($('#cboxAudit' + tmpSfx).is(":checked")) + '; expires=' + now.toGMTString() + ';';
            });
        }

        if (document.cookie.length > 0) {
            for (var y = 0; y < auditLimit; y++) {
                var ckieSfx = y > 0 ? y.toString() : '';
                //check if control exits, skip loop if not
                if ($('#cboxAudit' + ckieSfx).length == 0)
                    continue;
                //declare cookie name
                var cname = 'auditColumnState' + ckieSfx;
                //get cookie index
                var cstart = document.cookie.indexOf(cname + '=');
                //check if cookie exists
                if (cstart != -1) {
                    //get cookie value
                    cstart = cstart + cname.length + 1;
                    var cend = document.cookie.indexOf(";", cstart);
                    if (cend == -1) {
                        cend = document.cookie.length;
                    }
                    //check if value is set to true
                    if (unescape(document.cookie.substring(cstart, cend)) == 'true') {
                        $('.std_audit' + ckieSfx).show();
                        $('#cboxAudit' + ckieSfx).attr('checked', true);
                    } else {
                        $('.std_audit' + ckieSfx).hide();
                        $('#cboxAudit' + ckieSfx).attr('checked', false);
                    }
                }
            }
        };
    },
    IsNumberKey: function (evt, isInteger) {
        var charCode = (evt.which) ? evt.which : event.keyCode;
        //allow dots
        if (isInteger == null) {
            if (charCode == 46)
                return true;
        }
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
        return true;
    },
    IsNumeric: function (str) {/* Number validation */
        str = $.trim(str);
        var retval = true;
        var num = "1234567890";
        var i;
        //alert(num.charAt(i));  
        for (i = 0; i < str.length; i++) {
            if (num.indexOf(str.charAt(i)) < 0 || num.indexOf(str.charAt(i)) > num.length) {
                str = str.replace(str.charAt(i), '');
                retval = false;
            }
        }
        return retval;
    },
    IsValidFile: function (source, args) {
        try {
            var fileAndPath = document.getElementById(source.controltovalidate).value;
            var lastPathDelimiter = fileAndPath.lastIndexOf("\\");
            var fileNameOnly = fileAndPath.substring(lastPathDelimiter + 1);
            var file_extDelimiter = fileNameOnly.lastIndexOf(".");
            var file_ext = fileNameOnly.substring(file_extDelimiter + 1).toLowerCase();
            var validformats = ["doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf", "jpg", "png", "jpeg", "bmp", "jpeg"];
            if ($.inArray(file_ext, validformats) == -1) {
                args.IsValid = false;
                return;
            }
        }
        catch (err) {
            txt = "There was an error on this page.\n\n";
            txt += "Error description: " + err.description + "\n\n";
            txt += "Click OK to continue.\n\n";
            txt += document.getElementById(source.controltovalidate).value;
            alert(txt);
        }
        args.IsValid = true;
    },
    IsValidForm: function (rules, messages) {
        //for Single pages, id remains form1, for content pages id dynamically changes to form 2
        var formId = $('#form1').length > 0 ? 'form1' : 'aspnetForm';
        // hook up the form, the validation rules, and messages with jQuery validate.
        var showErrorMessage = false;
        var validator = $('#' + formId).validate({
            //update validations dynamically on text change
            onchange: true,
            //validation rules ex: email, required field etc..
            rules: rules,
            //custom error messages
            messages: messages,
            //set appropriate error css class on error
            highlight: function (element) {
                jsFns.HighlightControl(element);
            },
            //remove error css class on correction
            unhighlight: function (element) {
                jsFns.UnHighlightControl(element);
            },
            errorPlacement: function (error, element) {
                //hide error message for radio buttons
                if (!$(element).is("input[type=radio]")) {
                    $(element).addClass("std_errorcontrol");
                    error.insertAfter(element);
                }
            },
            success: function (label) {

            }
            //load error container on error occurance
            //                showErrors: function (errorMap, errorList) {

            //                    this.defaultShowErrors();
            //                }
        });

    },
    IsValidEmailAddress: function (emailAddress) {
        emailAddress = $.trim(emailAddress);
        var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
        return pattern.test(emailAddress);
    },
    IsValidEmailandSMS: function (emailidscontrol, phonenoscontrol) {        
        if ($.trim($('#' + emailidscontrol).val()) == '' && $.trim($('#' + phonenoscontrol).val()) == '')
            return true;
        var emailarray = $('#' + emailidscontrol).val().split(",");
        var invalidEmails = '';
        var sorted_emailarr = emailarray.sort();
        var dupemails = [];
        $.each(emailarray, function (i, item) {
            //check if valid email
            if (!jsFns.IsValidEmailAddress(item)) {
                if (invalidEmails != '') invalidEmails += ', ';
                invalidEmails += item;
            }
            //check if duplicate entry
            if (sorted_emailarr[i + 1] == sorted_emailarr[i]) {
                dupemails.push(sorted_emailarr[i]);
            }
        });

        var phonearray = $('#' + phonenoscontrol).val().split(",");
        var invalidNumbers = '';
        var sorted_phnarr = phonearray.sort();
        var dupnos = [];
        $.each(phonearray, function (i, item) {
            //check if valid phone
            if (!jsFns.IsNumeric(item) || item.length < 10) {
                if (invalidNumbers != '') invalidNumbers += ', ';
                invalidNumbers += item;
            }
            //check if duplicate entry
            if (sorted_phnarr[i + 1] == sorted_phnarr[i]) {
                dupnos.push(sorted_phnarr[i]);
            }
        });

        if (dupemails.length > 0 || dupnos.length > 0) {
            if (dupemails.length > 0) jsFns.ShowMessage('Duplicate Email(s): ' + dupemails, 'warning');
            if (dupnos.length > 0) jsFns.ShowMessage('Duplicate Phone numbers(s): ' + dupnos, 'warning');
            return false;
        }
        if (invalidEmails != '' || invalidNumbers != '') {
            if (invalidEmails != '') jsFns.ShowMessage('Invalid Email(s): ' + invalidEmails, 'warning');
            if (invalidNumbers != '') jsFns.ShowMessage('Invalid Phone numbers(s): ' + invalidNumbers, 'warning');
            return false;
        }
        return true;
    },
    InValidPasswordMsg: function (pswd) {
        //validate the length
        if (pswd.length < 8) return 'Password must be at least 8 characters';
        //validate letter
        if (!pswd.match(/[A-z]/)) return 'At least one letter is required';

        //validate capital letter
        if (!pswd.match(/[A-Z]/)) return 'At least one capital letter is required';

        //validate number
        if (!pswd.match(/\d/)) return 'At least one number is required';
        return true;
    },
    IsValidPassword: function (pswd) { /* Function to check if valid password */
        //validate the length
        if (pswd.length < 8) return false;
        //validate letter
        if (!pswd.match(/[A-z]/)) return false;

        //validate capital letter
        if (!pswd.match(/[A-Z]/)) return false;

        //validate number
        if (!pswd.match(/\d/)) return false;
        return true;
    },
    IsValidPhone: function (str) { /* Function to check if valid phone no */
        var retval = true;
        //var num = "1234567890-";
        var num = "1234567890";
        var i;
        //alert(num.charAt(i));  
        for (i = 0; i < str.value.length; i++) {
            if (num.indexOf(str.value.charAt(i)) < 0 || num.indexOf(str.value.charAt(i)) > num.length) {
                str.focus();
                retval = false;
            }
        }
        return retval;
    },
    LoadGridSearch: function (data, controltoLoad) {
        if (data != [] && data != null && data != '') {
            data = $.parseJSON(data);
            controltoLoad.autocomplete({
                source: data
            });
        }
    },
    RemoveSpecialChar: function (val) {
        var tempVal = val.value;
        for (var i = 0; i < tempVal.length; i++) {
            if (validchars.indexOf(tempVal.charAt(i)) < 0 || validchars.indexOf(tempVal.charAt(i)) > validchars.length) {
                val.value = val.value.replace(tempVal.charAt(i), '');
            }
        }
        return val.value;
    },
    ShowMessage: function (message, type) {
        $('span[id$=lblStatusMessage]').html("<div class='" + type.toLowerCase() + "'>" +
            "<img src='images/close_icon.gif' alt='close' style='float:right; vertical-align:top; cursor: pointer;' onclick='$(this).parent().remove();'/>" +
            message + "</div>");
        $('html, body').animate({ scrollTop: '0px' }, 600);
    },
    ShowPopup: function (displaycontrol) {
        $.colorbox({
            fixed: true,
            inline: true, width: "40%", open: true, scrolling: false, href: "#" + displaycontrol,
            onClosed: function () {
            },
            onOpen: function () {
                //$("div#colorbox").appendTo("form");                
            },
            onComplete: function () {
            }
        });
    },
    ShowProcessing: function () {
        $('span[id$=lblStatusMessage]').html('');
        $('#divProcessing').show();
        $('.std_modalContainer').focus();
    },
    StripHTML: function (str) {
        var strippedText = $("<div/>").html(str).text();
        return strippedText;
    },
    UnHighlightControl: function (element) {
        $(element).removeClass("std_errorcontrol");
        if ($(element).is("input[type=text]") || $(element).is("input[type=password]") || $(element).is("textarea")) {
            if ($(element).val() != '')
                $(element).addClass('std_input std_ifilled');
            else
                $(element).addClass('std_input');
            $(element).removeClass('std_ierror');
        } else if ($(element).is("input[type=radio]")) {
            $('#' + $(element).attr('id').split('_')[0]).css({ 'border': 'none', 'padding': '0px' });
        } else if ($(element).is("input[type=checkbox]")) {
            $('#' + $(element).attr('id').split('_')[0]).css({ 'outline': 'none' });
        } else if ($(element).is("select")) {
            if ($(element).val() != '') {
                //check if dropdown type is autosuggest and unhighlight associated textbox
                if ($(element).attr('isAutoSuggest') != undefined) {
                    $('#txt' + $(element).attr('id')).addClass('std_input std_ifilled');
                    $('#txt' + $(element).attr('id')).removeClass('std_ierror');
                }
                $(element).addClass('std_select std_filled');
            } else {
                //check if dropdown type is autosuggest and unhighlight associated textbox
                if ($(element).attr('isAutoSuggest') != undefined) {
                    $('#txt' + $(element).attr('id')).addClass('std_input');
                    $('#txt' + $(element).attr('id')).removeClass('std_ierror');
                }
                $(element).addClass('std_select');
            }
            $(element).removeClass('std_serror');
        }
    },
    ValidateControls: function (parentControlId, controlstoSkip) {
        var isValid = true;
        var controlstoSkipArray;        
        if (controlstoSkip != null)
            controlstoSkipArray = controlstoSkip.split(',');
        var $group = (parentControlId == null || parentControlId == '') ? $('.std_fieldset') : $('#' + parentControlId);
        if ($group.find(':input').length == 0)
            alert('No controls found in ' + parentControlId);
        $group.find(':input').each(function (i, item) {
            var found;
            if (!$(item).is("input[type=submit]")) {
                if ($(item).is("input[type=checkbox]") || $(item).is("input[type=radio]"))
                    found = $.inArray($(item).attr('id').split('_')[0], controlstoSkipArray) > -1;
                else
                    found = $.inArray($(item).attr('id'), controlstoSkipArray) > -1;

                if (!found) { //skip validation on specific control
                    if (!$(item).valid())
                        isValid = false;
                } else {
                    jsFns.UnHighlightControl(item);
                }

            }
        });
        if (!isValid)
            jsFns.ShowMessage('Fields marked with <span class="required">*</span>are mandatory', 'info');
        return isValid;
    },
    ValidPasswordChars: function (control) {
        for (var i = 0; i < control.value.length; i++) {
            if (validchars.indexOf(control.value.charAt(i)) < 0 || validchars.indexOf(control.value.charAt(i)) > validchars.length) {
                control.value = '';
                control.focus();
            }
        }
    },
    //function to validate textarea on keyup, keydown and onblur events
    ValidateTextArea: function (isOnblur) {
        var url = 'www.ProcureMENA.com';
        var cntfield = $('#charCnt');
        var field = $('#txtContent');
        var maxlimit = 140 - (url.length);
        var NewLinesArr = new Array();
        var FieldLength = field.val().length;
        var DeductChar = maxlimit - ((FieldLength - field.val().length));
        var SubStrVal = field.val().substring(0, DeductChar);

        //check if event is fired on keyup or keydown events
        if (!isOnblur) {

            if (FieldLength > maxlimit) // if too long...trim it!
            {
                field.val(SubStrVal);
                jsFns.ShowMessage("Message can have a maximum of " + maxlimit + " characters only", 'info');
                cntfield.html(((maxlimit - FieldLength) > 0 ? (maxlimit - FieldLength) : 0) + ' characters left');
                return false;
            }
            else// otherwise, update \'characters left\' counter
            {
                cntfield.html((maxlimit - FieldLength) + ' characters left');
            }
        }
        else {
            var SubStrVal = field.val();
            SubStrVal = SubStrVal.replace(/[\s\n\r]+/g, ' ');
            //SubStrVal = SubStrVal.replace(/\s+/g, " ");        
            field.val(SubStrVal);
            FieldLength = field.val().length;
            //SubStrVal = SubStrVal.replace("  ", " ");
        }
        //check if Content text is not empty
        if ($.trim(field.val()).length > 0) {
            //lblContent text is set in this function
            $('#tdContent').show();
            cntfield.html((maxlimit - FieldLength) + ' characters left');
        }
        else {
            $('#lblContent').html('');
            $('#twitttxt').val('');
            $('#tdContent').hide();
            cntfield.html('140 characters left');
        }
    }
};

//function to load active tab
function fnLoadAccordion(arg) {
    if (arg != null) {
        $('#accordion').accordion({ active: parseInt(arg), autoHeight: false });
        $('.accordion').accordion({ active: parseInt(arg), autoHeight: false });
    } else {
        $('#accordion').accordion({ active: parseInt(arg), autoHeight: false });
        $('.accordion').accordion({ active: parseInt(arg), autoHeight: false });
    }
}