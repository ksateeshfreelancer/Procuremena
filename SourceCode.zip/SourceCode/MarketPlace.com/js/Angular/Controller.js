﻿app.controller("myCntrl", function ($scope, angularService) {    
    //$scope.divEnquiry = false;        
    //To search results
    $scope.resultsli = false;
    $scope.getProducts = function (pageNo) {        
        jsFns.ShowProcessing();
        var getData = angularService.getProducts(pageNo);
        getData.then(function (result) {
            var resultsPerPage = 4;
            var pagerCount = 4;
            if (result.status != 200) {
                alert('No listings match your criteria. Please expand your search.');
                return;
            }
            result = result.data.d;
            var totalPageCount = parseInt(result.count / resultsPerPage);
            //if prod count is 6 then show 2 prods in 2nd page
            if ((result.count / resultsPerPage) > (result.count % resultsPerPage))
                totalPageCount++;

            $scope.productlist = result;
            $scope.resultsli = true;
            jsFns.HideProcessing();

            $('#lblStatusMessage').show();
            $('#divresults').show();
            //******* Pagination logic starts *************//

            var ul = $('<ul>').attr('class', 'pagination');
            //decreasing pageNo count for building paging
            if (pageNo % pagerCount == 0)
                pageNo = pageNo - 1;
            //indicates first group.. no prev button required
            if (pageNo > pagerCount) {
                ul.append($("<li>").append($("<a>").attr(
                    {
                        //"href": "javascript:void(0)",
                        "aria-label": "Previous",
                        "ng-click": "getProducts(" + parseInt(pageNo / pagerCount) + ")"
                    }).append($("<span>").attr('aria-hidden', 'true').html('&laquo;'))));
            }
            for (var i = 1; i <= pagerCount; i++) {
                //add only 4 pages
                if (i > totalPageCount) continue;                
                ul.append($("<li>").append($("<a>").attr({
                    "href": "javascript:void(0)",
                    "ng-click": "getProducts(" + parseInt((pageNo / pagerCount) + i) + ");"
                }).text(parseInt((pageNo / pagerCount) + i))));
            }
            //indicates last page.. no next button required
            if ((totalPageCount - pageNo) > pagerCount) {
                ul.append($("<li>").append($("<a>").attr(
                    {
                        "href": "javascript:void(0)",
                        "aria-label": "Previous",
                        "ng-click": "getProducts(" + parseInt((pageNo / pagerCount) + pagerCount + 1) + ")"
                    }).append($("<span>").attr('aria-hidden', 'true').html('&raquo;'))));
            }            
            $scope.ulnav = ul;
            //******* Pagination logic ends *************//

        }, function () {
            alert('Error in getting records');
        });
    }

    $scope.getProducts(1);

    //called when user clicks on send enquiry button
    $scope.showPopup = function (id) {
        $('.std_quote').colorbox({
            href: 'GetQuote?T=P&ID=' + id,
            iframe: true, width: "70%", height: "80%", top: '5% !important',
            left: '15% !important', onClosed: function (arg) {
                if (typeof (callbackOnClose) !== 'undefined' && typeof (callbackOnClose) === 'function')
                    callbackOnClose();
            }
        });
    };

    //called when user clicks on search button
    $scope.setSearchInfo = function () {
        var getData = angularService.setSearchInfo($scope.productName);
        getData.then(function (result) {
            window.location.href = "Search?P=" + $scope.productName;
        }, function () {
            alert('Error in getting records');
        });
    }

    //load auto complete in search results page
    $scope.complete = function (ctrl) {
        $(ctrl).autocomplete({
            source: function (request, response) {
                var getData = angularService.getautoComplete($scope.productName);
                getData.then(function (result) {
                    response($.map(result.data.d, function (item) {
                        return { value: item }
                    }))
                }, function () {
                    alert('Error in getting records');
                });
            },
            select: function (event, ui) {
                $scope.productName = ui.item.label;
                //var UIvalue = ui.item.value;
                //return false;
            },
            minLength: 2   // MINIMUM 2 CHARACTERS TO START WITH.
        });      
    }

    $scope.SendEnquiry = function ()
    {
        var Enquiry = {
            Name: $scope.employeeName,
            Email: $scope.employeeEmail,
            Age: $scope.employeeAge
        };
        var getAction = $scope.Action;

        if (getAction == "Update") {
            Enquiry.Id = $scope.employeeId;
            var getData = angularService.updateEmp(Enquiry);
            getData.then(function (msg) {
                $scope.employees = null;
                GetAllEmployee();
                alert(msg.data);
                $scope.divEmployee = false;
            }, function () {
                alert('Error in updating record');
            });
        } else {
            var getData = angularService.AddEmp(Employee);
            getData.then(function (msg) {
                GetAllEmployee();
                alert(msg.data);
                $scope.divEmployee = false;                
            }, function () {
                alert('Error in adding record');
            });
        }
    }

    $scope.AddEmployeeDiv=function()
    {
        ClearFields();
        $scope.Action = "Add";
        $scope.divEmployee = true;
    }
    
    function ClearFields() {
        $scope.employeeId = "";
        $scope.employeeName = "";
        $scope.employeeEmail = "";
        $scope.employeeAge = "";
    }
});