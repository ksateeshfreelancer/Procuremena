﻿app.service("angularService", function ($http) {

    //get search results
    this.getProducts = function (pageno) {
        var parameters = { pageNo: pageno };
        var response = $http({
            method: "post",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            url: "AjaxService.asmx/SearchProducts",
            data: JSON.stringify(parameters)
        });
        return response;
    };

    //save search info
    this.setSearchInfo = function (pname) {        
        var parameters = { category: '', subCategory: '', product: pname };
        var response = $http({
            method: "post",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            url: "AjaxService.asmx/SetSearchInformation",
            data: JSON.stringify(parameters)
        });
        return response;
    };

    //load auto complete in search results page
    this.getautoComplete = function (pname) {
        var parameters = { inputText: pname };
        var response = $http({
            method: "post",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            url: "AjaxService.asmx/GetAutoSearchCompleteList",
            data: JSON.stringify(parameters)
        });
        return response;
    };

    // Add Employee
    this.AddEmp = function (employee) {
        var response = $http({
            method: "post",
            url: "Home/AddEmployee",
            data: JSON.stringify(employee),
            dataType: "json"
        });
        return response;
    }
});