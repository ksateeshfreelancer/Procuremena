﻿using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CLB.BL;
using CLB.DTO;
using CLB.BL.Administration;
using CLB.Enums;

public partial class Administration_ManageRoles : BasePage
{
    #region Global Variables

    private RoleManager _roleManager = new RoleManager();
    public UserRole usersPageMode;

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {        
        if (IsPostBack) return;
        BindRoles();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            var duplicates = "";
            var isLoopBreak = false;
            var counter = 0;
            var roles = new List<Role>();
            var totalRoles = GetCachedRoles();
            foreach (DataListItem item in dataList.Items)
            {
                counter++;
                var hdnRoleID = (HiddenField)item.FindControl("hdnRoleID");
                var txtRoleName = (TextBox)item.FindControl("txtRoleName");
                var cblFeatures = (CheckBoxList)item.FindControl("cblFeatures");
                
                List<ListItem> selectedFeatures = cblFeatures.Items.Cast<ListItem>().Where(li => li.Selected).ToList();

                //skip empty strings
                if (selectedFeatures.Count == 0 && IsEmpty(txtRoleName)) continue;

                if (selectedFeatures.Count == 0 || IsEmpty(txtRoleName))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid entries in Row: " + counter + ".",
                        MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }
                //skip duplicates
                if (roles.Any(x => x.RoleName == txtRoleName.Text))
                {
                    if (!string.IsNullOrEmpty(duplicates)) duplicates += ", ";
                    duplicates += counter;
                }
                else if (totalRoles.Any(x => x.RoleName.ToLower().Equals(txtRoleName.Text.Trim().ToLower())))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Role " + txtRoleName.Text + " already exists.", MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                roles.Add(new Role
                {
                    RoleID = int.Parse(hdnRoleID.Value),
                    RoleName = txtRoleName.Text.Trim(),
                    //Level = (CurrentUser.Role.RoleID < 100 ? 1 : (CurrentUser.Referral.Level + (CurrentUser.Referral.RefID == 0 ? 2 : 1))),
                    Screens = (from screen in GetViewStateScreens()
                               where (selectedFeatures.Select(x => int.Parse(x.Value))).Any(x => x == screen.ScreenID)
                               select screen).ToList()
                });
            }

            if (roles.Count == 0 && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("At least one role is required to save.", MessageType.Warning);
                return;
            }

            if (!string.IsNullOrEmpty(duplicates) && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate entries found in " + duplicates + " row(s).", MessageType.Warning);
                return;
            }
            if (!isLoopBreak)
            {
                foreach (var role in roles.Where(x => x.RoleID == 0))
                {
                    lblStatusMessage.InnerHtml = _roleManager.SaveRole(role, out _status);    
                }
                
                //lblStatusMessage.InnerHtml = _roleManager.UpdateRoles(roles.Where(x => x.RoleID > 0), out _status);
            }
            if (_status)
            {
                ClearControls(this);
                //clear viewstate
                GetCachedRoles(true);
                BindRoles();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    protected void dataList_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        try
        {
            DataListItem item = e.Item;
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Utilities.BindControl(GetViewStateScreens().Where(x => x.IsAdminScreen), "DisplayName", "ScreenID", item.FindControl("cblFeatures"));             
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #endregion

    #region Private Methods
    private void BindRoles()
    {
        int noofRoles = 3;
        var roles = new List<Role>();
        //create empty grid with no of roles
        for (int i = 1; i <= noofRoles; i++)
        {
            roles.Add(new Role
            {
                RoleID = 0,
                RoleName = string.Empty,
                Screens = new List<Screen>()
            });
        }
        dataList.DataSource = ViewState["FilterList"] = ViewState["List"] = roles;
        dataList.DataBind();        
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        BindRoles();
    }

    #endregion
}