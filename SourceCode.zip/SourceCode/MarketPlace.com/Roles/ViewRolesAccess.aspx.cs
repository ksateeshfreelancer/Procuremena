﻿using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
public partial class ViewRolesAccess : BasePage
{
    #region Global Variables

    private RoleManager _roleManager = new RoleManager();

    #endregion

    #region Page Methods

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindRoles();
    }
    protected void ibtnDelete_Click(object sender, ImageClickEventArgs e)
    {
        var ibtnDelete = (ImageButton)((Control)sender);
        var hdnDiscussionID = (HiddenField)ibtnDelete.Parent.FindControl("hdnRoleID");
        lblStatusMessage.InnerHtml = _roleManager.DeleteRole(int.Parse(hdnDiscussionID.Value), out _status);
        GetCachedRoles(true);
        BindRoles();
        
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        var btnUpdate = (Button)((Control)sender);

        var roleID = int.Parse(((HiddenField)btnUpdate.Parent.FindControl("hdnRoleID")).Value);
        var roleName = ((TextBox)btnUpdate.Parent.FindControl("txtRoleName")).Text.Trim();
        var cblFeatures = (CheckBoxList)btnUpdate.Parent.FindControl("cblFeatures");
        var allRoles = GetCachedRoles();

        List<ListItem> selectedFeatures = cblFeatures.Items.Cast<ListItem>().Where(li => li.Selected).ToList();

        //check empty strings
        if (string.IsNullOrEmpty(roleName))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Role Name.", MessageType.Warning);
            return;
        }

        //check for duplication
        if (allRoles.Any(x => x.RoleID != roleID && x.RoleName.ToLower().Equals(roleName.ToLower())))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate entries found for Role: " + roleName + ".", MessageType.Warning);
            return;
        }

        var role = new Role
        {
            RoleID = roleID,
            RoleName = roleName,
            Level = 1,
            Screens = (from screen in GetViewStateScreens()
                       where (selectedFeatures.Select(x => int.Parse(x.Value))).Any(x => x == screen.ScreenID)
                       select screen).ToList()
        };

        lblStatusMessage.InnerHtml = _roleManager.SaveRole(role, out _status);

        if (_status)
        {
            GetCachedRoles(true);
            BindRoles();            
        }
    }

    protected void dataListRoles_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        try
        {
            DataListItem item = e.Item;
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var roleID = Convert.ToInt32(((HiddenField)item.FindControl("hdnRoleID")).Value);
                var cblFeatures = (CheckBoxList)item.FindControl("cblFeatures");

                var ibtnDelete = (ImageButton)item.FindControl("ibtnDelete");
                var txtRoleName = (TextBox)item.FindControl("txtRoleName");

                //do not allow super admin to delete predefined roles
                if (roleID < 100)
                {
                    ibtnDelete.Visible = false;
                    txtRoleName.Enabled = false;
                }

                if (roleID == 0) ibtnDelete.Visible = false;

                //load only admin screens for super admin.. Categorizing screens by features is not needed for superadmin
                /* if (IsSuperAdmin)
                 {
                     var adminscreens = GetViewStateScreens(true);
                     var screens = GetViewStateScreens(false);

                     //do not show admin screens for moderator roles
                     if (roleID == 1 || roleID > 100)
                     {
                         screens.AddRange(adminscreens);
                     }
                     Utilities.BindControl(screens, "DisplayName", "ScreenID", cblFeatures);
                     var selectedScreens = GetViewStateRoles().FirstOrDefault(x => x.RoleID == roleID).Screens;
                     foreach (ListItem feature in cblFeatures.Items)
                     {
                         if (selectedScreens.Any(y => y.ScreenID == int.Parse(feature.Value)))
                             feature.Selected = true;
                     }
                 }
                 else*/
                {
                    var screens = GetViewStateScreens();
                    Utilities.BindControl(screens.Where(x => x.IsAdminScreen), "DisplayName", "ScreenID", cblFeatures);
                    var selectedScreens = GetCachedRoles().FirstOrDefault(x => x.RoleID == roleID).Screens;
                    foreach (ListItem feature in cblFeatures.Items)
                    {
                        if (selectedScreens.Any(y => y.ScreenID == int.Parse(feature.Value)))
                            feature.Selected = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #endregion

    #region Private Methods
    private void BindRoles()
    {        
        _roleManager = new RoleManager();
        //retrieve all roles except admin
        var roles = _roleManager.GetRoles().Where(x => x.RoleID >= 100);
        //ViewState["FilterList"] = ViewState["List"] =
        dataListRoles.DataSource = roles;
        dataListRoles.DataBind();
    }

    #endregion

}