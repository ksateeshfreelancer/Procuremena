﻿using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CLB.BL;
using CLB.Enums;
using CLB.DTO;

public partial class Accounts_ManageUsers : BasePage
{
    #region Global Variables

    private UserManager _userManager = new UserManager();
    public UserRole usersPageMode;

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("manageusers")))
        {
            usersPageMode = UserRole.Customer;
        }
        else if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("managestaff")))
        {
            usersPageMode = UserRole.DynamicUser;
        }
        else if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("manageagents")))
        {
            usersPageMode = UserRole.Vendor;
        }        
        if (IsPostBack) return;
        BindUsers();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            var duplicates = "";
            var isLoopBreak = false;
            var counter = 0;
            var allUsers = GetUsers();
            var users = new List<User>();

            foreach (GridViewRow item in gridview.Rows)
            {
                counter++;                
                var firstName = ((TextBox)item.FindControl("txtFirstName")).Text.Trim();
                var lastName = ((TextBox)item.FindControl("txtLastName")).Text.Trim();
                var email = ((TextBox)item.FindControl("txtEmail")).Text.Trim();
                var mobile = ((TextBox)item.FindControl("txtMobile")).Text.Trim();
                var password = ((TextBox)item.FindControl("txtPassword")).Text.Trim();                
                var roleId = ((DropDownList)item.FindControl("ddlRole")).SelectedIndex > 0 ?
                    int.Parse(((DropDownList)item.FindControl("ddlRole")).SelectedValue) : 0;

                //skip empty strings
                if (roleId == 0 && string.IsNullOrEmpty(firstName) && string.IsNullOrEmpty(lastName) && string.IsNullOrEmpty(email)
                    && string.IsNullOrEmpty(mobile)) continue;

                if (roleId == 0 || string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(email)
                    || string.IsNullOrEmpty(mobile))
                {
                    if (usersPageMode == UserRole.DynamicUser && roleId == 0)
                    {
                        lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid entries in Row: " + counter + ".",
                            MessageType.Warning);
                        isLoopBreak = true;
                        break;
                    }
                }

                if (!IsValidEmail((TextBox)item.FindControl("txtEmail")))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Email in Row: " + counter + ".",
                            MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }
                if (!IsValidPhone((TextBox)item.FindControl("txtMobile")))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Mobile in Row: " + counter + ".",
                            MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                //skip duplicates
                if (users.Any(x => x.Email == email || x.Mobile == mobile))
                {
                    if (!string.IsNullOrEmpty(duplicates)) duplicates += ", ";
                    duplicates += counter;
                }
                else if (allUsers.Any(x => (x.Email == email || x.Mobile == mobile)))
                {
                    var duplicateuser = allUsers.FirstOrDefault(x => (x.Email == email || x.Mobile == mobile));
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate entries found for " + duplicateuser.Email + " or " + duplicateuser.Mobile + ".",
                            MessageType.Warning);
                    isLoopBreak = true;
                    break;
                }

                //role selection is enabled only while adding staff
                if (usersPageMode != UserRole.DynamicUser)
                    roleId = (int)usersPageMode;

                users.Add(new User
                {
                    Email = email,
                    InvalidLoginAttempts = 0,
                    IsNewPassword = true,
                    Mobile = mobile,
                    Password = Utilities.GetEncryptedPassword(Utilities.SharedSecret, password),
                    Role = new Role { RoleID = roleId },
                    Status = Status.Active,
                    UserDetails = new UserDetails
                    {
                        UserID = 0,
                        FirstName = firstName,
                        LastName = lastName,
                        RegisteredIP = Utilities.IPAddress,
                        Country = new Country
                        {
                            CountryID = Convert.ToInt32(Session[SessionVariables.CountryId])
                        },
                    }
                });
            }

            if (users.Count == 0 && !isLoopBreak)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("At least one user record is required to save.", MessageType.Warning);
                return;
            }

            if (!string.IsNullOrEmpty(duplicates))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate entries found in " + duplicates +
                    " row(s). Email and MobileNo must be unique for every user.", MessageType.Warning);
                return;
            }
            if (!isLoopBreak)
                lblStatusMessage.InnerHtml = _userManager.SaveUsers(users, out _status);
            if (_status)
            {
                foreach (var newuser in users.Where(x => x.UserID == 0))
                {
                    Utilities.SendEmail(newuser.Email, "New " + usersPageMode.ToString() + " registration",
                        "Dear User, <br/> your account is created successfully. <br/><br/><br/> Login Details:<br/><br/>Username: " +
                        newuser.Email + " or " + newuser.Mobile + "<br/>Password: " + newuser.Password, null,
                        CurrentUser.Email);
                }
                ClearControls(this);
                BindUsers();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #region Grid Events

    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ((TextBox)e.Row.FindControl("txtPassword")).Text = CreateRandomPassword(8, e.Row.RowIndex);                
                Utilities.BindControl(GetFilterRoles(), "RoleName", "RoleID", ((DropDownList)e.Row.FindControl("ddlRole")));
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindUsers()
    {
        int noofUsers = 10;
        var users = new List<User>();
        //create empty grid with no of users
        for (int i = 1; i <= noofUsers; i++)
        {
            users.Add(new User
            {
                UserID = 0,
            });
        }
        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = users;
        gridview.DataBind();
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        BindUsers();
    }

    private List<User> GetUsers()
    {
        if (ViewState["Users"] == null)
        {
            var userManager = new UserManager();
            ViewState["Users"] = userManager.GetUsers();
        }
        return ViewState["Users"] as List<User>;
    }

    private List<CLB.DTO.Role> GetFilterRoles()
    {
        if (ViewState["Roles"] == null)
        {
            var roleManager = new RoleManager();            
            ViewState["Roles"] = roleManager.GetRoles();            
        }
        return ViewState["Roles"] as List<Role>;
    }

    #endregion

}