﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class Users_ManageUser : BasePage
{
    #region Global Variables

    UserManager _userManager = new UserManager();
    public UserRole usersPageMode;

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        txtPassword.Enabled = false;

        if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("manageuser")))
        {
            if (Request.QueryString["UT"] != null)
            {
                usersPageMode = (UserRole)int.Parse(Request.QueryString["UT"].ToString());
            }
            else
            {
                usersPageMode = UserRole.Customer;
            }
        }
        else if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("managevendor")))
        {
            //WE ARE NOT ALLOWING vendor TO BE CREATED HERE AS IT NEEDS SPONSOR ID AND OTHER VALIDATIONS.            
            usersPageMode = UserRole.Vendor;
        }
        else
        {
            usersPageMode = UserRole.DynamicUser;
        }

        Page.Title += (usersPageMode == UserRole.DynamicUser ? "Staff" : usersPageMode.ToString()) + " Details";

        if (IsPostBack)
            return;
        LoadDropdowns();
        int id;
        if (Request.QueryString["ID"] != null && int.TryParse(Utilities.Decrypt(Request.QueryString["ID"]), out id))
        {
            LoadUserDetails(id);
            lbtnResetPassword.Visible = true;
            txtPassword.Visible = false;
        }
        else
        {
            txtPassword.Text = CreateRandomPassword(8);
            lbtnResetPassword.Visible = false;
            txtPassword.Visible = true;
            hdnID.Value = "0";
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        var users = new List<User>();
        var userRole = 0;
        switch (usersPageMode)
        {
            case UserRole.DynamicUser:
                userRole = int.Parse(ddlRole.SelectedValue);
                break;
            default:
                userRole = (int)usersPageMode;
                break;
        }

        var user = new User
        {
            Email = txtEmail.Text.Trim(),
            InvalidLoginAttempts = 0,
            IsNewPassword = true,
            Mobile = txtMobile.Text.Trim(),
            Password = Utilities.GetEncryptedPassword(Utilities.SharedSecret, txtPassword.Text.Trim()),
            Role = new Role { RoleID = userRole },
            Status = (Status)int.Parse(rblStatus.SelectedValue),
            UserDetails = new UserDetails
            {
                DOB = GetFormattedDate(txtDOB.Value, true),
                FirstName = txtFirstName.Text.Trim(),
                LastName = txtLastName.Text.Trim(),
                RegisteredIP = Utilities.IPAddress,
                UserID = int.Parse(hdnID.Value)
            },
            UserID = int.Parse(hdnID.Value)
        };
        users.Add(user);

        List<User> userList = LoadUsers();

        if (userList != null && userList.Count > 0)
        {
            var duplicateUsers = (from suser in userList
                                  where ((suser.Email == txtEmail.Text.Trim() || suser.Mobile == txtMobile.Text.Trim()))
                                  select suser).ToList();

            if (user.UserID > 0 && duplicateUsers.Any(x => x.UserID != user.UserID))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate entries found for " + user.Email + " or " + user.Mobile + ".",
                    MessageType.Warning);
                return;
            }
            if (user.UserID == 0 && duplicateUsers.Any())
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Duplicate entries found for " + user.Email + " or " + user.Mobile + ".",
                    MessageType.Warning);
                return;
            }
        }

        lblStatusMessage.InnerHtml = _userManager.SaveUsers(users, out _status);

        if (_status)
        {
            foreach (var newuser in users.Where(x => x.UserID == 0))
            {
                Utilities.SendEmail(newuser.Email, "New " + usersPageMode.ToString() + " registration",
                    "Dear User, <br/> your account is created successfully. <br/><br/><br/> Login Details:<br/><br/>Username: " +
                    newuser.Email + " or " + newuser.Mobile + "<br/>Password: " + newuser.Password, null,
                    CurrentUser.Email);
            }
            GetCachedUsers(clearCache: true);
            txtMobile.Enabled = txtEmail.Enabled = true;
            txtMobile.CssClass = txtEmail.CssClass = "std_input std_imedium";
            lbtnResetPassword.Visible = false;
            txtPassword.Visible = true;
            CreatedDate.Text = ModifiedDate.Text = "";
            ClearControls(this);
            rblStatus.Items[0].Selected = true;
            //set new password
            txtPassword.Text = CreateRandomPassword(8);
        }
    }
    protected void lbtnResetPassword_Click(object sender, EventArgs e)
    {
        var newPassword = CreateRandomPassword(8);
        if (_userManager.ResetUserPassword(int.Parse(hdnID.Value),
            Utilities.GetEncryptedPassword(Utilities.SharedSecret, newPassword), out _status) == DbMessage.Success)
        {
            Utilities.SendEmail(txtEmail.Text, "Password reset", "Dear " + usersPageMode.ToString() + ",<br/><br/><br/> Your password was reset" +
                " by " + CurrentUser.UserDetails.FirstName + " " + CurrentUser.UserDetails.LastName + "(" + CurrentUser.Role.RoleName + ")." +
                "<br/><br/>Your new password is " + newPassword);
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Password is reset and new password details are sent to registered email.",
                CLB.Enums.MessageType.Success);
        }
        else
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to reset password, please try again later.",
                CLB.Enums.MessageType.Success);
    }

    #endregion

    #region Private Methods
    private void LoadDropdowns()
    {
        var roleManager = new RoleManager();
        var roles = roleManager.GetRoles();
        Utilities.BindControl(roles.Where(x => x.RoleID > 100), "RoleName", "RoleID", ddlRole);

        rblStatus.Items.Add(new ListItem(Status.Active.ToString(), ((int)Status.Active).ToString()));
        rblStatus.Items.Add(new ListItem(Status.InActive.ToString(), ((int)Status.InActive).ToString()));
        rblStatus.SelectedIndex = 0;
    }
    private void LoadUserDetails(int id)
    {
        var user = LoadUsers().FirstOrDefault(x => x.UserID == id);
        if (user == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load User details. Please try later.", CLB.Enums.MessageType.Info);
            return;
        }
        hdnID.Value = user.UserID.ToString();
        txtFirstName.Text = user.UserDetails.FirstName;
        txtLastName.Text = user.UserDetails.LastName;
        txtEmail.Text = user.Email;
        txtEmail.Enabled = false;
        txtEmail.CssClass = "std_idisabled";
        if (user.UserDetails.DOB != null && user.UserDetails.DOB.Year > 1901)
            txtDOB.Value = user.UserDetails.DOB.ToString("dd-MM-yyyy");
        txtMobile.Text = user.Mobile;
        txtMobile.Enabled = false;
        txtMobile.CssClass = "std_idisabled";
        ddlRole.SelectedValue = user.Role.RoleID.ToString();
        CreatedDate.Text = FormatDateTime(user.CreatedDate);
        ModifiedDate.Text = FormatDateTime(user.ModifiedDate);
        rblStatus.Items.FindByText(user.Status.ToString()).Selected = true;
    }

    private List<User> LoadUsers()
    {
        if (ViewState["Users"] == null)
        {
            var users = _userManager.GetUsers();
            ViewState["Users"] = users;
        }
        return ViewState["Users"] as List<User>;
    }

    #endregion
}