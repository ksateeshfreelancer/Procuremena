﻿using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.BL;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using System.Data;

public partial class Accounts_ViewUsers : BasePage
{
    #region Global Variables

    private UserManager _userManager = new UserManager();
    public string UserNames { get; set; }
    public UserRole usersPageMode;
    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("viewvendors")))
        {
            Page.Title += "Vendors";
            usersPageMode = UserRole.Vendor;
            //lnkAdd.HRef = "~/" + _redirectPage.ManageVendor.Key + "?T=P";
            //lnkAdd.InnerText = "Add Agent";
            lnkAdd.Visible = false;
        }
        else if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("viewcustomers")))
        {
            Page.Title += "Customers";
            usersPageMode = UserRole.Customer;
            //lnkAdd.HRef = "~/" + _redirectPage.ManageUsers.Key + "?T=P";
            //lnkAdd.InnerText = "Add User";
            lnkAdd.Visible = false;
        }
        else if (Page.Request.Url.AbsolutePath.Split('/').Any(x => x.ToLower().Equals("viewstaff")))
        {
            Page.Title += "Staff";
            usersPageMode = UserRole.DynamicUser;
            lnkAdd.HRef = "~/" + _redirectPage.ManageStaff.Key + "?T=P";
            lnkAdd.InnerText = "Add Staff";
        }

        if (IsPostBack) return;
        BindUsers();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtNameSearch.Value = "";
        BindUsers();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string[] sear = new string[] { " " };
        var users = ((List<User>)ViewState["List"]);
        if (users == null) return;
        var control = ((Control)sender).NamingContainer;
        users = (from user in users
                 let search = txtNameSearch.Value.Trim()
                 where (search.Split(sear, StringSplitOptions.None).Any(y => user.UserDetails.FirstName.Contains(y)) ||
                        search.Split(sear, StringSplitOptions.None).Any(y => user.UserDetails.LastName.Contains(y)) ||
                     user.Email.Contains(search) || user.Mobile.Contains(search) || user.Role.RoleName.Contains(search))
                 select user).ToList();

        gridview.DataSource = ViewState["FilterList"] = users;
        gridview.DataBind();
    }
    protected void cboxStatus_CheckedChanged(object sender, EventArgs e)
    {
        var row = (CheckBox)sender;
        var cboxStatus = (CheckBox)row.FindControl("cboxStatus");
        var hdnUserID = (HiddenField)row.FindControl("hdnUserID");
        var status = (cboxStatus.Checked) ? 1 : 0;

        var dbMessage = _userManager.UpdateField(Tables.Users, "Status", status.ToString(), "UserID", hdnUserID.Value);

        if (dbMessage == DbMessage.Success)
        {
            GridViewRow gvr = (GridViewRow)cboxStatus.NamingContainer;
            var email = gridview.DataKeys[gvr.RowIndex][1].ToString();
            var userDetails = ((UserDetails)gridview.DataKeys[gvr.RowIndex][2]);
            //send email to vendor that his product is approved
            Utilities.SendEmail(email, "Account " + (cboxStatus.Checked ? "Activated" : "De-activated"),
                "Hi " + userDetails.FirstName + " " + userDetails.LastName + ",<br/><br/> Your account is " + (cboxStatus.Checked ? "Activated" : "De-activated") + ".<br/>");
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("User status is changed to " + ((Status)status).ToString() + " successfully", MessageType.Success);
        }
        else
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update status. Please try again later.", MessageType.Error);
        BindUsers();
    }

    #region Grid Events

    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                var userID = int.Parse(((HiddenField)e.Row.FindControl("hdnUserID")).Value);
                switch (usersPageMode)
                {
                    case UserRole.Customer:
                        ((HtmlAnchor)e.Row.FindControl("lnkEdit")).HRef = "~/" + _redirectPage.ManageCustomer.Key + "?T=P&UT=" + (int)UserRole.Customer + "&ID=" + Utilities.Encrypt(userID);
                        break;
                    case UserRole.Vendor:
                        ((HtmlAnchor)e.Row.FindControl("lnkEdit")).HRef = "~/" + _redirectPage.ManageVendor.Key + "?T=P&UT=" + (int)UserRole.Vendor + "&ID=" + Utilities.Encrypt(userID);
                        break;
                    case UserRole.DynamicUser:
                        ((HtmlAnchor)e.Row.FindControl("lnkEdit")).HRef = "~/" + _redirectPage.ManageStaff.Key + "?T=P&UT=" + (int)UserRole.DynamicUser + "&ID=" + Utilities.Encrypt(userID);
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<User>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Users",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "UserDetails.Firstname", "UserDetails.LastName", "Email", "Mobile", "UserDetails.DOB", "CreatedDate" });
    }

    #endregion

    #endregion

    #region Private Methods

    private void BindUsers()
    {
        var users = _userManager.GetUsers(null, null);

        if (usersPageMode != UserRole.DynamicUser)
            users = users.Where(x => x.Role.RoleID == (int)usersPageMode).OrderByDescending(x => x.ModifiedDate).ToList();
        else
            users = users.Where(x => x.Role.RoleID > 100).OrderByDescending(x => x.ModifiedDate).ToList();

        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = users;
        gridview.DataBind();

        var userNames = (from item in users select ValidAutoCompleteString(item.UserDetails.FirstName + " " + item.UserDetails.LastName + "(" + item.Email + ", " + item.Mobile + ")")).ToList();
        UserNames = JsonConvert.SerializeObject(userNames.ToArray());
    }

    #endregion
}
