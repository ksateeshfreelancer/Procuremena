﻿using CLB.BL;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ResetPassword : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fsResetPwd.Visible = false;
        int userId = 0;
        long ticks = 0;
        if (Request.QueryString["T"] == null || !long.TryParse(Request.QueryString["T"].ToString(), out ticks) ||
            Request.QueryString["U"] == null || !int.TryParse(Utilities.Decrypt(Server.UrlDecode(Request.QueryString["U"])), out userId))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Link.", MessageType.Error);
            return;
        }
        //check if link is expired
        if (DateTime.Now.Ticks > ticks)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Link expired.", MessageType.Error);
            return;
        }
        fsResetPwd.Visible = true;
        ViewState["UserID"] = userId;
    }
    protected void btnResetPwd_Click(object sender, EventArgs e)
    {
        if (ViewState["UserID"] == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Link.", MessageType.Error);
            return;
        }

        var accountManager = new AccountManager();
        try
        {
            var newPassword = txtNewPwd.Value.Trim();
            var userManager = new UserManager();
            var userDetails = userManager.GetUsers().FirstOrDefault(x => x.UserID == int.Parse(ViewState["UserID"].ToString()));

            if (userDetails == null)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Email or Mobile.", MessageType.Error);
                return;
            }

            if (userDetails.Status == Status.InActive)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Your account is InActive. Please contact Administrator.", MessageType.Info);
                return;
            }

            if (userDetails.Status == Status.Deleted)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Your account is Deleted. Please contact Administrator.", MessageType.Info);
                return;
            }

            var changePassword = new CLB.DTO.ChangePassword
            {
                UserID = userDetails.UserID,
                NewPassword = Utilities.GetEncryptedPassword(Utilities.SharedSecret, newPassword),
                OldPassword = "RESET"
            };

            if (accountManager.ChangePassword(changePassword) == DbMessage.PasswordChanged)
            {
                Utilities.SendEmail(userDetails.Email, "Password Reset", "New Password: " + newPassword);
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Your password is changed successfully. " +
                    "Click <a href='" + _redirectPage.Login.Key + "' class='std_anchor'>here</a> to login with new password.", MessageType.Success);
                ClearControls(this);
            }
            else
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Email Id.", MessageType.Error);
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
}