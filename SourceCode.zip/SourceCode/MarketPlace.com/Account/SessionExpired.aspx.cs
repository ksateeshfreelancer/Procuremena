﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Security;
using System.Drawing;

using System.Web.UI.HtmlControls;

public partial class SessionExpired : System.Web.UI.Page
{
    string IP;
    protected void Page_Load(object sender, EventArgs e)
    {
        HtmlMeta meta = new HtmlMeta();

        meta.HttpEquiv = "Refresh";

       // meta.Content = Convert.ToString(Session.Timeout * 60) + ";url=Default.aspx";
       meta.Content = 3 + ";url=login";

       this.Page.Header.Controls.Add(meta);
    }
        
}