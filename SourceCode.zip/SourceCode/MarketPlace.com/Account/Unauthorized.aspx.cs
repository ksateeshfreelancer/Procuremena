﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.DTO;
using CLB.Enums;
using CLB.Util;

public partial class Unauthorized : System.Web.UI.Page
{
    public User CurrentUser
    {
        get { return (User)Session[SessionVariables.CurrentUser]; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        trCurrentUserDetails.Visible = (Session[SessionVariables.CurrentUser] != null);
    }
}