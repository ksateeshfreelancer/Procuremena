﻿using CLB.BL;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Logout : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string[] pagestoFilter = new[] { "productdetails", "home" };

        LogoutUser();
        //if user is in ecommerce related pages, do not redirect him to login page. let user be on same screen
        if (Page.Request.UrlReferrer != null && pagestoFilter.Any(x => Page.Request.UrlReferrer.AbsolutePath.ToLower().Contains(x)))
            Response.Redirect("~" + Page.Request.UrlReferrer.PathAndQuery);
        else
            Response.Redirect(_redirectPage.Login.Key, false);
    }
}