﻿using CLB.BL;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ForgotPassword : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtUsername.Focus();
    }
    protected void btnForgotPwd_Click(object sender, EventArgs e)
    {
        var accountManager = new AccountManager();
        try
        {
            var userManager = new UserManager();
            var userDetails = userManager.GetUsers().FirstOrDefault(x => x.Email == txtUsername.Text.Trim() || x.Mobile == txtUsername.Text.Trim());

            if (userDetails == null)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Email/Mobile.", MessageType.Error);
                return;
            }

            if (userDetails.Status == Status.InActive)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Your account is InActive. Please contact Administrator.", MessageType.Info);
                return;
            }

            if (userDetails.Status == Status.Deleted)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Your account is Deleted. Please contact Administrator.", MessageType.Info);
                return;
            }

            var resetLink = GetDomainUrl + "/" + _redirectPage.ResetPassword.Key + "?T=" + DateTime.Now.AddDays(5).Ticks + "&U=" + Server.UrlEncode(Utilities.Encrypt(userDetails.UserID));

            Utilities.SendEmail(userDetails.Email, "Password Reset", "We've received a request to reset your password. Please use this link to set new password. " +
                " Link will expire in 5 days <br/><br/>" + resetLink);

            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Link to reset your password has be sent to your registered email.", MessageType.Success);
            ClearControls(this);
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
}