﻿using CLB.BL;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    #region Declarations

    public RedirectPage _redirectPage = new RedirectPage();
    AccountManager accountManager = new AccountManager();
    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        //check if session already exists
        if (Session[SessionVariables.CurrentUser] != null)
        {
            var user = (User)Session[SessionVariables.CurrentUser];

            if (user.Role.Screens.Count > 0)
            {
                switch (user.Role.RoleID)
                {
                    case (int)UserRole.Administrator:
                        Response.Redirect(_redirectPage.AdminDashboard.Key, false);
                        break;
                    case (int)UserRole.Customer:
                        Response.Redirect(_redirectPage.CustomerDashboard.Key, false);
                        break;
                    case (int)UserRole.Vendor:
                        Response.Redirect(_redirectPage.VendorDashboard.Key, false);
                        break;
                    default:
                        var firstOrDefault = user.Role.Screens.FirstOrDefault();
                        //check if user has access to atleast one screen in administration module
                        if (firstOrDefault != null)
                            //redirect to first or default screen
                            Response.Redirect(firstOrDefault.ScreenName, false);
                        break;
                }
            }
            else
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Unauthorized user.", MessageType.Error);
                Session.Clear();
                Session.Abandon();
            }
        }

        if (!IsPostBack)
        {
            if (Request.Cookies["UserName"] != null && Request.Cookies["Password"] != null)
            {
                txtUserName.Value = Request.Cookies["UserName"].Value;
                txtPassword.Attributes.Add("value", Utilities.Decrypt(Request.Cookies["Password"].Value));
                txtPassword.Value = Utilities.Decrypt(Request.Cookies["Password"].Value);
            }
        }
        //redirect user back to same page if session expires abnormally
        if (Request.QueryString["Redirect"] != null && Request.QueryString["Redirect"] != string.Empty)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Please login to continue.", MessageType.Info);
        }
    }
    #endregion

    #region Control Events
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Session["IsEncrypted"] = null;
        long mobile;
        long.TryParse(txtUserName.Value.Trim(), out mobile);
        var user = new User();
        //check if user entered mobile number or email address and assign textbox value to respective property
        if (mobile > 0)
            user.Mobile = txtUserName.Value.Trim();
        else
            user.Email = txtUserName.Value.Trim();

        //Password encryption is already done in client side 
        //user.Password = Utilities.GetEncryptedPassword(Utilities.SharedSecret, txtPassword.Value);
        user.Password = txtPassword.Value;
        Authenticate(user);
    }
    #endregion

    #region Private Methods
    private void Authenticate(User loginDetails)
    {
        DbMessage dbMessage;
        var outMessage = accountManager.AuthenticateUser(loginDetails, out dbMessage);

        if (dbMessage == DbMessage.PasswordChanged || dbMessage == DbMessage.Success)
        {
            #region Save to Cookies

            if (chkRememberMe.Checked)
            {
                Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(30);
                Response.Cookies["Password"].Expires = DateTime.Now.AddDays(30);
            }
            else
            {
                //Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
                //Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);
            }

            Response.Cookies["UserName"].Value = txtUserName.Value.Trim();
            Response.Cookies["Password"].Value = Utilities.Encrypt(txtPassword.Value.Trim());

            #endregion

            var user = (User)Session[SessionVariables.CurrentUser];

            #region Users of one domain(Ex:blackhills.abc.com) cannot login to other domain psa url(Ex:redhills.abc.com)

            var basePage = new BasePage();
            var domainName = basePage.GetDomainName;

            /*
            //apply this on all roles except super admin. SuperAdmin can login into any domain
            if (basePage.IsSuperAdmin && !domainName.Equals("abc"))
            {
                if (!.ShortName.ToLower().Equals(domainName) && !basePage.IsDevEnvironment)
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Unauthorized access.", MessageType.Error);
                    ClearSession();
                    return; //skip code execution from here
                }
            }
             */

            #endregion

            var firstOrDefault = user.Role.Screens.OrderBy(x => x.ScreenName).FirstOrDefault();
            //check if user has access to atleast one screen
            if (firstOrDefault != null)
            {
                //Close popup window if login is called from popup
                if (Request.QueryString["T"] != null)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, GetType(), "MyKey",
                        "parent.$.fn.colorbox.close();", true);
                    return;
                }

                if (user.IsNewPassword)
                    Response.Redirect(_redirectPage.ChangePassword.Key, false);
                if (dbMessage == DbMessage.PasswordChanged)
                    Response.Redirect(_redirectPage.ChangePassword.Key, false);
                else
                {
                    if (Request.QueryString["Redirect"] != null && Request.QueryString["Redirect"] != string.Empty)
                        Response.Redirect(Request.QueryString["Redirect"], false);
                    else
                    {
                        switch (user.Role.RoleID)
                        {
                            case (int)UserRole.Administrator:
                                Response.Redirect(_redirectPage.AdminDashboard.Key, false);
                                break;
                            case (int)UserRole.Customer:
                                Response.Redirect(_redirectPage.CustomerDashboard.Key, false);
                                break;
                            case (int)UserRole.Vendor:

                                #region Load Subscription Details

                                var _sbscriptionManager = new SubscriptionManager();
                                var subscriptions = _sbscriptionManager.GetSubscriptions(userID: user.UserID);

                                if (subscriptions != null && subscriptions.FirstOrDefault(x => !x.IsExpired) != null)
                                {
                                    Session[SessionVariables.SubscriptionDetails] = subscriptions.FirstOrDefault(x => !x.IsExpired);
                                }

                                #endregion

                                Response.Redirect(_redirectPage.VendorDashboard.Key, false);
                                break;
                            default:
                                Response.Redirect(firstOrDefault.ScreenName, false);
                                break;
                        }
                    }
                }
            }
            else
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Unauthorized access.", MessageType.Error);
                ClearSession();
            }
        }
        else
        {
            lblStatusMessage.InnerHtml = outMessage;
            txtPassword.Focus();
        }
    }
    private void ClearSession()
    {
        HttpCookie cookie = Request.Cookies["UserName"];
        if (cookie != null)
        {
            cookie.Expires = DateTime.Now.AddDays(-1d);
            Response.Cookies.Add(cookie);
        }
        HttpCookie cookie1 = Request.Cookies["Password"];
        if (cookie1 != null)
        {
            cookie1.Expires = DateTime.Now.AddDays(-1d);
            Response.Cookies.Add(cookie1);
        }

        Cache.Remove(Session[SessionVariables.UserId].ToString());
        Application.Contents.Remove(Session[SessionVariables.UserId].ToString());
        Session.Clear();
        Session.Abandon();
    }
    #endregion
}