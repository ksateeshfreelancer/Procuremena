﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;
using CLB.BL;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.DTO;
using CLB.BL.Administration;
using CLB.Util;

public partial class Notifications_SendEmail : BasePage
{
    public string Emails;
    protected void Page_Load(object sender, EventArgs e)
    {
        UpdatePanel updatePanel = Page.Master.FindControl("mainUpdatePanel") as UpdatePanel;
        UpdatePanelControlTrigger trigger = new PostBackTrigger();
        trigger.ControlID = btnSubmit.UniqueID;
        updatePanel.Triggers.Add(trigger);
        ScriptManager.GetCurrent(this).RegisterPostBackControl(btnSubmit);

        if (IsPostBack) return;

        //var rankings = GetViewStateRankings();
        var users = GetCachedUsers();

        if (Request.QueryString["Email"] != null)
            txtEmails.Text = Request.QueryString["Email"];
        else
        {            
           /* var list = new List<ListItem>();
            list.AddRange(from rank in rankings                          
                          select (new ListItem(rank.RankName, rank.RankID.ToString())));
            cblRankings.DataSource = list;
            cblRankings.DataBind();*/
        }

        UserManager userManager = new UserManager();        
        var emails = new List<Email>();
        users = userManager.GetUsers(null, null).Where(x => x.Role.RoleID != (int)UserRole.Administrator).ToList();
        emails.AddRange(from user in users select new Email { name = user.UserDetails.FirstName + " " + user.UserDetails.LastName, to = user.Email });
        hdnEmails.Value = Newtonsoft.Json.JsonConvert.SerializeObject(emails);
    }
  
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtBody.InnerHtml.Length > _maxLength)
            {
                Utilities.CustomMessage("Body cannot exceed " + _maxLength + " characters (" + txtBody.InnerHtml.Length + ")", MessageType.Warning);
                return;
            }

            string emails = txtEmails.Text;

            if (cblRankings.Items.Count > 0)
            {
                if (emails.Length > 0) emails += ",";

                var users = GetCachedUsers();
                /*
                //get all users in selected rankings
                foreach (ListItem item in cblRankings.Items)
                {
                    if (!item.Selected) continue;
                    emails += string.Join(",", (from User user in users where user.Referral.Ranking.RankID == int.Parse(item.Value) select user.Email).ToArray());
                } */              
            }

            var logManager = new LogManager();
            var emailLog = new EmailLog
            {
                Body = txtBody.InnerHtml.Trim(),
                Emails = emails,
                Subject = txtSubject.Text.Trim(),
                CreatedDate = DateTime.Now
            };
            logManager.LogEmail(emailLog, out _status);
            Utilities.SendEmail(CurrentUser.Email, txtSubject.Text, txtBody.Value,
                (!FileUpload1.HasFile ? null : FileUpload1.PostedFile.FileName), null, txtEmails.Text, true);
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Email(s) sent successfully.", MessageType.Success);
            ClearControls(this);
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to send email(s), please try again later.", MessageType.Error);
        }
    }
}

public class Email
{
    public string name { get; set; }
    public string to { get; set; }
}