﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;
using CLB.BL;
using CLB.Enums.Database;
using CLB.Enums;
using CLB.DTO;
using CLB.BL.Administration;
using CLB.Util;

public partial class Notifications_SendSMS : BasePage
{       
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        //var rankings = GetViewStateRankings();
        var users = GetCachedUsers();

        if (Request.QueryString["Mobile"] != null)
            txtPhoneNos.Text = Request.QueryString["Mobile"];
        else
        {
            /*var list = new List<ListItem>();
            list.AddRange(from rank in rankings
                          select (new ListItem(rank.RankName, rank.RankID.ToString())));
            cblRankings.DataSource = list;
            cblRankings.DataBind();*/
        }

        UserManager userManager = new UserManager();
        var phones = new List<string>();
        users = userManager.GetUsers(null, null).Where(x => x.Role.RoleID != (int)UserRole.Administrator).ToList();
        phones.AddRange(from user in users select user.Mobile);
        hdnPhones.Value = Newtonsoft.Json.JsonConvert.SerializeObject(phones);
    }    
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string phones = txtPhoneNos.Text;

            if (cblRankings.Items.Count > 0)
            {
                if (phones.Length > 0) phones += ",";

                var users = GetCachedUsers();
                /*
                //get all users in selected rankings
                foreach (ListItem item in cblRankings.Items)
                {
                    if (!item.Selected) continue;
                    phones += string.Join(",", (from User user in users where user.Referral.Ranking.RankID == int.Parse(item.Value) select user.Mobile).ToArray());
                }*/
            }            

            var logManager = new LogManager();
            var smsLog = new SMSLog
            {
                Message = txtContent.Value.Trim(),
                PhoneNos = phones.Trim()
            };
            logManager.LogSMS(smsLog, out _status);

            foreach (var item in txtPhoneNos.Text.Split(','))
            {
                Utilities.SendSMS(item, txtContent.Value.Trim());
            }

            lblStatusMessage.InnerHtml = Utilities.CustomMessage("SMS sent successfully.", MessageType.Success);
            ClearControls(this);
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to send SMS, please try again later.", MessageType.Error);
        }
    }
}
