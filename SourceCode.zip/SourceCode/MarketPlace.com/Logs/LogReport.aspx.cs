﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CLB.BL;
using CLB.DTO;
using CLB.BL.Administration;
using CLB.Util;
using CLB.Enums;

public partial class Exceptions_Exceptions : BasePage
{
    #region Global Variables

    private LogManager _logManager;
    public string ClientNames { get; set; }
    public string NamesEmailsMobiles { get; set; }

    public string CurrentPage
    {
        get { return Page.Request.Url.AbsolutePath.Split('/')[Page.Request.Url.AbsolutePath.Split('/').Length - 1]; }
    }

    #endregion

    #region Control Events

    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            txtFromDate.Value = DateTime.Now.AddDays(-1).ToString("dd-MM-yyyy");
            txtToDate.Value = DateTime.Now.ToString("dd-MM-yyyy");
            BulidGrid(CurrentPage, txtFromDate.Value, txtToDate.Value);
        }
        if (gridview.Rows.Count > 0)
            BuildSearchForGrid(CurrentPage);
    }



    protected void btnSearch_Click(object sender, EventArgs e)
    {
        BulidGrid(CurrentPage, (txtFromDate.Value != "") ? txtFromDate.Value : null, (txtToDate.Value != "") ? txtToDate.Value : null);
        if (gridview.Rows.Count > 0)
            BuildSearchForGrid(CurrentPage);

        if (gridview.Rows.Count > 0)
            ScriptManager.RegisterClientScriptBlock(Page, GetType(), "MyKey",
                "fnLoadAccordion(0);ajaxFunctions.LoadReportCalenders($('#" + txtFromDate.ClientID + "'), $('#" +
                txtToDate.ClientID + "'));", true);
    }

    protected void ibtnExport_onClick(object sender, ImageClickEventArgs e)
    {
        var columns = new[] { "" };
        switch (CurrentPage)
        {
            case "UIErrorLog":
                columns = new[] { "ErrorMessage", "DetailedMessage", "IPAddress", "LogDate", "Method", "Page" };
                break;
            case "DBErrorLog":
                columns = new[] { "ErrorNumber", "LogDate", "ErrorMessage", "ErrorProcedure", "ErrorLine", "ErrorState", "ErrorSeverity" };
                break;
            case "EmailLog":
                columns = new[] { "Emails", "Subject", "Body", "CreatedDate" };
                break;
            case "LoginLog":
                columns = new[] { "UserName", "Email", "Mobile", "LoginDate", "IPAddress", "Status" };
                break;
            case "SMSLog":
                columns = new[] { "PhoneNos", "Message", "CreatedDate" };
                break;
        }

        Export(ViewState["FilterList"], CurrentPage + " Report", (ExportType)Enum.Parse(typeof(ExportType), ((ImageButton)sender).CommandName), columns);

    }

    #region GridEvents

    protected void gridview_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridview.PageIndex = e.NewPageIndex;
        gridview.DataSource = ViewState["List"];
        gridview.DataBind();

        if (gridview.Rows.Count > 0)
            BuildSearchForGrid(CurrentPage);
    }

    protected void gridview_Sorting(object sender, GridViewSortEventArgs e)
    {
        switch (CurrentPage)
        {
            case "UIErrorLog":
                SortList<ErrorLog>(gridview, e.SortExpression);
                break;
            case "DBErrorLog":
                SortList<DbErrorLog>(gridview, e.SortExpression);
                break;
            case "LoginLog":
                SortList<LoginLog>(gridview, e.SortExpression);
                break;
            case "EmailLog":
                SortList<EmailLog>(gridview, e.SortExpression);
                break;
            case "SMSLog":
                SortList<SMSLog>(gridview, e.SortExpression);
                break;
        }

        if (gridview.Rows.Count > 0)
            BuildSearchForGrid(CurrentPage);
    }

    protected void gridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Search")
        {
            var row = gridview.Controls[0].Controls[1];

            switch (CurrentPage)
            {
                case "UIErrorLog":
                    var txtErrorMethod = (TextBox)row.FindControl("txtErrorMethod");
                    var uiErrorLog = (List<ErrorLog>)ViewState["List"];
                    if (txtErrorMethod.Text != "")
                        uiErrorLog = uiErrorLog.FindAll(x => x.Method.Contains(txtErrorMethod.Text.Trim()));
                    ViewState["FilterList"] = uiErrorLog;
                    break;
                case "DBErrorLog":
                    var txtErrorProcedure = (TextBox)row.FindControl("txtErrorProcedure");
                    var dbErrorLog = (List<DbErrorLog>)ViewState["List"];
                    if (txtErrorProcedure.Text != "")
                        dbErrorLog = dbErrorLog.FindAll(x => x.ErrorProcedure.Contains(txtErrorProcedure.Text.Trim()));
                    ViewState["FilterList"] = dbErrorLog;
                    break;               
                case "LoginLog":                    
                    var ddlRole = (DropDownList)row.FindControl("ddlRole");
                    var txtLoginLogNameSearch = (TextBox)row.FindControl("txtLoginLogNameSearch");
                    var loginLog = (List<LoginLog>)ViewState["List"];                    
                    if (ddlRole.SelectedIndex != 0)
                        loginLog = loginLog.FindAll(x => x.User.Role.RoleID == int.Parse(ddlRole.SelectedValue));
                    if (txtLoginLogNameSearch.Text != "")
                        loginLog =
                            loginLog.FindAll(
                                x =>                                
                                x.User.Email.Contains(txtLoginLogNameSearch.Text.Trim()) ||
                                x.User.Mobile.Contains(txtLoginLogNameSearch.Text.Trim()));
                    ViewState["FilterList"] = loginLog;
                    break;
                case "EmailLog":
                    var txtEmailLogNameSearch = (TextBox)row.FindControl("txtEmailLogNameSearch");
                    var emailLog = (List<EmailLog>)ViewState["List"];
                    if (txtEmailLogNameSearch.Text != "")
                        emailLog = emailLog.FindAll(
                                    x =>
                                    x.Emails.Contains(txtEmailLogNameSearch.Text.Trim()) ||
                                    x.Subject.Contains(txtEmailLogNameSearch.Text.Trim()));
                    ViewState["FilterList"] = emailLog;
                    break;
                case "SMSLog":
                    var txtSMSLogNameSearch = (TextBox)row.FindControl("txtSMSLogNameSearch");
                    var smsLog = (List<SMSLog>)ViewState["List"];
                    if (txtSMSLogNameSearch.Text != "")
                        smsLog = smsLog.FindAll(
                                    x =>
                                    x.PhoneNos.Contains(txtSMSLogNameSearch.Text.Trim()) ||
                                    x.Message.Contains(txtSMSLogNameSearch.Text.Trim()));
                    ViewState["FilterList"] = smsLog;
                    break;   
            }
            gridview.DataSource = ViewState["FilterList"];
            gridview.DataBind();
        }
        if (e.CommandName == "Reset")
        {
            gridview.DataSource = ViewState["List"];
            gridview.DataBind();
        }
        BuildSearchForGrid(CurrentPage);
    }

    #endregion

    #endregion

    #region Private Methods

    private void BulidGrid(string currentPage, string fromDate = null, string toDate = null)
    {
        if (fromDate != null)
            fromDate = GetSqlDate(fromDate);
        if (toDate != null)
            toDate = GetSqlDate(toDate);
        gridview.Columns.Clear();
        _logManager = new LogManager();

        switch (currentPage)
        {
            case "UIErrorLog":
                Page.Title = "User Interface Exceptions";
                Heading.InnerHtml = "User Interface Exceptions";
                var errorLogReport = _logManager.GetErrorLog(fromDate, toDate);
                ViewState["FilterList"] = ViewState["List"] = errorLogReport;
                divExport.Visible = errorLogReport.Count > 0;
                gridview.Columns.Add(SetBoundField("DomainName"));
                gridview.Columns.Add(SetBoundField("ErrorMessage"));
                gridview.Columns.Add(SetBoundField("DetailedMessage"));
                gridview.Columns.Add(SetBoundField("IPAddress"));
                gridview.Columns.Add(SetBoundField("LogDate"));
                gridview.Columns.Add(SetBoundField("Method"));
                gridview.Columns.Add(SetBoundField("Page"));

                NamesEmailsMobiles =
                    Newtonsoft.Json.JsonConvert.SerializeObject(
                        errorLogReport.Select(x => x.Method).Distinct().ToArray());
                break;
            case "DBErrorLog":
                Page.Title = "Database Exceptions";
                Heading.InnerHtml = "Database Exceptions";
                var dbErrorLogReport = _logManager.GetDbErrorLog(fromDate, toDate);
                ViewState["FilterList"] = ViewState["List"] = dbErrorLogReport;
                divExport.Visible = dbErrorLogReport.Count > 0;
                gridview.Columns.Add(SetBoundField("ErrorNumber"));
                gridview.Columns.Add(SetBoundField("LogDate"));
                gridview.Columns.Add(SetBoundField("ErrorMessage", null, 238));
                gridview.Columns.Add(SetBoundField("ErrorProcedure"));
                gridview.Columns.Add(SetBoundField("ErrorLine"));
                gridview.Columns.Add(SetBoundField("ErrorState"));
                gridview.Columns.Add(SetBoundField("ErrorSeverity"));

                NamesEmailsMobiles =
                    Newtonsoft.Json.JsonConvert.SerializeObject(
                        dbErrorLogReport.Select(x => x.ErrorProcedure).Distinct().ToArray());
                break;
            case "LoginLog":            
                Page.Title = "Login Log";
                Heading.InnerHtml = "Login Log";
                var loginLogReport = _logManager.GetLoginLog(fromDate, toDate);
                ViewState["FilterList"] = ViewState["List"] = loginLogReport;
                divExport.Visible = loginLogReport.Count > 0;
                gridview.Columns.Add(SetBoundField("Role"));
                gridview.Columns.Add(SetBoundField("UserName"));
                gridview.Columns.Add(SetBoundField("Email"));
                gridview.Columns.Add(SetBoundField("Mobile"));
                gridview.Columns.Add(SetBoundField("LoginDateTime"));
                gridview.Columns.Add(SetBoundField("IPAddress"));
                gridview.Columns.Add(SetBoundField("Status"));

                var _namesEmailsMobiles = new string[loginLogReport.Count * 3];                
                loginLogReport.Select(x => x.User.Email).ToArray().CopyTo(_namesEmailsMobiles, loginLogReport.Count);
                loginLogReport.Select(x => x.User.Mobile).ToArray().CopyTo(_namesEmailsMobiles, loginLogReport.Count * 2);
                _namesEmailsMobiles = _namesEmailsMobiles.Distinct().ToArray();
                NamesEmailsMobiles = Newtonsoft.Json.JsonConvert.SerializeObject(_namesEmailsMobiles);
                break;
            case "EmailLog":
                Page.Title = "Email Log";
                Heading.InnerHtml = "Email Log";
                var emailLogReport = _logManager.GetEmailLog(fromDate, toDate);
                ViewState["FilterList"] = ViewState["List"] = emailLogReport;
                divExport.Visible = emailLogReport.Count > 0;
                gridview.Columns.Add(SetBoundField("Emails"));
                gridview.Columns.Add(SetBoundField("Subject"));
                gridview.Columns.Add(SetBoundField("Body"));
                gridview.Columns.Add(SetBoundField("CreatedDate"));
                break;
            case "SMSLog":
                Page.Title = "SMS Log";
                Heading.InnerHtml = "SMS Log";
                var smsLogReport = _logManager.GetSMSLog(fromDate, toDate);
                ViewState["FilterList"] = ViewState["List"] = smsLogReport;
                divExport.Visible = smsLogReport.Count > 0;
                gridview.Columns.Add(SetBoundField("PhoneNos"));
                gridview.Columns.Add(SetBoundField("Message"));
                gridview.Columns.Add(SetBoundField("CreatedDate"));
                break;
        }
        gridview.DataSource = ViewState["List"];
        gridview.DataBind();

    }

    private void BuildSearchForGrid(string pageName)
    {
        var headerGridRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
        var headerCell = new TableCell
        {
            ColumnSpan = gridview.Columns.Count,
            CssClass = "gridtrsearchpanel",
        };
        headerCell.Attributes.Add("style", "color:#000000");
        var table = new Table { CellPadding = 0, CellSpacing = 0, ID = "tblGridSearch" };
        table.Attributes.Add("Width", "100%");
        var tableRow = new TableRow();
        var tablecell = new TableCell();
        var searchButton = new Button
        {
            CssClass = "std_searchbtn",
            CommandName = "Search"
        };
        var resetButton = new Button
        {
            CssClass = "resetbtn",
            CommandName = "Reset"
        };
        resetButton.Attributes.Add("style", "margin: 5px;");
        tablecell.Controls.Add(searchButton);
        tablecell.Controls.Add(resetButton);
        tableRow.Cells.Add(tablecell);

        switch (pageName)
        {
            case "UIErrorLog":
                var errorMethodCell = new TableCell { HorizontalAlign = HorizontalAlign.Center };
                var txtErrorMethod = new TextBox { CssClass = "input_small", ID = "txtErrorMethod" };
                txtErrorMethod.Attributes.Add("style", "margin-left: 297px;");
                txtErrorMethod.Attributes.Add("placeholder", "Error Method Name");
                errorMethodCell.Controls.Add(txtErrorMethod);


                tableRow.Cells.Add(errorMethodCell);
                break;
            case "DBErrorLog":
                var errorProcedureCell = new TableCell { HorizontalAlign = HorizontalAlign.Center };
                var txtErrorProcedure = new TextBox { CssClass = "input_small", ID = "txtErrorProcedure" };
                txtErrorProcedure.Attributes.Add("style", "margin-left: 297px;");
                txtErrorProcedure.Attributes.Add("placeholder", "Procedure Name");
                errorProcedureCell.Controls.Add(txtErrorProcedure);


                tableRow.Cells.Add(errorProcedureCell);

                break;
            case "LoginLog":
            case "EmailLog":
            case "SMSLog":
                var loginLogclientNameSearchCell = new TableCell();
                var txtLoginLogClientNameSearch = new TextBox { CssClass = "input_small", ID = "txtLoginLogClientNameSearch" };
                txtLoginLogClientNameSearch.Attributes.Add("placeholder", "Client Name");
                loginLogclientNameSearchCell.Controls.Add(txtLoginLogClientNameSearch);

                var loginLogRoleCell = new TableCell();
                var ddlRole = new DropDownList { ID = "ddlRole", CssClass = "select_small select_filled1" };
                Utilities.BindControl<Role>(ddlRole, new[] { UserRole.Vendor.ToString(), UserRole.Customer.ToString() });
                loginLogRoleCell.Controls.Add(ddlRole);

                var loginLogNameSearchCell = new TableCell();
                var txtLoginLogNameSearch = new TextBox { CssClass = "input_small", ID = "txtLoginLogNameSearch" };
                txtLoginLogNameSearch.Attributes.Add("placeholder", "Name (or) Email (or) Mobile");
                loginLogNameSearchCell.Controls.Add(txtLoginLogNameSearch);

                tableRow.Cells.Add(loginLogclientNameSearchCell);
                tableRow.Cells.Add(loginLogRoleCell);
                tableRow.Cells.Add(loginLogNameSearchCell);
                break;
           
            case "FailedBookingsLog":
                var failedBookingsLogclientNameSearchCell = new TableCell();
                var txtfailedBookingsLogClientNameSearch = new TextBox { CssClass = "input_small", ID = "txtfailedBookingsLogClientNameSearch" };
                txtfailedBookingsLogClientNameSearch.Attributes.Add("placeholder", "Client Name");
                failedBookingsLogclientNameSearchCell.Controls.Add(txtfailedBookingsLogClientNameSearch);

                tableRow.Cells.Add(failedBookingsLogclientNameSearchCell);
                break;
        }

        table.Rows.Add(tableRow);
        headerCell.Controls.Add(table);
        headerGridRow.Cells.Add(headerCell);
        gridview.Controls[0].Controls.AddAt(1, headerGridRow);
    }

    #endregion

}