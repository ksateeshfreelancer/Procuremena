﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Caching;
using System.Xml;
using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Util;
using CLB.Enums.Database;

/// <summary>
/// Summary description for BackgroundServiceManager
/// </summary>
public class BackgroundServiceManager
{
    public BackgroundServiceManager()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void ExecutePayouts()
    {        
        LogEntry("ExecutePayouts SP triggered");
        /* Enable method to trigger at the frequency specified in config file 
         * Create a cache for the duration specified in config file 
         * execute service of code only when cache expires         
         */
        if (HttpRuntime.Cache["ExecutePayouts"] != null) return;

        HttpRuntime.Cache.Add("ExecutePayouts", "YES", null,
            DateTime.Now.AddMinutes(int.Parse(ConfigurationManager.AppSettings["Duration"])),
            Cache.NoSlidingExpiration, CacheItemPriority.Default, null);

        var accountManager = new AccountManager();
        try
        {
            var par = new object[,]
                { 
                    {"@OutMessage", null, "Out"}
                };
            //accountManager.GetDataTable(par, StoredProcedures.SpExecutePayouts);
            var response = par[0, 1].ToString();
            LogEntry(response);
        }
        catch (Exception ex)
        {
            accountManager.LogException(ex);
            LogException(ex);
        }
        
    }
    public void AsyncMethod(out int threadId)
    {
        threadId = Thread.CurrentThread.ManagedThreadId;
        ExecutePayouts();
    }

    #region Private Methods
    private void LogEntry(string status)
    {
        try
        {   
            //skip logging entries if background worker process is disabled
            if (!bool.Parse(ConfigurationManager.AppSettings["EnableBGWProcess"]))
                return;

            //skip logging entries if disabled
            if (!bool.Parse(ConfigurationManager.AppSettings["EnableBGWPLog"]))
                return;

            //Global varaiable declaration 
            var xmlfile = AppDomain.CurrentDomain.BaseDirectory + "Uploads\\Logs\\BackgroundWorkerLog.xml";

            // loading xml file 
            var xdoc = new XmlDocument();
            xdoc.Load(xmlfile);

            //Creating childnode to root node using Xmlelement 
            var xelement = xdoc.CreateElement("Log");

            //creating attribute to childnode using XmlElement 
            var logId = xdoc.CreateAttribute("LogId");

            logId.InnerText = (xdoc.SelectSingleNode("ErrorLog").HasChildNodes) ? (int.Parse(xdoc.SelectSingleNode("ErrorLog").LastChild.Attributes["LogId"].Value) + 1).ToString() : "1";
            xelement.Attributes.Append(logId);

            //creating attribute to childnode using XmlElement 
            var xstatus = xdoc.CreateAttribute("Status");
            xstatus.InnerText = status;
            xelement.Attributes.Append(xstatus);

            //creating attribute to childnode using XmlElement 
            var xlogTime = xdoc.CreateAttribute("LogTime");
            xlogTime.InnerText = String.Format("{0:dd-MM-yyyy HH:mm:ss}", DateTime.Now);
            xelement.Attributes.Append(xlogTime);

            //Adding childnode to the root node.(in my case "NewElement is root node") 
            xdoc.DocumentElement.AppendChild(xelement);
            xdoc.Save(xmlfile);            
        }
        catch (Exception ex)
        {
            Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"],
                                "Error occured while logging BackgroundWorker process",
                                "Message - " + ex.Message + "<br/><br/>StackTrace - " + ex.StackTrace);
        }
    }
    public void LogException(Exception ex)
    {
        try
        {
            //Global variable declaration 
            var xmlfile = AppDomain.CurrentDomain.BaseDirectory + "Uploads\\Logs\\BackgroundWorkerErrorLog.xml";

            // loading xml file 
            var xdoc = new XmlDocument();
            xdoc.Load(xmlfile);

            //Creating childnode to root node using Xmlelement 
            var xelement = xdoc.CreateElement("Log");


            //creating attribute to childnode using XmlElement 
            var logId = xdoc.CreateAttribute("LogId");

            logId.InnerText = (xdoc.SelectSingleNode("ErrorLog").HasChildNodes) ? (int.Parse(xdoc.SelectSingleNode("ErrorLog").LastChild.Attributes["LogId"].Value) + 1).ToString() : "1";
            xelement.Attributes.Append(logId);

            //creating attribute to childnode using XmlElement 
            var xlogTime = xdoc.CreateAttribute("LogTime");
            xlogTime.InnerText = String.Format("{0:dd-MM-yyyy HH:mm:ss}", DateTime.Now);
            xelement.Attributes.Append(xlogTime);

            //creating attribute to childnode using XmlElement 
            var logMessage = xdoc.CreateAttribute("Message");
            logMessage.InnerText = ex.Message;
            xelement.Attributes.Append(logMessage);

            //creating attribute to childnode using XmlElement 
            var logStackTrace = xdoc.CreateAttribute("StackTrace");
            logStackTrace.InnerText = ex.Message;
            xelement.Attributes.Append(logStackTrace);

            //Adding childnode to the root node.(in my case "NewElement is root node") 
            xdoc.DocumentElement.AppendChild(xelement);
            xdoc.Save(xmlfile);

            if (!bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
            {
                Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"],
                                    "Error occured while running BackgroundWorker ",
                                    "Message - " + ex.Message + "<br/><br/>StackTrace - " + ex.StackTrace);
            }
        }
        catch (Exception)
        {
            if (!bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
            {
                Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"],
                                    "Error occured while logging BackgroundWorker exception",
                                    "Message - " + ex.Message + "<br/><br/>StackTrace - " + ex.StackTrace);
            }
        }
    }

    #endregion
}