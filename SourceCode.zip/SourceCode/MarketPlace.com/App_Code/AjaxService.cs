﻿using CLB.DTO;
using CLB.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;

/// <summary>
/// Summary description for AjaxService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class AjaxService : System.Web.Services.WebService
{

    BasePage _basePage = new BasePage();

    public AjaxService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod(EnableSession = true)]
    public Boolean IsValidCaptcha(String text)
    {
        return _basePage.IsValidCaptchaCode(text);
    }

    [WebMethod(EnableSession = true)]
    public Boolean SelectTopMenuCategory(String text)
    {
        Session["SearchParams"] = text;
        return true;
    }

    [WebMethod(EnableSession = true)]
    public string EncryptPassword(string password)
    {
        if (Session["IsEncrypted"] != null)
            return password;
        Session["IsEncrypted"] = true;
        return CLB.Util.Utilities.GetEncryptedPassword(CLB.Util.Utilities.SharedSecret, password);
    }

    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod]
    public List<string> GetAutoSearchCompleteList(string inputText)
    {
        inputText = inputText.ToLower();
        List<ProductCatalog> resultProds = _basePage.GetCachedProducts();
        var aliasProductNames = from item in resultProds
                                from name in item.AliasNames.Split(',')
                                where !string.IsNullOrEmpty(name) && name.ToLower().Contains(inputText)
                                let d = name.Trim() //+ " > " + item.SubCategory.SubCategoryName
                                select d;
        //.Replace(inputText, ("<b>" + inputText+"</b>"))
        var filterData = (from rp in resultProds
                          where !string.IsNullOrEmpty(rp.ProductName) && rp.ProductName.ToLower().Contains(inputText)
                          let c = rp.ProductName.Trim() //+ " > " + rp.SubCategory.SubCategoryName
                          select c).Concat(aliasProductNames).ToList();

        return filterData;
    }

    [WebMethod(EnableSession = true)]
    public List<Category> GetCategoryHierarchyList()
    {
        List<Category> menuItems = new List<Category>();

        if (Session["CategoryHierarchies"] != null)
        {
            menuItems = (List<Category>)Session["CategoryHierarchies"];
        }
        else
        {
            List<Category> catgyList = _basePage.GetCachedCategories().Where(p => p.Status == CLB.Enums.Status.Active).ToList();
            List<SubCategory> subCatgyList = _basePage.GetCachedSubCategories().Where(p => p.Status == CLB.Enums.Status.Active).ToList();

            foreach (var eachCatgy in catgyList)
            {
                List<SubCategory> retList = subCatgyList.Where(p => p.Category.CategoryID == eachCatgy.CategoryID).ToList();
                if (retList != null && retList.Count() > 0)
                {
                    foreach (var subCat in retList)
                    {
                        subCat.Category.MainCategory = new MainCategory() { MainCategoryID = eachCatgy.MainCategory.MainCategoryID, MainCategoryName = eachCatgy.MainCategory.MainCategoryName };
                    }
                    eachCatgy.SubCategories = retList.OrderBy(p => p.DisplayOrder).ToList();

                    menuItems.Add(eachCatgy);
                }
            }
            Session["CategoryHierarchies"] = menuItems;
        }

        //Used For popular category section...
        Dictionary<string, Category> categoryImagesInfo = new Dictionary<string, Category>();

        foreach (var catItem in menuItems)
        {
            string fileName = System.Configuration.ConfigurationManager.AppSettings[catItem.CategoryID.ToString()];
            if (!string.IsNullOrEmpty(fileName))
            {
                catItem.ImagePath = fileName;
                categoryImagesInfo.Add(catItem.CategoryID.ToString(), catItem);
            }
        }
        Session["CategoryImagesInfo"] = categoryImagesInfo;

        return menuItems.OrderBy(p => p.DisplayOrder).ToList();
    }

    [WebMethod]
    public List<MainCategory> GetMainCategoriesList()
    {
        List<MainCategory> mainCatList = _basePage.GetCachedMainCategories().Where(s => s.Status == CLB.Enums.Status.Active).ToList();

        return mainCatList;
    }

    [WebMethod(EnableSession = true)]
    public Boolean SetSearchInformation(string category, string subCategory, string product)
    {
        var param = new SearchParams
        {
            CategoryName = category,
            SubCategoryName = subCategory,
            ProductName = product
        };
        Session[CLB.Util.SessionVariables.SearchParams] = param;
        return true;
    }

    [WebMethod(EnableSession = true)]
    public object SearchProducts(int pageNo)
    {
        var list = new List<VendorInventory>();
        var message = "Search results";
        var resultsperpage = 4;
        var totalCount = 0;
        try
        {
            pageNo--;
            var vim = new VendorInventoryManager();
            var param = (SearchParams)Session[CLB.Util.SessionVariables.SearchParams];

            if (param != null)
            {
                list = vim.SearchProducts(param.CategoryName, param.SubCategoryName, param.ProductName);
                var cityID = 0;
                if (!string.IsNullOrEmpty(param.CategoryName))
                    message = "Search results for " + param.CategoryName;
                else if (!string.IsNullOrEmpty(param.SubCategoryName))
                    message = "Search results for " + param.SubCategoryName;
                else if (!string.IsNullOrEmpty(param.ProductName))
                    message = "Search results for " + param.ProductName;
                else if (!string.IsNullOrEmpty(param.CityName))
                {
                    var cities = _basePage.GetCachedCities();
                    cityID = cities.FirstOrDefault(x => x.CityName.ToLower() == param.CityName.ToLower() ||
                        (!string.IsNullOrEmpty(x.AliasNames) &&
                        x.AliasNames.Split(',').Any(y => y.Trim().ToLower() == param.CityName.ToLower()))).CityID;
                    message = "Search results for " + param.CityName;
                }

                //check if vendor inventory id is passed
                if (param.VendorInventoryID > 0)
                {
                    list = list.Where(x => x.InventoryID == param.VendorInventoryID).ToList();
                }
            }
            else
            {
                list = vim.SearchProducts();
            }

            if (list != null && list.Count > 0)
            {
                totalCount = list.Count;
                message += " - " + list.Count + " products found";
                Session[CLB.Util.SessionVariables.SearchProdIds] = list.Select(x => x.Product.ProductID).ToList();
                list = list.Skip(resultsperpage * pageNo).Take(resultsperpage).ToList();

                foreach (var item in list)
                {
                    item.Description = HttpUtility.HtmlDecode(item.Description);
                    if (!item.MoreRedirectURL.ToLower().Contains("http"))
                        item.MoreRedirectURL = "http://" + item.MoreRedirectURL;
                    item.UOM.UnitName = item.UOM.UnitName.TrimEnd('s');
                    var hasImage = false;
                    item.ImageUrl = _basePage.LoadImage(item.InventoryID, out hasImage);
                }
            }
        }
        catch (Exception ex)
        {
            _basePage.TrackException(ex);
        }
        return new
        {
            list = list,
            count = totalCount,
            message = (totalCount > 0
                        ? message
                        : "No listings match your criteria. Please expand your search.")
        };
    }

    [WebMethod(EnableSession = true)]
    public List<Category> GetAllProductsList(string filterVal)
    {
        List<Category> catgyList = null;
        if (!string.IsNullOrEmpty(filterVal))
        {
            List<MainCategory> mainCatList = _basePage.GetCachedMainCategories().Where(s => s.Status == CLB.Enums.Status.Active).ToList();
            MainCategory mainCat = mainCatList.Where(p => p.MainCategoryID == Convert.ToInt32(filterVal)).FirstOrDefault();
            catgyList = _basePage.GetCachedCategories(false, mainCat.MainCategoryID).Where(s => s.Status == CLB.Enums.Status.Active).OrderBy(p => p.DisplayOrder).ToList();
        }
        else
        {
            catgyList = _basePage.GetCachedCategories().Where(s => s.Status == CLB.Enums.Status.Active).OrderBy(p => p.DisplayOrder).ToList();
        }

        List<SubCategory> result = _basePage.GetCachedSubCategories().Where(s => s.Status == CLB.Enums.Status.Active).OrderBy(p => p.DisplayOrder).ToList();

        List<Category> menuItems = new List<Category>();

        foreach (var eachCatgy in catgyList)
        {
            //	Display Ordering for Categories and subcategories should be like this.. (1,2,3;;  2,3,0;; 1, 2,0;; 1,0,0;; 2,4,6;; 0,0,0)

            List<SubCategory> filteredList = result.Where(m => m.Category.CategoryID == eachCatgy.CategoryID).ToList();
            List<SubCategory> subCatgyList = filteredList.OrderBy(p => p.DisplayOrder).Where(s => s.Status == CLB.Enums.Status.Active).ToList();
            if (subCatgyList.Count() == 0)
            {
                subCatgyList = filteredList.OrderBy(p => p.DisplayOrder).ToList();
            }
            else if (subCatgyList.Count() == 1)
            {
                subCatgyList = subCatgyList.Concat(filteredList.OrderBy(p => p.DisplayOrder).Take(2)).ToList();
            }
            else if (subCatgyList.Count() == 2)
            {
                subCatgyList = subCatgyList.Concat(filteredList.OrderBy(p => p.DisplayOrder).Take(1)).ToList();
            }

            foreach (var subCat in subCatgyList)
            {
                subCat.Category.MainCategory = new MainCategory() { MainCategoryID = eachCatgy.MainCategory.MainCategoryID, MainCategoryName = eachCatgy.MainCategory.MainCategoryName };
            }
            eachCatgy.SubCategories = subCatgyList;

            menuItems.Add(eachCatgy);
        }

        return menuItems.Where(p => p.DisplayOrder > 0).Concat(menuItems.Where(m => m.DisplayOrder == 0)).ToList();
    }

    [WebMethod(EnableSession = true)]
    public Dictionary<string, List<string>> GetBannerAdsImagePaths()
    {
        Dictionary<string, List<string>> imagesDict = new Dictionary<string, List<string>>();
        List<string> imagePaths = new List<string>();
        //Get the Image Folder path
        for (int i = 1; i <= 4; i++)
        {
            string path = Path.Combine(_basePage.appDataFolder, "BannerAds\\Position-" + i + "\\");
            DirectoryInfo dir = new DirectoryInfo(path);
            FileInfo[] imageFiles = dir.GetFiles();
            imagePaths = imageFiles.Select(p => string.Format(@"/Uploads/BannerAds/Position-{0}/{1}", i, p.Name)).ToList();

            var param = (SearchParams)Session[CLB.Util.SessionVariables.SearchParams];
            var prodIds = (List<long>)Session[CLB.Util.SessionVariables.SearchProdIds];
            if (param != null && prodIds != null && prodIds.Count > 0)
            {
                var result = (from item in imagePaths
                              let itemId = item.Split('/')[item.Split('/').Length - 1].Split('.')[0].Split('-')[1]
                              where prodIds.Any(x => x == long.Parse(itemId))
                              select item).ToList();
                //<UserID>-<ProductID>-<VendorInventoryID>

                if (result != null && result.Count > 0)
                    imagesDict.Add("position-" + i, result);
            }
            else
                imagesDict.Add("position-" + i, imagePaths);
        }
        return imagesDict;
    }

    ///Sateesh code starts here

    [WebMethod(EnableSession = true)]
    public List<Category> GetMenuCategories()
    {
        List<Category> menuItems = new List<Category>();

        if (Session["MenuCategories"] != null)
        {
            menuItems = (List<Category>)Session["MenuCategories"];
        }
        else
        {
            menuItems = _basePage.GetMenuCategies();
            //    List<SubCategory> subCatgyList = _basePage.GetCachedSubCategories().Where(p => p.Status == CLB.Enums.Status.Active).ToList();

            //    foreach (var eachCatgy in catgyList)
            //    {
            //        List<SubCategory> retList = subCatgyList.Where(p => p.Category.CategoryID == eachCatgy.CategoryID).ToList();
            //        if (retList != null && retList.Count() > 0)
            //        {
            //            foreach (var subCat in retList)
            //            {
            //                subCat.Category.MainCategory = new MainCategory() { MainCategoryID = eachCatgy.MainCategory.MainCategoryID, MainCategoryName = eachCatgy.MainCategory.MainCategoryName };
            //            }
            //            eachCatgy.SubCategories = retList.OrderBy(p => p.DisplayOrder).ToList();

            //            menuItems.Add(eachCatgy);
            //        }
            //    }
            //    Session["MenuCategories"] = menuItems;
            //}

            ////Used For popular category section...
            //Dictionary<string, Category> categoryImagesInfo = new Dictionary<string, Category>();

            //foreach (var catItem in menuItems)
            //{
            //    string fileName = System.Configuration.ConfigurationManager.AppSettings[catItem.CategoryID.ToString()];
            //    if (!string.IsNullOrEmpty(fileName))
            //    {
            //        catItem.ImagePath = fileName;
            //        categoryImagesInfo.Add(catItem.CategoryID.ToString(), catItem);
            //    }
            //}
            //Session["CategoryImagesInfo"] = categoryImagesInfo;
        }
        return menuItems;

    }
}
