﻿#region Developer Note
/*
 * Created by       : Satya Sai Prasad K
 * Created Date     : 15-Dec-2012
 * Version          : 1.0
 */
#endregion

#region Imports

using CLB.BL;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Web;
using System.Web.Caching;
using System.Web.DynamicData;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ListItem = System.Web.UI.WebControls.ListItem;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using Newtonsoft.Json;
using CLB.Enums;
using CLB.BL.Administration;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Utilities = CLB.Util.Utilities;

#endregion

/// <summary>
/// Summary description for BasePage
/// </summary>
public class BasePage : Page
{
    #region Global Variables
    
    public string appDataFolder = Path.Combine(HttpRuntime.AppDomainAppPath, "Uploads\\");
    private string _validCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890.";
    //public string TodaysDate = DateTime.Today.String("dd-MM-yyyy");
    protected string[] DateFormats =
                {
                    "dd-MM-yyyy", "dd-M-yyyy", "d-M-yyyy", "d-MM-yyyy",
                    "dd/MM/yyyy", "dd/M/yyyy", "d/M/yyyy", "d/MM/yyyy",
                    //"MM-dd-yyyy", "M-dd-yyyy", "M-d-yyyy", "MM-d-yyyy",
                    //"MM/dd/yyyy", "M/dd/yyyy", "M/d/yyyy", "MM/d/yyyy"
                };
    protected bool _status;
    protected long _identity;
    protected int _maxLength = 4000;

    //details of current user are stored in Page_PreInit method
    public User CurrentUser;
    public RedirectPage _redirectPage = new RedirectPage();

    string[] emptyDataTemplates = null;

    string[] pagestoSkip = new[] { "sendenquiry", "sendmultiitemenquiry", "getquote", "home", "search", "index", "logout", 
        "forgotpassword", "resetpassword", "userregistration", "userregistrationsuccess", "pagenotfound",
        "sessionexpired", "adrouter" };

    #endregion

    #region Public Properties

    public string GetDomainName
    {
        get
        {
            var domainUrl = "http://ProcureMENA.com";
            //var domainUrl = "http://sevenhills.com/";

            if (!IsDevEnvironment)
                domainUrl = HttpContext.Current.Request.Url.ToString();

            var domainName = GetDomainNameFromUrl(domainUrl);
            return domainName.Split('.').Length == 1
                ? domainName
                : string.Join(".", domainName.Split('.').Skip(1));
        }
    }

    public string GetDomainUrl
    {
        get
        {
            var domainUrl = "http://ProcureMENA.com";
            //var domainUrl = "http://sevenhills.com/";

            if (!IsDevEnvironment)
                domainUrl = HttpContext.Current.Request.Url.ToString();

            var domainName = GetDomainNameFromUrl(domainUrl);
            return "http://" + (domainName.Split('.').Length == 1
                ? domainName
                : string.Join(".", domainName.Split('.').Skip(1))) + ".com";
        }
    }

    public bool IsDevEnvironment
    {
        get { return bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]); }
    }

    /*public bool IsSuperAdmin
    {
        get
        {
            if (CurrentUser == null)
                return false;
            return (CurrentUser.Role.RoleID == 1);
        }
    }*/

    #endregion

    #region Constructor

    /// <summary>
    /// Constructor
    /// </summary>
    public BasePage()
    {
        emptyDataTemplates = new[] { _redirectPage.ViewEmailQueries.Key };

        //store current user details from session to property. This CurrentUser can be used in all pages
        if (HttpContext.Current.Session != null)
        {
            CurrentUser = (User)HttpContext.Current.Session[SessionVariables.CurrentUser];

            if (HttpContext.Current.Session[SessionVariables.CountryId] == null)
                HttpContext.Current.Session[SessionVariables.CountryId] = GetCountryByIP();
        }

    }

    #endregion

    #region Protected Methods
    protected void BindTime(DropDownList ddlHours, DropDownList ddlMinutes)
    {
        //set default values
        for (int i = 0; i <= 23; i++)
        {
            if (DateTime.Now.Hour < i) continue;
            ddlHours.Items.Add(new ListItem(i.ToString()));
        }

        ddlHours.Items.Insert(0, new ListItem("Hrs", ""));

        //set default values
        for (int i = 0; i <= 59; i++)
            ddlMinutes.Items.Add(new ListItem(i.ToString()));
        ddlMinutes.Items.Insert(0, new ListItem("Mins", ""));
    }    
    protected string CreateRandomPassword(int passwordLength, int? seed = null)
    {
        const string allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ*&%$#@";
        var randNum = seed.HasValue ? new Random(seed.Value) : new Random();
        var chars = new char[passwordLength];
        for (var i = 0; i < passwordLength; i++)
        {
            chars[i] = allowedChars[(int)((allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }
    protected void Export(dynamic list, string fileName, ExportType exportType, string[] exportColumns = null)
    {
        var form = new HtmlForm();
        Response.Clear();
        Response.Buffer = true;
        switch (exportType)
        {
            case ExportType.PDF:
                Response.AddHeader("content-disposition", "attachment;filename=" + fileName + ".pdf");
                Response.ContentType = "application/pdf";
                break;
            case ExportType.Excel:
                Response.AddHeader("content-disposition", "attachment;filename=" + fileName + ".xls");
                Response.ContentType = "application/vnd.ms-excel";
                break;
            case ExportType.Word:
                Response.AddHeader("content-disposition", "attachment;filename=" + fileName + ".doc");
                Response.ContentType = "application/vnd.ms-word";
                break;
        }
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Charset = "";

        var sw = new StringWriter();
        var hw = new HtmlTextWriter(sw);
        form.Controls.Add(BuildExportGrid(list, exportColumns));
        this.Controls.Add(form);
        form.RenderControl(hw);
        //style to format numbers to string
        string style = @"<style> .textmode { mso-number-format:\@; } </style>";
        Response.Write(style);
        if (exportType == ExportType.PDF)
        {
            var sr = new StringReader(sw.ToString());
            var pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            var htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            htmlparser.Parse(sr);
            pdfDoc.Close();
            Response.Write(pdfDoc);
        }
        else
        {
            Response.Output.Write(sw.ToString());
        }

        Response.Flush();
        Response.End();
    }
    protected string FormatDate(object date)
    {
        if (date == null) return "-";
        return DateTime.Parse(date.ToString()).ToString("dd MMM yyyy");
    }
    protected string FormatDateTime(object date)
    {
        return (date == null || string.IsNullOrEmpty(date.ToString())) ? "-" : DateTime.Parse(date.ToString()).ToString("dd MMM yyyy, hh:mm tt");
    }
    protected string FormatPrice(object price)
    {
        if (double.Parse(price.ToString()) == 0) return "-";
        return double.Parse(price.ToString()).ToString("#.##");
        //return "Rs." + double.Parse(price.ToString()).ToString("#.##") + "/-";
    }
    protected int GetUserID(string fname, string lname, string email, string mobile, string password)
    {
        int userid = 0;
        if (CurrentUser == null)
        {
            email = email.Trim();
            mobile = mobile.Trim();

            var users = GetCachedUsers();
            users = (from user in users
                     where (email.ToLower() == user.Email.ToLower() || mobile == user.Mobile)
                     select user).ToList();

            //indicates that user does not exist
            if (users == null || users.Count == 0)
            {
                //create new user 
                var user = new User
                {
                    Email = email,
                    InvalidLoginAttempts = 0,
                    IsNewPassword = true,
                    Mobile = mobile,
                    Password = Utilities.GetEncryptedPassword(Utilities.SharedSecret, password),
                    Role = new CLB.DTO.Role { RoleID = (int)UserRole.Customer },
                    Status = Status.AdminApproval,
                    UserDetails = new UserDetails
                    {
                        FirstName = fname.Trim(),
                        LastName = lname.Trim(),
                        RegisteredIP = Utilities.IPAddress == null ? "1.0.0.0" : Utilities.IPAddress,
                        UserID = 0,
                        Gender = Gender.Male,
                        Country = new Country
                        {
                            CountryID = Convert.ToInt32(Session[SessionVariables.CountryId])
                        },
                        CreatedBy = "0",
                        ModifiedBy = "0"
                    },
                    UserID = 0
                };
                var _userManager = new UserManager();
                if (_userManager.SaveUser(user, out userid, out _status) == DbMessage.Success)
                {
                    //reset cache
                    GetCachedUsers(clearCache: true);
                    Utilities.SendEmail(email, "Your New Login Details at " + GetDomainName,
                           "<br/><br/>Dear " + fname + " "+ lname + ",<br/><br/>" +
                           "In your visit to " + GetDomainName + ", dated " + DateTime.Now.ToString("dd-MM-yyyy") + ", you have successfully registered with us. Here are your login details. <br/><br/>" +
                           "<br/><br/>Email: " + email +
                           "<br/><br/>Mobile: " + mobile +
                           "<br/><br/>Password: " + password);

                    Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"], "Account pending for Activation",
                            "Hi Admin,<br/><br/> A new User has registered and activation is pending. Please review and activate.<br/><br/>" +
                            "<br/><br/>Email: " + email +
                            "<br/><br/>Mobile: " + mobile + "<br/><br/>" +
                            GetDomainUrl + "/" + _redirectPage.ViewCustomers.Key);
                }
                else
                {                    
                    return 0;
                }
            }
            else
            {
                userid = users.FirstOrDefault().UserID;
            }
        }
        else
        {
            userid = CurrentUser.UserID;
        }
        return userid;
    }
    protected int GetCityID(string cityName)
    {
        CityManager _cityManager = new CityManager();
        var cities = GetCachedCities(false, Convert.ToInt32(Session[SessionVariables.CountryId]));

        var cityDetails = cities.FirstOrDefault(x => (x.CityName.ToLower().Equals(cityName.ToLower().Trim())
                || x.AliasNames.Split(',').Any(y => y.ToLower().Trim().Equals(cityName.ToLower().Trim()))));

        int cityID = 0;
        #region Validate and create new City

        if (cityDetails == null)
        {
            _cityManager.SaveCity(
                new City
                {
                    CityID = 0,
                    CityName = cityName.Trim(),
                    Status = Status.Active,
                    Country = new Country
                    {
                        CountryID = int.Parse(Session[SessionVariables.CountryId].ToString())
                    }
                }, out cityID, out _status);
            //clear cache after new city is inserted
            GetCachedCities(true);
        }
        else
        {
            cityID = cityDetails.CityID;
        }
        
        #endregion

        return cityID;
    }
    protected dynamic GetFormattedDate(string date, bool isNullable = false)
    {
        if (string.IsNullOrEmpty(date.Trim()))
            return (isNullable ? (DateTime?)null : new DateTime());
        try
        {
            return DateTime.ParseExact(date.Trim(), DateFormats, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
        }
        catch (Exception)
        {
            //supress exception
            //throw;
        }        
        return (isNullable ? (DateTime?)null : new DateTime());
    }
    public string GetFrequency(string frequency)
    {
        if (Enum.IsDefined(typeof(Frequency), int.Parse(Eval(frequency).ToString())))
            return Enum.Parse(typeof(CLB.Enums.Frequency), Eval(frequency).ToString()).ToString();
        else
            return Eval(frequency).ToString() + " days";
    }
    public string GetPlanFrequency(string frequency)
    {
        if (Enum.IsDefined(typeof(Frequency), int.Parse(Eval(frequency).ToString())))
        {
            switch ((Frequency)Enum.Parse(typeof(CLB.Enums.Frequency), Eval(frequency).ToString()))
            {
                case Frequency.Daily:
                    //option is excluded while binding
                    return "day";
                case Frequency.Weekly:
                    return "week";
                case Frequency.Monthly:
                    return "month";
                case Frequency.Quarterly:
                    return "3 months";
                case Frequency.Halfyearly:
                    return "6 months";
                case Frequency.Yearly:
                    return "year";
            }
        }
        else
            return Eval(frequency).ToString() + " days";
        return "";
    }
    protected string GetStringValue(object value)
    {
        if (value == null) return string.Empty;
        if (string.IsNullOrEmpty(value.ToString())) return string.Empty;
        return value.ToString();
    }
    protected string GetSqlDate(string date)
    {
        if (string.IsNullOrEmpty(date.Trim()))
            return null;
        try
        {
            return DateTime.ParseExact(date.Trim(), DateFormats, System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None).ToString("yyyy-MM-dd");
        }
        catch (Exception ex)
        {
            //supress exception
            //throw new Exception(ex.Message + "  input: " + date);
        }
        return null;
    }
    protected void gridview_Init(object sender, EventArgs e)
    {
        var control = (GridView)((Control)sender);
        control.AutoGenerateColumns = false;
        control.CssClass = "gridview";
        control.PagerStyle.CssClass = "pgr";
        control.AlternatingRowStyle.CssClass = "alt";
        control.GridLines = GridLines.None;
        control.Width = new Unit("99%");
        control.AllowPaging = true;
        control.AllowSorting = true;
        control.ShowFooter = true;
        control.PageSize = 50;
        if (!emptyDataTemplates.Any(x => x.ToString().ToLower() == control.Parent.Page.Request.Url.AbsolutePath.TrimStart('/').ToLower()))
            control.EmptyDataRowStyle.CssClass = "emptygridview";
        control.EmptyDataText = "No Records Found !!!";
        control.PageIndexChanging += gridview_PageIndexChanging;
    }
    public bool IsEmpty(TextBox textBox)
    {
        return string.IsNullOrEmpty(textBox.Text.Trim());
    }
    public bool IsValidNumber(TextBox textBox)
    {
        int price = 0;
        return (!string.IsNullOrEmpty(textBox.Text.Trim()) && int.TryParse(textBox.Text.Trim(), out price));
    }
    public bool IsValidEmail(TextBox textBox)
    {
        Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
        Match match = regex.Match(textBox.Text.Trim());
        return (match.Success);
    }
    public bool IsValidPhone(TextBox textBox)
    {
        if (textBox.Text.Length != 10) return false;
        Regex regex = new Regex(@"[^0-9]");
        return !regex.IsMatch(textBox.Text.Trim());
    }
    protected void LogoutUser()
    {
        if (Session[SessionVariables.UserId] != null)
        {
            #region Save Logout Information

            if (HttpRuntime.Cache["LoginLogId-" + Session[SessionVariables.UserId]] != null)
            {
                var accountManager = new AccountManager();
                var result = accountManager.SaveLogoutInformation(
                    int.Parse(HttpRuntime.Cache["LoginLogId-" + Session[SessionVariables.UserId]].ToString()));
            }

            #endregion

            HttpCookie cookie = Request.Cookies["UserName"];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(cookie);
            }
            HttpCookie cookie1 = Request.Cookies["Password"];
            if (cookie1 != null)
            {
                cookie1.Expires = DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(cookie1);
            }
            Cache.Remove(Session[SessionVariables.UserId].ToString());
            Application.Contents.Remove(Session[SessionVariables.UserId].ToString());
        }
        Session.Clear();
        Session.Abandon();
    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        Page_PreInit();
        MasterPageFile = Request.QueryString["T"] != null ? "~/PopupMasterPage.master" : "~/MasterPage.master";
    }
    protected void Page_PreInit()
    {
        //set page title dynamically if needed
        Page.Title = Page.Title;

        //if (pagestoSkip.Any(x => Page.Request.Url.AbsolutePath.ToLower().Contains(x) && Session[SessionVariables.CurrentUser] == null))
        if (pagestoSkip.Any(x => Page.Request.Url.AbsolutePath.ToLower().Contains(x)))
        {
            //Sessionid is validated in the pages to listed in pagestoSkip
            if (HttpContext.Current.Session[SessionVariables.CurrentUser] != null)
                CurrentUser = (User)HttpContext.Current.Session[SessionVariables.CurrentUser];
            return;
        }

        //check if authenticated user and valid domain redirection
        if (Session[SessionVariables.CurrentUser] == null)
        {
            if (Page.Request.Url.AbsolutePath.ToLower().Contains("logout"))
            {
                if (Request.QueryString["Redirect"] == null)
                    Response.Redirect(_redirectPage.Login.Key);
            }
            else
                //redirect to login page if session expires abnormally
                Response.Redirect(_redirectPage.Login.Key + "?Redirect=" + Page.Request.Url.AbsolutePath);
        }
        else
        {
            //store current user details from session to property. This CurrentUser can be used in all pages
            CurrentUser = (User)HttpContext.Current.Session[SessionVariables.CurrentUser];

            var currentPage = Page.Request.Url.AbsolutePath.Trim();
            /*
            if (IsDevEnvironment)
            {
                currentPage = currentPage.ToLower().Replace("ui", string.Empty);
            }
            */
            if (currentPage.Split('/').Count() > 1) currentPage = currentPage.Split('/')[currentPage.Split('/').Length - 1];
            currentPage = currentPage.ToLower().TrimStart('/').TrimEnd('/');

            //if (Page.Request.Url.Query != string.Empty) currentPage += Page.Request.Url.Query;

            var user = (User)HttpContext.Current.Session[SessionVariables.CurrentUser];

            if (!user.Role.Screens.Exists(x => x.ScreenName.ToLower() == currentPage.ToLower())) // + Page.Request.Url.Query.ToLower()
                Response.Redirect(_redirectPage.Unauthorized.Key + "?P=" + currentPage);

            //skip all validations in development environment
            if (!IsDevEnvironment)
            {
                //Following pages are accessible only for super admins and dynamic users created by super admins
                if ((currentPage == "adminbalance" || currentPage == "admincommissions" ||
                     currentPage == "cancellationpolicy"))
                    Response.Redirect(_redirectPage.Unauthorized.Key, true);

                //Following pages are accessible only for site admins and dynamic users created by site admins
                /** agentdistributorbalance must be accessible for distributor **/
                //if ((currentPage == "agentdistributorbalance") && IsSiteAdmin == -1)
                //Response.Redirect(_redirectPage.Unauthorized.Key, true);
            }
        }
    }
    protected void gridview_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        var control = (GridView)((Control)sender);
        control.PageIndex = e.NewPageIndex;
        control.DataSource = ViewState["FilterList"];
        control.DataBind();
    }
    protected void PostBackBind_DataBinding(object sender, EventArgs e)
    {
        var sm = (ScriptManager)Page.Master.FindControl("Scriptmanager1");
        switch (sender.GetType().Name)
        {
            case "ImageButton":
                sm.RegisterPostBackControl((ImageButton)sender);
                break;
            case "Button":
                sm.RegisterPostBackControl((Button)sender);
                break;
        }
    }
    protected BoundField SetBoundField(string columnName, string headerText = null, int? width = null)
    {
        var boundField = new BoundField
        {
            DataField = columnName,
            HeaderText = !string.IsNullOrEmpty(headerText) ? headerText : columnName,
            SortExpression = columnName,
        };
        if (width.HasValue)
            boundField.ItemStyle.Width = width.Value;
        return boundField;
    }
    /// <summary>
    /// Method to sort gridview columns
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="gridView"></param>
    /// <param name="sortBy"></param>
    protected void SortList<T>(GridView gridView, string sortBy)
    {
        var list = ((List<T>)ViewState["FilterList"]);

        bool isAscending;

        if (ViewState["SortDirection"] == null ||
            ViewState["SortDirection"].ToString() == SortDirection.Ascending.ToString())
        {
            ViewState["SortDirection"] = SortDirection.Descending.ToString();
            isAscending = true;
        }
        else
        {
            ViewState["SortDirection"] = SortDirection.Ascending.ToString();
            isAscending = false;
        }

        gridView.DataSource = isAscending
                                  ? list.AsQueryable().OrderBy(GetPropertyExpression<T>(sortBy)).ToList()
                                  : list.AsQueryable()
                                        .OrderByDescending(GetPropertyExpression<T>(sortBy))
                                        .ToList();
        gridView.DataBind();
    }
    public string TrimText(string value, int limit)
    {
        return value.Trim().Length > limit ? value.Substring(0, limit).Trim() : value.Trim();
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// This methos is used to set the default values to controls
    /// </summary>        
    public void ClearControls(Control parent, string controlstoSkip = null)
    {
        foreach (Control c in parent.Controls)
        {
            if (controlstoSkip != null && c.ID != null && controlstoSkip.Split(',').FirstOrDefault(x => x.ToUpper() == c.ID.ToUpper()) != null)
                continue;

            if (c.GetType() == typeof(TextBox))
            {
                ((TextBox)(c)).Text = String.Empty;
                ((TextBox)(c)).Enabled = true;
            }
            else if (c.GetType() == typeof(HtmlInputText))
            {
                ((HtmlInputText)(c)).Value = String.Empty;
                ((HtmlInputText)(c)).Disabled = false;
            }
            else if (c.GetType() == typeof(HtmlTextArea))
            {
                ((HtmlTextArea)(c)).Value = String.Empty;
                ((HtmlTextArea)(c)).InnerText = String.Empty;
                ((HtmlTextArea)(c)).InnerHtml = String.Empty;
                ((HtmlTextArea)(c)).Disabled = false;
            }
            else if (c.GetType() == typeof(HtmlInputRadioButton))
            {
                ((HtmlInputRadioButton)(c)).Checked = false;
                ((HtmlInputRadioButton)(c)).Disabled = false;
            }
            else if (c.GetType() == typeof(HtmlSelect))
            {
                if (((HtmlSelect)(c)).Items.Count > 0)
                    ((HtmlSelect)(c)).SelectedIndex = 0;
                ((HtmlSelect)(c)).Disabled = false;
            }
            else if (c.GetType() == typeof(DropDownList))
            {
                if (((DropDownList)(c)).Items.Count > 0)
                    ((DropDownList)(c)).SelectedIndex = 0;
                ((DropDownList)(c)).Enabled = true;
            }
            else if (c.GetType() == typeof(TreeView))
            {
                var col = ((TreeView)(c)).Nodes;
                if (col.Count > 0)
                {
                    foreach (TreeNode node in col)
                        node.Checked = false;
                }
            }
            else if (c.GetType() == typeof(CheckBoxList))
            {
                var items = ((CheckBoxList)(c)).Items;
                if (items.Count > 0)
                {
                    foreach (ListItem li in items)
                        li.Selected = false;
                }
                ((CheckBoxList)(c)).Enabled = true;
            }
            else if (c.GetType() == typeof(RadioButtonList))
            {
                var items = ((RadioButtonList)(c)).Items;
                if (items.Count > 0)
                {
                    foreach (ListItem li in items)
                        li.Selected = false;
                }
                ((RadioButtonList)(c)).Enabled = true;
            }
            else if (c.GetType() == typeof(CheckBox))
            {
                ((CheckBox)(c)).Checked = false;
                ((CheckBox)(c)).Enabled = true;
            }
            if (c.HasControls())
            {
                ClearControls(c, controlstoSkip);
            }
        }
    }
    public void DisableControls(Control gv)
    {
        var lb = new LinkButton();
        var l = new Literal();
        var name = String.Empty;
        for (var i = 0; i < gv.Controls.Count; i++)
        {
            if (gv.Controls[i].GetType() == typeof(LinkButton))
            {
                var linkButton = gv.Controls[i] as LinkButton;
                if (linkButton != null) l.Text = linkButton.Text;
                gv.Controls.Remove(gv.Controls[i]);
                gv.Controls.AddAt(i, l);
            }
            else if (gv.Controls[i].GetType() == typeof(DropDownList))
            {
                if (gv.Controls[i].HasControls())
                {
                    var dropDownList = gv.Controls[i] as DropDownList;
                    if (dropDownList != null)
                        l.Text = dropDownList.SelectedItem.Text;

                    gv.Controls.Remove(gv.Controls[i]);

                    gv.Controls.AddAt(i, l);
                }
            }
            if (gv.Controls[i].HasControls())
            {
                DisableControls(gv.Controls[i]);
            }
        }
    }
    public String DecodeUrl(String url)
    {
        return Server.UrlDecode(url);
    }
    public String EncodeUrl(String url)
    {
        return Server.UrlEncode(url);
    }
    public string GetDomainNameFromUrl(string domainUrl)
    {
        var splitstring = "";
        if (domainUrl.IndexOf(".com") > 0)
            splitstring = ".com";
        else if (domainUrl.IndexOf(".co.in") > 0)
            splitstring = ".co.in";
        else if (domainUrl.IndexOf(".in") > 0)
            splitstring = ".in";

        var domainName = domainUrl.Substring(0, domainUrl.IndexOf(splitstring)).Replace("http://", "").Replace("www.", "").ToLower();
        return domainName;
    }
    public Boolean IsValidCaptchaCode(String text)
    {
        //Email parameter is passed because once captcha code is verified
        return Session["CaptchaImageText"] != null && Session["CaptchaImageText"].ToString() == text;
    }
    public string LoadImage(long inventoryID, out bool hasImage)
    {
        hasImage = false;
        string imageUrl = "";
        string fileExtension = "bmp";
        //Get the Image Folder path
        string path = Path.Combine(appDataFolder, "ProductImages\\" + inventoryID + "\\");
        //Create a directory with the path given
        DirectoryInfo dir = new DirectoryInfo(path);
        //Check if directory exists
        if (dir.Exists)
        {
            FileInfo[] fileArray = dir.GetFiles();
            //Code to set default image if no image is present
            for (int i = 1; i <= 1; i++)
            {
                FileInfo f1 = new FileInfo(path + i + ".jpg");
                FileInfo f2 = new FileInfo(path + i + ".jpeg");
                FileInfo f3 = new FileInfo(path + i + ".gif");
                FileInfo f4 = new FileInfo(path + i + ".bmp");
                FileInfo f5 = new FileInfo(path + i + ".png");
                if (!f1.Exists && !f2.Exists && !f3.Exists && !f4.Exists && !f5.Exists)
                    imageUrl = "~/Images/No_image_available.bmp";
            }
            //Code to retrieve product images from directory with productid name
            foreach (FileInfo file in fileArray)
            {
                if (file.Extension.ToLower() == ".jpg" || file.Extension.ToLower() == ".jpeg" ||
                    file.Extension.ToLower() == ".gif" || file.Extension.ToLower() == ".bmp" || file.Extension.ToLower() == ".png")
                {
                    imageUrl = "~/Uploads/ProductImages/" + inventoryID + "/" + file.Name;
                    fileExtension = file.Extension;
                    hasImage = true;
                }
            }
        }
        else
        {
            for (int i = 1; i <= 1; i++)
            {
                System.IO.FileInfo f1 = new System.IO.FileInfo(path + i + ".jpg");
                System.IO.FileInfo f2 = new System.IO.FileInfo(path + i + ".jpeg");
                System.IO.FileInfo f3 = new System.IO.FileInfo(path + i + ".gif");
                System.IO.FileInfo f4 = new System.IO.FileInfo(path + i + ".bmp");
                System.IO.FileInfo f5 = new System.IO.FileInfo(path + i + ".png");
                if (!f1.Exists && !f2.Exists && !f3.Exists && !f4.Exists && !f5.Exists)
                    imageUrl = "~/Images/No_image_available.bmp";
            }
        }
        
        byte[] bytes = File.ReadAllBytes(HttpContext.Current.Server.MapPath(imageUrl));
        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
        return "data:image/" + fileExtension + ";base64," + base64String;
    }
    public string TrackException(Exception ex)
    {
        //disable exception logging in dev environment
        if (!IsDevEnvironment)
        {
            var baseClass = new BLBaseClass();
            baseClass.LogException(ex);
        }
        return DbConstants.OutMessage(DbMessage.Failed);
    }
    public string ValidAutoCompleteString(string value)
    {
        value = value.Replace("'", "").Replace("\n", " ").Replace("\t", " ");
        value = value.Length > 50 ? (value.Substring(0, 49) + "...") : value;
        string validChars = _validCharacters;
        Char[] charArray = value.ToCharArray();
        for (Int16 i = 0; i < value.Length; i++)
        {
            if (validChars.IndexOf(charArray[i]) < 0 || validChars.IndexOf(charArray[i]) > validChars.Length)
                charArray.ToList().Remove(charArray[i]);
        }
        return new string(charArray);
    }
    public String ValidateFilename(String fileName)
    {
        fileName = fileName.Replace("&", "");
        return Path.GetInvalidFileNameChars()
                   .Aggregate(fileName, (current, c) => current.Replace(c.ToString(), string.Empty));
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Method to build gridiew from dynamic list and export to pdf/excel/word
    /// </summary>
    /// <param name="list"></param>
    /// <param name="exportColumns"></param>
    /// <returns></returns>
    private GridView BuildExportGrid(dynamic list, IEnumerable<string> exportColumns = null)
    {
        if (list == null)
            return new GridView();

        var gridview = new GridView
            {
                EmptyDataText = "No records found",
                ForeColor = ColorTranslator.FromHtml("#333333"),
                AutoGenerateColumns = false
            };

        gridview.FooterStyle.BackColor = ColorTranslator.FromHtml("#FFFFFF");
        gridview.FooterStyle.ForeColor = ColorTranslator.FromHtml("#000066");
        gridview.RowStyle.ForeColor = ColorTranslator.FromHtml("#000066");
        gridview.RowStyle.HorizontalAlign = HorizontalAlign.Left;
        gridview.EmptyDataRowStyle.Font.Bold = true;
        gridview.EmptyDataRowStyle.Font.Size = new FontUnit("Small");
        gridview.EmptyDataRowStyle.ForeColor = ColorTranslator.FromHtml("#657600");
        gridview.EmptyDataRowStyle.VerticalAlign = VerticalAlign.Top;
        gridview.EmptyDataRowStyle.HorizontalAlign = HorizontalAlign.Center;

        if (list.GetType() == typeof(System.Data.DataTable))
            gridview.AutoGenerateColumns = true;
        else
        {
            foreach (var column in exportColumns)
                gridview.Columns.Add(SetBoundField(column));
        }

        gridview.DataSource = list;
        gridview.DataBind();

        return gridview;
    }

    /// <summary>
    /// Method to get dynamic property name for sorting a list
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="sortColumn"></param>
    /// <returns></returns>
    private static Expression<Func<T, object>> GetPropertyExpression<T>(string sortColumn)
    {
        // Prepare the dynamic sort expression
        Expression propConvExp;
        var paramExp = Expression.Parameter(typeof(T), typeof(T).ToString());

        if (sortColumn.Contains('.'))
        {
            var keys = sortColumn.Split('.');

            propConvExp = Expression.Property(paramExp, keys[0]);

            for (var index = 1; index < keys.Length; index++)
            {
                propConvExp = Expression.Property(propConvExp, keys[index]);
            }

            propConvExp = Expression.Convert(propConvExp, typeof(object));
        }
        else
        {
            propConvExp = Expression.Convert(Expression.Property(paramExp, sortColumn), typeof(object));
        }

        return Expression.Lambda<Func<T, object>>(propConvExp, paramExp);
    }

    private string GetCountryByIP()
    {
        ///YET TO IMPLEMENT LOGIC TO RETRIEVE COUNTRY FROM IP ADDRESS
        return "1";
    }

    #endregion

    #region View State Values

    /*public List<ProductCatalog> GetViewStateProducts(bool loadFeatures, bool loadOffers, bool clearViewState = false, int? categoryID = null,
            int? subCategoryID = null, int? brandID = null)
    {
        if (clearViewState) ViewState["Products"] = null;

        if (ViewState["Products"] == null)
        {
            var productCatalogManager = new ProductCatalogManager();
            ViewState["Products"] = productCatalogManager.GetProductCatalog(loadFeatures, loadOffers, categoryID: categoryID, 
                subCategoryID: subCategoryID, brandID: brandID);
        }
        return ViewState["Products"] as List<ProductCatalog>;
    }*/
    public List<Country> GetCachedCountries(bool clearCache = false)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("Countries"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Countries")] == null)
        {
            var countryManager = new CountryManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("Countries"),
                                  countryManager.GetCountries(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        return HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Countries")] as List<Country>;
    }


    // Sateesh code starts here


    public List<Category> GetMenuCategies(bool clearCache = false, int? mainCategoryID = null)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("MenuCategories"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("MenuCategories")] == null)
        {
            var categoryManager = new CategoryManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("MenuCategories"),
                                  categoryManager.GetMenuCategories(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        var categories = HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("MenuCategories")] as List<Category>;
        
        return categories;
    }















    //Ends here
    public List<Category> GetCachedCategories(bool clearCache = false, int? mainCategoryID = null)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("Categories"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Categories")] == null)
        {
            var categoryManager = new CategoryManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("Categories"),
                                  categoryManager.GetCategories(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        var categories = HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Categories")] as List<Category>;
        if (mainCategoryID.HasValue)
        {
            categories = categories.Where(x => x.MainCategory.MainCategoryID == mainCategoryID.Value).ToList();
        }
        return categories;
    }
    public List<City> GetCachedCities(bool clearCache = false, int? countryID = null)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("Cities"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Cities")] == null)
        {
            var cityManager = new CityManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("Cities"),
                                  cityManager.GetCities(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        var cities = HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Cities")] as List<City>;
        if (countryID.HasValue)
        {
            cities = cities.Where(x => x.Country.CountryID == countryID.Value).ToList();
        }
        return cities;
    }
    public List<EnquiryStatus> GetCachedEnquiryStatuses(bool clearCache = false)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("EnquiryStatuses"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("EnquiryStatuses")] == null)
        {
            var enquiryStatusManager = new EnquiryStatusManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("EnquiryStatuses"),
                                  enquiryStatusManager.GetEnquiryStatuses(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        return HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("EnquiryStatuses")] as List<EnquiryStatus>;
    }
    public List<MainCategory> GetCachedMainCategories(bool clearCache = false)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("MainCategories"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("MainCategories")] == null)
        {
            var mainCategoryManager = new MainCategoryManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("MainCategories"),
                                  mainCategoryManager.GetMainCategories(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        return HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("MainCategories")] as List<MainCategory>;
    }
    public List<ProductCatalog> GetCachedProducts(bool clearCache = false, int? countryID = null,
        int? mainCategoryID = null, int? categoryID = null, int? subCategoryID = null)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("Products"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Products")] == null)
        {
            var productCatalogManager = new ProductCatalogManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("Products"),
                                  productCatalogManager.GetProductCatalog(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        var products = HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Products")] as List<ProductCatalog>;
        if (countryID.HasValue)
        {
            products = products.Where(x => x.Country.CountryID == countryID.Value).ToList();
        }
        if (mainCategoryID.HasValue)
        {
            products = products.Where(x => x.MainCategory.MainCategoryID == mainCategoryID.Value).ToList();
        }
        if (categoryID.HasValue)
        {
            products = products.Where(x => x.Category.CategoryID == categoryID.Value).ToList();
        }
        if (subCategoryID.HasValue)
        {
            products = products.Where(x => x.SubCategory.SubCategoryID == subCategoryID.Value).ToList();
        }
        return products;
    }
    public List<Role> GetCachedRoles(bool clearCache = false)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("Roles"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Roles")] == null)
        {
            var roleManager = new RoleManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("Roles"),
                                  roleManager.GetRoles(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        return HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Roles")] as List<Role>;
    }
    public List<SubCategory> GetCachedSubCategories(bool clearCache = false, int? categoryID = null)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("SubCategories"));
        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("SubCategories")] == null)
        {
            var subCategoryManager = new SubCategoryManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("SubCategories"),
                                  subCategoryManager.GetSubCategories(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        var subCategories = HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("SubCategories")] as List<SubCategory>;
        if (categoryID.HasValue)
        {
            subCategories = subCategories.Where(x => x.Category.CategoryID == categoryID.Value).ToList();
        }
        return subCategories;
    }    
    public List<Screen> GetViewStateScreens(bool clearViewState = false)
    {
        if (clearViewState) ViewState["Screens"] = null;

        if (ViewState["Screens"] == null)
        {
            var roleManager = new RoleManager();
            ViewState["Screens"] = roleManager.GetScreens().OrderBy(x => x.DisplayName).ToList();
        }
        var screens = ViewState["Screens"] as List<Screen>;
        screens = screens.OrderBy(x => x.DisplayName).ToList();
        return screens;
    }
    public List<User> GetCachedUsers(int? userID = null, int?[] userRole = null, bool clearCache = false)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("Users"));
        
        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Users")] == null)
        {
            var userManager = new UserManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("Users"),
                                  userManager.GetUsers(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        var users = HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("Users")] as List<User>;
        if (userRole != null && userRole.Length > 0)
        {
            users = users.Where(x => userRole.ToList().Any(y => y.Value == x.Role.RoleID)).ToList();
        }
        if (userID.HasValue)
        {
            users = users.Where(x => x.UserID == userID).ToList();
        }
        return users;
    }
    public List<UnitofMeasurement> GetCachedUOMs(bool clearCache = false)
    {
        if (clearCache) HttpRuntime.Cache.Remove(CLB.Util.Utilities.Encrypt("UOM"));

        if (HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("UOM")] == null)
        {
            var uomManager = new UnitofMeasurementManager();
            //Set cache to expire after x hours,i.e., the object expires 
            //  and is removed from the cache x hours after it is last accessed. (x defined in web config)
            HttpRuntime.Cache.Add(CLB.Util.Utilities.Encrypt("UOM"),
                                  uomManager.GetUnitofMeasurements(),
                                  null,
                                  Cache.NoAbsoluteExpiration,
                                  new TimeSpan(int.Parse(ConfigurationManager.AppSettings["MasterDataCacheDuration"]), 0, 0),
                                  CacheItemPriority.Default,
                                  null);
        }
        return HttpRuntime.Cache[CLB.Util.Utilities.Encrypt("UOM")] as List<UnitofMeasurement>;
    }
    #endregion
}

public enum ExportType
{
    PDF,
    Excel,
    Word
}

public class AuthorizationHandler : IHttpHandler, IReadOnlySessionState
{
    public void ProcessRequest(HttpContext context)
    {
        RedirectPage _redirectPage = new RedirectPage();
        context.Response.Redirect(_redirectPage.Unauthorized.Key, false);
        context.Response.End();
    }

    public bool IsReusable
    {
        get { return false; }
    }
}


/// <summary>
/// Provides a method for performing a deep copy of an object.
/// Binary Serialization is used to perform the copy.
/// </summary>
public static class CloneEntity
{
    /// <summary>
    /// Perform a deep Copy of the object.
    /// </summary>
    /// <typeparam name="T">The type of object being copied.</typeparam>
    /// <param name="source">The object instance to copy.</param>
    /// <returns>The copied object.</returns>
    public static T Clone<T>(T source)
    {
        if (!typeof(T).IsSerializable)
        {
            throw new ArgumentException("The type must be serializable.", "source");
        }

        // Don't serialize a null object, simply return the default for that object
        if (Object.ReferenceEquals(source, null))
        {
            return default(T);
        }

        IFormatter formatter = new BinaryFormatter();
        Stream stream = new MemoryStream();
        using (stream)
        {
            formatter.Serialize(stream, source);
            stream.Seek(0, SeekOrigin.Begin);
            return (T)formatter.Deserialize(stream);
        }
    }
}