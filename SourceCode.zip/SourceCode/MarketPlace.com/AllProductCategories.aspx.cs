﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AllProductCategories : System.Web.UI.Page
{
    RedirectPage _redirectPage = new RedirectPage();

    protected void Page_Load(object sender, EventArgs e)
    {   
        
    }   
}