﻿using CLB.BL;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboards_AdminDashboard : BasePage
{
    #region Declarations

    public delegate void Enquiries_Delegate();
    EnquiryManager _enquiryManager = new EnquiryManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        //use delegates to store enquiries list to view state...
        Enquiries_Delegate d = new Enquiries_Delegate(GetUserReplyAwaitingEnquiries);
        IAsyncResult R = d.BeginInvoke(null, null); //invoking the method

        Response.Redirect(_redirectPage.ViewEnquiries.Key, true);
    }
    #endregion

    #region Private Methods
    private void GetUserReplyAwaitingEnquiries()
    {
        var enquiries = _enquiryManager.GetEnquiries(enquiryStatusID: 3);

        if (enquiries != null && enquiries.Count > 0)
        {
            foreach (var enquiry in enquiries)
            {
                //check if enquiry craeted date is  > 7 days and close it
                if ((DateTime.Now - enquiry.CreatedDate).Days > 7)
                {
                    //if the status is changed to closed (value > 8) in enquiry table, same has to be updated for corresponding
                    //records in Quotations table.
                    var result = _enquiryManager.UpdateField(Tables.Quotation, "StatusID", "11", "EnquiryID", enquiry.EnquiryID.ToString());
                    result = _enquiryManager.UpdateField(Tables.Enquiry, "StatusID", "11", "EnquiryID", enquiry.EnquiryID.ToString());
                }
                else
                {
                    string body = "Hi " + enquiry.User.UserDetails.FirstName + " " + enquiry.User.UserDetails.LastName + ",  <br/><br/> We haven't heard from you for the enquiry you've raised on " + GetFormattedDate(enquiry.CreatedDate.ToString("d-M-yyyy")) +
                                    ". <br/><br/> Vendors have replied to your enquiry. <br/><br/> Login to see the details.<br/><br/>" +
                                    GetDomainUrl + "/" + _redirectPage.ViewQuotations.Key;
                    Utilities.SendEmail(enquiry.User.Email, "Vendors replied to your enquiry", body);
                }
            }
        }
    }

    #endregion
}