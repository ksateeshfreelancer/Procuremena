﻿using CLB.BL;
using CLB.DTO;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboards_VendorDashboard : BasePage
{
    protected void Page_Load(object sender, EventArgs e)    
    {
        if (Session[SessionVariables.SubscriptionDetails] == null)
        {
            var _sbscriptionManager = new SubscriptionManager();
            var subscriptions = _sbscriptionManager.GetSubscriptions(userID: CurrentUser.UserID);

            //when a new user is created no records are present in subscription by default
            if (subscriptions != null && subscriptions.FirstOrDefault(x=> !x.IsExpired) != null)
            {
                Session[SessionVariables.SubscriptionDetails] = subscriptions.FirstOrDefault(x => !x.IsExpired);
            }
        }

        if (Session[SessionVariables.SubscriptionDetails] != null)
        {
            var days = ((DateTime)GetFormattedDate(((Subscription)Session[SessionVariables.SubscriptionDetails]).EndDate.ToString("dd-MM-yyyy")) - DateTime.Now).Days;
            if (days < 10)
                ltrContent.Text = Utilities.CustomMessage("Your subscription expires in " + days + " days. Please contact Administrator to renew.", CLB.Enums.MessageType.Warning);
            else
            {
                Response.Redirect(_redirectPage.ViewVendorEnquiries.Key, true);
            }
        }
    }
}