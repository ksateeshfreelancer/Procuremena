﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

public partial class SearchResults : BasePage
{
    AjaxService objService = new AjaxService();
    public string BannerAdLeft;
    public string BannerAdRight;

    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateBannerAds();
    }

    private void PopulateBannerAds()
    {
        List<string> retList = new List<string>();
        AjaxService objService = new AjaxService();
        Dictionary<string, List<string>> bannersDetails = objService.GetBannerAdsImagePaths();

        string leftBannerDivs = string.Empty;
        string rightBannerDivs = string.Empty;
        for (int i = 0; i < bannersDetails.Count(); i++)
        {
            var item = bannersDetails.ElementAt(i);
            var itemKey = item.Key;
            var itemValue = item.Value;
            if (i <= 1)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(@"<div id='mybanner" + (i + 1) + "' class='divFrame" + (i + 1) + "'>")
                  .Append(GetBannerDiv(itemValue))
                  .Append("</div>").AppendLine();

                leftBannerDivs += sb.ToString();
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(@"<div id='mybanner" + (i + 1) + "' class='divFrame" + (i + 1) + "'>")
                  .Append(GetBannerDiv(itemValue))
                  .Append("</div>").AppendLine();

                rightBannerDivs += sb.ToString();
            }
        }
        BannerAdLeft = leftBannerDivs;
        BannerAdRight = rightBannerDivs;
    }

    private static string GetBannerDiv(List<string> itemValue)
    {
        StringBuilder sb = new StringBuilder();
        foreach (var eachImage in itemValue)
        {            
            byte[] bytes = File.ReadAllBytes(HttpContext.Current.Server.MapPath(eachImage));
            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);           

            string innerDiv = @"<div class='innerDivClass'>" +
                                   "<a target='_blank' href='AdRouter?Key="+ eachImage.Split('/')[eachImage.Split('/').Length - 1].Split('.')[0] + "'><img width='140px' height='580px' src='data:image/." + eachImage.Split('.')[eachImage.Split('.').Length - 1] + ";base64," + base64String + "'/></a>" + //class='innerDivClass'
                               "</div>";
            sb.Append(innerDiv).AppendLine();
        }
        return sb.ToString();
    }    
}