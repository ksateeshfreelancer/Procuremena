﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.BL;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using System.Data;
using System.IO;
using System.Text;

public partial class SendMultiItemEnquiry : BasePage
{
    #region Global Variables
    public string Products { get; set; }
    public List<AutoComplete> UnitMeasurements { get; set; }

    private EnquiryManager _enquiryManager = new EnquiryManager();
    private ProductCatalogManager _productCatalogManager = new ProductCatalogManager();
    private UnitofMeasurementManager _unitofMeasurementManager = new UnitofMeasurementManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        //If user is alredy registered/logged-in auto-populate user details
        if (CurrentUser != null)
        {
            txtMobile.Text = CurrentUser.Mobile;
            txtEmail.Text = CurrentUser.Email;
            txtName.Text = CurrentUser.UserDetails.FirstName + " " + CurrentUser.UserDetails.LastName;
        }

        if (IsPostBack) return;

        //Bind Products auto complete
        var products = GetCachedProducts();
        var aliasProductNames = from item in products
                                from name in item.AliasNames.Split(',')
                                select ValidAutoCompleteString(name.Trim());
        Products = JsonConvert.SerializeObject((from item in products select ValidAutoCompleteString(item.ProductName.Trim()))
            .Concat(aliasProductNames));

        //Bind Unit of Measurement
        var units = GetCachedUOMs();
        UnitMeasurements = new List<AutoComplete>();
        UnitMeasurements.AddRange(from unit in units select new AutoComplete { id = unit.UnitID.ToString(), label = unit.UnitName });
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string password = CreateRandomPassword(6);
            string[] sear = new string[] { " " };
            var allProducts = GetCachedProducts();
            var userid = GetUserID(txtName.Text, "", txtEmail.Text, txtMobile.Text, password);                            
            if (userid == 0)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid User details. Please try again.", MessageType.Error);
                return;
            }

            var enquirylabel = _enquiryManager.GenerateEnquiryLabel();

            var enquiryData = hdnEnquiryData.Value;

            if (string.IsNullOrEmpty(enquiryData.Trim()))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Please add at least one product/item to send enquiry.", MessageType.Warning);
                return;
            }

            var enquiries = new List<Enquiry>();
            foreach (var data in enquiryData.Split('~'))
            {
                var enquiry = new Enquiry
                {
                    User = new User
                    {
                        UserID = userid
                    },
                    EnquiryLabel = enquirylabel,
                    EnquiryStatus = new EnquiryStatus
                    {
                        StatusID = 1 //indicates initiated
                    },
                    IsGeneralEnquiry = true,
                    IsMultiProduct = (enquiryData.Contains('~')),
                    Quantity = Convert.ToDouble(data.Split('^')[1]),
                    UOM = new UnitofMeasurement
                    {
                        UnitID = Convert.ToInt32(data.Split('^')[2])
                    },
                    //ProductID = productID, productID will be assigned in following code
                    ProductName = data.Split('^')[0],
                    ProductSpecification = data.Split('^')[3].Trim(),
                    DeliveryLocation = txtDeliveryLocation.Text.Trim()
                };
                enquiries.Add(enquiry);
            }

            #region Product validation

            var loopBreak = true;
            foreach (var enquiry in enquiries)
            {
                var prodSearch = (from item in allProducts
                                  where item.ProductName.ToLower().Equals(enquiry.ProductName.ToLower().Trim()) ||
                                  item.AliasNames.Split(',').Any(x => x.ToLower().Trim() == enquiry.ProductName.ToLower().Trim())
                                  select item).ToList();

                if (prodSearch.Count == 0)
                {
                    loopBreak = true;
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Product entered in row " + enquiries.IndexOf(enquiry) + " is not found. Please select a valid product.", MessageType.Error);
                }
                else
                {
                    loopBreak = false;
                    enquiry.ProductID = prodSearch.FirstOrDefault().ProductID;
                }
                if (loopBreak) break;
            }

            #endregion

            if (loopBreak || enquiries.Count == 0)
                return;

            var dbMessage = _enquiryManager.SaveEnquiries(enquiries, out _status);

            //no addl info is available for multi enquiry
            //dbMessage = _enquiryManager.SaveEnquiryAddlInfo(enquiry, out _status);

            lblStatusMessage.InnerHtml = dbMessage == DbMessage.Success ? Utilities.CustomMessage("We thank you for posting your requirement. You will be contacted soon.", MessageType.Success)
                : Utilities.CustomMessage("Failed to submit enquiry. Please try again later.", MessageType.Error);
            if (_status)
            {
                StringBuilder sbBody = new StringBuilder();
                sbBody.Append("<br/><br/><table style='text-align: left;'><thead><tr><th>Sl No</th><th>Product</th><th>Quantity</th><th>Product Specification</th></thead><tbody>");

                foreach (var enquiry in enquiries)
                {
                    sbBody.Append("<tr><td>" + (enquiries.IndexOf(enquiry) + 1) + "</td>");
                    sbBody.Append("<td>" + enquiry.ProductName + "</td>");
                    sbBody.Append("<td>" + enquiry.Quantity + " " + enquiry.UOM.UnitName + "</td>");
                    sbBody.Append("<td>" + enquiry.ProductSpecification + "</td></tr>");
                }
                sbBody.Append("</tbody></table>");
                sbBody.Append("<br/><br/>Mobile: " + txtMobile.Text);
                sbBody.Append("<br/><br/>Name: " + txtName.Text);
                sbBody.Append("<br/><br/>Email: " + txtEmail.Text);
                sbBody.Append("<br/><br/>Delivery Location: " + txtDeliveryLocation.Text);
                Utilities.SendEmail(txtEmail.Text, "Enquiry submitted for review", sbBody.ToString());

                Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"], "Enquiry pending for Approval",
                            "Hi Admin,<br/><br/> A new User has sent an enquiry. Please review and approve.<br/><br/>" +
                            sbBody.ToString() + "<br/><br/>" +
                            GetDomainUrl + "/" + _redirectPage.ViewEnquiries.Key);
                ClearControls(this);

                //If user is alredy registered/logged-in auto-populate user details
                if (CurrentUser != null)
                {
                    txtMobile.Text = CurrentUser.Mobile;
                    txtEmail.Text = CurrentUser.Email;
                    txtName.Text = CurrentUser.UserDetails.FirstName + " " + CurrentUser.UserDetails.LastName;
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #endregion
}