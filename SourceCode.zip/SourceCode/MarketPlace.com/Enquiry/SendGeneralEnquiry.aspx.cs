﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.BL;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using System.Data;
using System.IO;

public partial class SendEnquiry : BasePage
{
    #region Global Variables
    public string Products { get; set; }
    public string UnitMeasurments { get; set; }

    private EnquiryManager _enquiryManager = new EnquiryManager();
    private ProductCatalogManager _productCatalogManager = new ProductCatalogManager();
    private UnitofMeasurementManager _unitofMeasurementManager = new UnitofMeasurementManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        //If user is alredy registered/logged-in auto-populate user details
        if (CurrentUser != null)
        {
            txtMobile.Text = CurrentUser.Mobile;
            txtEmail.Text = CurrentUser.Email;
            txtName.Text = CurrentUser.UserDetails.FirstName + " " + CurrentUser.UserDetails.LastName;
        }

        if (IsPostBack) return;

        //Bind Products auto complete
        var products = GetCachedProducts();
        var aliasProductNames = from item in products
                                from name in item.AliasNames.Split(',')
                                select ValidAutoCompleteString(name);
        Products = JsonConvert.SerializeObject((from item in products select ValidAutoCompleteString(item.ProductName))
            .Concat(aliasProductNames));

        //Bind Unit of Measurement
        Utilities.BindControl(GetCachedUOMs(), "UnitName", "UnitId", ddlUnits);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string password = CreateRandomPassword(6);
            long productID;
            string[] sear = new string[] { " " };
            var allProducts = GetCachedProducts();
            var userid = GetUserID(txtName.Text, "", txtEmail.Text, txtMobile.Text, password);
            if (userid == 0)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid User details. Please try again.", MessageType.Error);
                return;
            }

            //var city = allCities.Where(x => (x.CityName.ToLower().Equals(txtCitySearch.Value.ToLower().Trim())));
            allProducts = (from item in allProducts
                           where item.ProductName.ToLower().Equals(txtProductSearch.Value.ToLower().Trim()) ||
                           item.AliasNames.Split(',').Any(x => x.ToLower().Trim() == txtProductSearch.Value.ToLower().Trim())
                           select item).ToList();

            if (allProducts.Count == 0)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Product not found. Please select a valid product.", MessageType.Error);
                return;
            }
            else
            {
                productID = allProducts.FirstOrDefault().ProductID;
            }

            var enquirylabel = _enquiryManager.GenerateEnquiryLabel();
            var enquiry = new Enquiry
            {
                User = new User
                {
                    UserID = userid
                },
                EnquiryLabel = enquirylabel,
                EnquiryStatus = new EnquiryStatus
                {
                    StatusID = 1 //indicates initiated
                },
                IsGeneralEnquiry = true,
                IsMultiProduct = false,
                Quantity = Convert.ToDouble(txtQuantity.Text.Trim()),
                UOM = new UnitofMeasurement
                {
                    UnitID = Convert.ToInt32(ddlUnits.SelectedValue.ToString())
                },
                ProductID = productID,
                ProductName = txtProductSearch.Value.ToString(),
                ProductSpecification = txtProductSpecification.Text.Trim(),
                DeliveryLocation = txtDeliveryLocation.Text.Trim()                
            };

            var dbMessage = _enquiryManager.SaveEnquiry(enquiry, out _identity, out _status);

            if (dbMessage == DbMessage.Success)
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("We thank you for posting your requirement. You will be contacted soon.", MessageType.Success);
            else
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to submit enquiry. Please try again later.", MessageType.Error);

            if (_status)
            {
                Utilities.SendEmail(txtEmail.Text, "Enquiry submitted for review",
                    "<br/><br/>Product: " + txtProductSearch.Value +
                    "<br/><br/>Quantity: " + txtQuantity.Text + " " + ddlUnits.SelectedItem.Text +
                    "<br/><br/>Product Specification: " + txtProductSpecification.Text +
                    "<br/><br/>Mobile: " + txtMobile.Text +
                    "<br/><br/>Name: " + txtName.Text +
                    "<br/><br/>Email: " + txtEmail.Text +
                    "<br/><br/>Delivery Location: " + txtDeliveryLocation.Text);

                Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"], "Enquiry pending for Approval",
                            "Hi Admin,<br/><br/> A new User has sent an enquiry. Please review and approve.<br/><br/>" +
                            "<br/><br/>Product: " + txtProductSearch.Value +
                            "<br/><br/>Quantity: " + txtQuantity.Text + " " + ddlUnits.SelectedItem.Text +
                            "<br/><br/>Product Specification: " + txtProductSpecification.Text +
                            "<br/><br/>Mobile: " + txtMobile.Text +
                            "<br/><br/>Name: " + txtName.Text +
                            "<br/><br/>Email: " + txtEmail.Text +
                            "<br/><br/>Delivery Location: " + txtDeliveryLocation.Text + "<br/><br/>" +
                            GetDomainUrl + "/" + _redirectPage.ViewEnquiries.Key);
                ClearControls(this);

                //If user is alredy registered/logged-in auto-populate user details
                if (CurrentUser != null)
                {
                    txtMobile.Text = CurrentUser.Mobile;
                    txtEmail.Text = CurrentUser.Email;
                    txtName.Text = CurrentUser.UserDetails.FirstName + " " + CurrentUser.UserDetails.LastName;
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #endregion

    #region Private Methods

    #endregion
}