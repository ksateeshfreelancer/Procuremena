﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewQuotationHistory : BasePage
{
    #region Global Variables

    private QuotationManager _quotationManager = new QuotationManager();
    private EnquiryLogManager _enquiryLogManager = new EnquiryLogManager();
    private EnquiryManager _enquiryManager = new EnquiryManager();

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindQuotationHistory();
    }

    #endregion

    #region Grid Events
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Quotation>(gridview, ((LinkButton)sender).CommandArgument);
    }

    #endregion

    #region Private Methods
    private void BindQuotationHistory()
    {
        long quotationID;
        if (Request.QueryString["ID"] != null && long.TryParse(Utilities.Decrypt(Request.QueryString["ID"]), out quotationID))
        {
            //continue;
        }
        else
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid request.", MessageType.Error);
            return;
        }

        var enquiryLog = _enquiryLogManager.GetEnquiryLog(quotationID: quotationID).OrderByDescending(x => x.CreatedDate).ToList();
        var enquiryDetails = _enquiryManager.GetEnquiries(enquiryID: enquiryLog.FirstOrDefault().EnquiryID).FirstOrDefault();

        //ENQUIRY DETAILS ARE FETCHED FROM DB. DONT Bind the details here
        enquiryLog.ForEach(x => x.Enquiry = enquiryDetails);

        gridview.DataSource = enquiryLog;
        gridview.DataBind();
    }

    #endregion
}