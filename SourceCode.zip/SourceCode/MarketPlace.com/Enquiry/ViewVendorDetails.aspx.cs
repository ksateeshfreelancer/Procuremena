﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CustomerProfile : BasePage
{
    #region Declarations

    private UserManager _userManager = new UserManager();
    private BusinessBranchDetailsManager _businessBranchDetailsManager = new BusinessBranchDetailsManager();
    private BusinessDetailsManager _businessDetailsManager = new BusinessDetailsManager();

    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindUserDetails();
    }

    #endregion

    #region ControlEvents
    protected void dlVendorBusinessDetails_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        try
        {
            DataListItem item = e.Item;
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var userID = int.Parse(((HiddenField)e.Item.FindControl("hdnUserID")).Value);
                var user = GetCachedUsers(userID: userID).FirstOrDefault();
                ((Label)e.Item.FindControl("lblName")).Text = user.UserDetails.FirstName + " " + user.UserDetails.LastName;
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #endregion

    #region PrivateMethods
    private void BindUserDetails()
    {
        int userID;
        if (Request.QueryString["ID"] == null || !int.TryParse(Utilities.Decrypt(Request.QueryString["ID"]), out userID))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid enquiry.", MessageType.Error);
            return;
        }

        var businessDetails = _businessDetailsManager.GetBusinessDetails(userID: userID);
        dlVendorBusinessDetails.DataSource = businessDetails;
        dlVendorBusinessDetails.DataBind();

        var branches = _businessBranchDetailsManager.GetBusinessBranches(userID);
        gridview.Visible = (branches != null && branches.Count > 0);
        gridview.DataSource = branches;
        gridview.DataBind();
    }

    #endregion
}