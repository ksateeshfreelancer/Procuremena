﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.BL;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using System.Data;
using System.IO;
using System.Configuration;

public partial class SendProductEnquiry : BasePage
{
    #region Global Variables
    public string Products { get; set; }
    public string UnitMeasurments { get; set; }
        
    private EnquiryManager _enquiryManager = new EnquiryManager();
    private ProductCatalogManager _productCatalogManager = new ProductCatalogManager();
    private VendorInventoryManager _vendorInventoryManager = new VendorInventoryManager();
    private UnitofMeasurementManager _unitofMeasurementManager = new UnitofMeasurementManager();
    
    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //If user is alredy registered/logged-in auto-populate user details
            if (CurrentUser != null)
            {
                ViewState["UserID"] = CurrentUser.UserID;
                txtMobile.Text = CurrentUser.Mobile;
                txtEmail.Text = CurrentUser.Email;
                txtName.Text = CurrentUser.UserDetails.FirstName + " " + CurrentUser.UserDetails.LastName;
            }

            if (IsPostBack) return;
            btnClose.Visible = false;
            if (CurrentUser == null)
            {
                std_sendenquiry_step1.Visible = true;
                std_sendenquiry_step2.Visible = false;
            }
            else
            {   
                lblStep2Name.InnerText = txtName.Text;
                lblStep2Mobile.InnerText = txtMobile.Text;
                lblStep2Email.InnerText = txtEmail.Text;
                std_sendenquiry_step1.Visible = false;
                std_sendenquiry_step2.Visible = true;
            }

            //Bind Products auto complete
            var products = GetCachedProducts();
            var aliasProductNames = from item in products
                                    from name in item.AliasNames.Split(',')
                                    select ValidAutoCompleteString(name);
            Products = JsonConvert.SerializeObject((from item in products select ValidAutoCompleteString(item.ProductName))
                .Concat(aliasProductNames));

            //Bind Unit of Measurement
            Utilities.BindControl(GetCachedUOMs(), "UnitName", "UnitId", ddlUnits);
            
            LoadProduct();
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void btnSubmitStep1_Click(object sender, EventArgs e)
    {
        try
        {
            string password = CreateRandomPassword(6);
            string[] sear = new string[] { " " };            
            
            var userid = GetUserID(txtName.Text, "", txtEmail.Text, txtMobile.Text, password);
            if (userid == 0)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid User details. Please try again.", MessageType.Error);
                return;
            }
            
            ViewState["UserID"] = userid;

            lblStep2Name.InnerText = txtName.Text;
            lblStep2Mobile.InnerText = txtMobile.Text;
            lblStep2Email.InnerText = txtEmail.Text;

            std_sendenquiry_step1.Visible = false;
            std_sendenquiry_step2.Visible = true;
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void btnSubmitStep2_Click(object sender, EventArgs e)
    {
        try
        {           
            var productDetails = (VendorInventory)ViewState["Product"];
            var enquirylabel = _enquiryManager.GenerateEnquiryLabel();            
            var enquiry = new Enquiry
            {
                // EnquiryID = int.Parse(hdnID.Value),
                User = new User
                {
                    UserID = (int)ViewState["UserID"]
                },
                EnquiryLabel = enquirylabel,
                EnquiryStatus = new EnquiryStatus
                {
                    StatusID = 1 //indicates initiated
                },
                IsGeneralEnquiry = false,
                IsMultiProduct = false,
                Quantity = Convert.ToDouble(txtQuantity.Text.Trim()),
                UOM = new UnitofMeasurement
                {
                    UnitID = Convert.ToInt32(ddlUnits.SelectedValue.ToString())
                },
                ProductID = productDetails.Product.ProductID,
                ProductName = productDetails.Product.ProductName,
                ProductSpecification = TrimText(txtProductSpecification.Text.Trim(), 1000),
                DeliveryLocation = txtDeliveryLocation.Text.Trim()
            };

            var dbMessage = _enquiryManager.SaveEnquiry(enquiry, out _identity, out _status);

            if (dbMessage == DbMessage.Success)
            {
                Image1.Visible = false;
                btnClose.Visible = true;
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("We thank you for posting your requirement. You will be contacted soon.", MessageType.Success);                
            }
            else
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to submit enquiry. Please try again later.", MessageType.Error);
            }

            if (_status)
            {
                Utilities.SendEmail(txtEmail.Text, "Enquiry submitted for review",
                       "<br/><br/>Product: " + productDetails.Product.ProductName +
                       "<br/><br/>Quantity: " + txtQuantity.Text + " " + ddlUnits.SelectedItem.Text +
                       "<br/><br/>Product Specification: " + txtProductSpecification.Text +
                       "<br/><br/>Mobile: " + txtMobile.Text +
                       "<br/><br/>Name: " + txtName.Text +
                       "<br/><br/>Email: " + txtEmail.Text +
                       "<br/><br/>Delivery Location: " + txtDeliveryLocation.Text);

                Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"], "Enquiry pending for Approval",
                            "Hi Admin,<br/><br/> A new User has sent an enquiry. Please review and approve.<br/><br/>" +
                            "<br/><br/>Product: " + productDetails.Product.ProductName +
                            "<br/><br/>Quantity: " + txtQuantity.Text + " " + ddlUnits.SelectedItem.Text +
                            "<br/><br/>Product Specification: " + txtProductSpecification.Text +
                            "<br/><br/>Mobile: " + txtMobile.Text +
                            "<br/><br/>Name: " + txtName.Text +
                            "<br/><br/>Email: " + txtEmail.Text +
                            "<br/><br/>Delivery Location: " + txtDeliveryLocation.Text + "<br/><br/>" +
                            GetDomainUrl + "/" + _redirectPage.ViewEnquiries.Key);
                ClearControls(this);

                std_sendenquiry_step1.Visible = false;
                std_sendenquiry_step2.Visible = false;
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }    
    #endregion

    #region Private Methods
    private void LoadProduct()
    {
        long inventoryID;
        if (Request.QueryString["ID"] != null && long.TryParse(Request.QueryString["ID"], out inventoryID))
        {
            //continue;
        }
        else
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid product.", MessageType.Error);
            return;
        }

        var product = _vendorInventoryManager.GetVendorInventory(inventoryID: inventoryID).FirstOrDefault();

        var hasImage = false;
        Image1.ImageUrl = LoadImage(product.InventoryID, out hasImage);

        lblProductName.InnerText = "Get Quote for " + product.Product.ProductName;
        ViewState["Product"] = product;        
    }

    #endregion
}