﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;
using Newtonsoft.Json;

public partial class ViewCustomerEnquiries : BasePage
{
    #region Global Variables

    private QuotationManager _quotationManager = new QuotationManager();
    private EnquiryManager _enquiryManager = new EnquiryManager();
    public string UserNames { get; set; }

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        BindEnquiries();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtEnquiryLabelSearch.Value = txtFromDateSearch.Value = txtToDateSearch.Value = "";
        BindEnquiries();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        BindEnquiries();
    }

    #region Grid Events
    protected void gridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "CloseEnquiry")
            {
                GridViewRow item = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var enquiryID = long.Parse(dataKeyArray.Values["EnquiryID"].ToString());
                var isMultiProduct = (bool)dataKeyArray.Values["IsMultiProduct"];
                var enquiryLabel = dataKeyArray.Values["EnquiryLabel"].ToString();

                var result = _quotationManager.UpdateField(Tables.Enquiry, "StatusID", "12", "EnquiryLabel", enquiryLabel);
                if (isMultiProduct)
                {
                    var enquiries = (List<Enquiry>)ViewState["UnalteredList"];
                    var quotations = (from enquiry in enquiries
                                      where enquiry.EnquiryLabel == enquiryLabel
                                      select new Quotation
                                      {
                                          Enquiry = new Enquiry
                                          {
                                              EnquiryID = enquiry.EnquiryID
                                          },
                                          EnquiryStatus = new EnquiryStatus
                                          {
                                              StatusID = 12
                                          }
                                      }).ToList();
                    var result1 = _enquiryManager.UpdateQuotationsStatus(quotations, false);
                }
                else
                {
                    var result1 = _quotationManager.UpdateField(Tables.Quotation, "StatusID", "12", "EnquiryID", enquiryID.ToString());
                }

                //don't check result1 status as enquiries with status 'initiated' will not have entries in quotation table
                if (result == DbMessage.Success)
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Enquiry closed successfully.", MessageType.Success);
                    BindEnquiries();
                }
                else
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update Enquiry " + enquiryLabel + ". Please try agian later", MessageType.Error);
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                var quotations = (List<Quotation>)ViewState["Quotations"];
                var enquiryID = long.Parse(dataKeyArray.Values["EnquiryID"].ToString());
                var enquiryLabel = dataKeyArray.Values["EnquiryLabel"].ToString();
                var isMultiProduct = (bool)dataKeyArray.Values["IsMultiProduct"];
                var enquiryStatus = (EnquiryStatus)(dataKeyArray.Values["EnquiryStatus"]);

                var lbtnCloseEnquiry = (LinkButton)e.Row.FindControl("lbtnCloseEnquiry");
                //indicates enquiry is already closed. don't show close button 
                if (enquiryStatus != null && enquiryStatus.StatusID > 10)
                {
                    lbtnCloseEnquiry.Attributes.Add("onclick", "return false;");
                    lbtnCloseEnquiry.CssClass = "";
                    lbtnCloseEnquiry.Attributes.Add("class", "std_noul");
                    lbtnCloseEnquiry.Attributes.Add("cursor", "default");
                    lbtnCloseEnquiry.Text = "Closed";
                }
                else
                {
                    lbtnCloseEnquiry.Attributes.Add("onclick", "if(confirm('Are you sure you want to close Enquiry ?')) jsFns.ShowProcessing(); else return false;");
                }

                #region Enquiry Status logic

                var lblEnquiryStatus = (Label)e.Row.FindControl("lblEnquiryStatus");
                if (enquiryStatus.StatusID > 8)
                {
                    lblEnquiryStatus.Text = "Closed";
                }
                else if (enquiryStatus.StatusID == 5)
                {
                    lblEnquiryStatus.Text = "Shown Interest";
                }
                else if (enquiryStatus.StatusID == 3)
                {
                    lblEnquiryStatus.Text = "Vendor Replied";
                }
                else
                {
                    lblEnquiryStatus.Text = "Active";
                }
                lblEnquiryStatus.Visible = !string.IsNullOrEmpty(enquiryLabel);

                #endregion

                #region Quotations Count

                var lnkQuotations = (HtmlAnchor)e.Row.FindControl("lnkQuotations");
                if (quotations != null)
                    lnkQuotations.InnerText = quotations.Count(x => x.Enquiry.EnquiryID == enquiryID && x.EnquiryStatus.StatusID > 2).ToString();

                if (lnkQuotations.InnerText == "0")
                {
                    lnkQuotations.Attributes.Add("onclick", "return false;");
                    lnkQuotations.Attributes.Add("class", "std_noul");
                    lnkQuotations.Attributes.Add("cursor", "default");
                }

                #endregion

                #region Multi Item Enquiries Logic

                if (isMultiProduct && enquiryStatus.StatusID == 0)
                {
                    lnkQuotations.Visible = false;
                    ((Label)e.Row.FindControl("lblCreatedDate")).Visible = false;
                    lbtnCloseEnquiry.Visible = false;
                }

                #endregion
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Enquiry>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void ibtnExport_Click(object sender, ImageClickEventArgs e)
    {
        var control = (ImageButton)((Control)sender);
        Export(ViewState["FilterList"], "Enquiries",
               (ExportType)Enum.Parse(typeof(ExportType), control.CommandName),
               new[] { "EnquiryLabel", "EnquiryStatus.StatusName", "IsGeneralEnquiry", "CreatedDate", "ProductName", "Quantity", "UOM.UnitName", "DeliveryLocation", "ModifiedDate" });
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindEnquiries()
    {
        #region Quotations

        var quotations = _quotationManager.GetQuotations(customerID: CurrentUser.UserID);

        var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor });
        //User details are not fetched from db. Bind the details here
        quotations.ForEach(x => x.Vendor = users.FirstOrDefault(y => y.UserID == x.VendorID));
        ViewState["Quotations"] = quotations;

        #endregion

        var enquiries = new List<Enquiry>();

        //check if atleast one filter is set
        if ((!string.IsNullOrEmpty(txtFromDateSearch.Value) && !string.IsNullOrEmpty(txtToDateSearch.Value)) ||
            !string.IsNullOrEmpty(txtEnquiryLabelSearch.Value))
        {
            enquiries = _enquiryManager.GetEnquiries(userID: CurrentUser.UserID, enquiryLabel: (!string.IsNullOrEmpty(txtEnquiryLabelSearch.Value.Trim()) ? txtEnquiryLabelSearch.Value : null),
                fromDate: GetSqlDate(txtFromDateSearch.Value), toDate: GetSqlDate(txtToDateSearch.Value));
        }
        else
        {
            enquiries = _enquiryManager.GetEnquiries(userID: CurrentUser.UserID, fromDate: GetSqlDate(DateTime.Now.AddMonths(-2).ToString("dd-MM-yyyy")),
                    toDate: GetSqlDate(DateTime.Now.AddDays(1).ToString("dd-MM-yyyy")));
        }

        //enquiries = enquiries.OrderByDescending(x=> new {x. })

        ViewState["UnalteredList"] = enquiries.ToList();

        var tmpEnquiries = CloneEntity.Clone<List<Enquiry>>(enquiries);

        //group enquiries for multi item view
        foreach (var items in tmpEnquiries.GroupBy(x => x.EnquiryLabel))
        {
            //loop only those enquiries that have multi items
            if (items.Count() > 1)
            {
                foreach (var enquiry in items.Skip(1))
                {
                    enquiry.EnquiryLabel = "";
                    enquiry.EnquiryStatus = new EnquiryStatus();
                }
            }
        }

        ViewState["FilterList"] = ViewState["List"] = tmpEnquiries.ToList();

        gridview.DataSource = tmpEnquiries.OrderByDescending(x => x.CreatedDate).ToList();
        gridview.DataBind();
    }

    #endregion
}