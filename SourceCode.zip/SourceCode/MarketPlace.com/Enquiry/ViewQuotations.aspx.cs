﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;
using Newtonsoft.Json;

public partial class ViewQuotations : BasePage
{
    #region Global Variables

    private QuotationManager _quotationManager = new QuotationManager();
    private EnquiryLogManager _enquiryLogManager = new EnquiryLogManager();
    private EnquiryManager _enquiryManager = new EnquiryManager();

    #endregion

    #region Page Methods

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindQuotations();
    }

    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        var quotations = (List<Quotation>)ViewState["List"];
        var tmpQuotations = new List<Quotation>();

        if (ddlProduct.SelectedIndex > 0)
            quotations = quotations.Where(x => x.Enquiry.ProductID == long.Parse(ddlProduct.SelectedValue)).ToList();

        //group enquiries for multi item view
        foreach (var items in quotations.GroupBy(x => new { x.Enquiry.EnquiryLabel, x.VendorID }))
        {
            //add only if vendor has replied to query
            if (items.FirstOrDefault().Enquiry.EnquiryStatus.StatusID > 2 && items.FirstOrDefault().TotalCost > 0)
            {
                var quotation = CloneEntity.Clone(items.FirstOrDefault());
                //quotation.UnitCost = 0;
                tmpQuotations.Add(quotation);
            }
        }
        gridview.DataSource = tmpQuotations;
        gridview.DataBind();
    }

    #endregion

    #region Grid Events

    protected void gridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "ShowInterest")
            {
                GridViewRow item = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                var dataKeyArray = gridview.DataKeys[item.RowIndex];
                var enquiry = (Enquiry)dataKeyArray.Values["Enquiry"];
                var vendorID = long.Parse(dataKeyArray.Values["VendorID"].ToString());
                var quotationID = long.Parse(dataKeyArray.Values["QuotationID"].ToString());

                //5	indicates UserInterested                
                var result = _quotationManager.UpdateField(Tables.Enquiry, "StatusID", "5", "EnquiryLabel", enquiry.EnquiryLabel);
                if (enquiry.IsMultiProduct)
                {
                    var quotations = (List<Quotation>)ViewState["UnalteredList"];
                    var tmpquotations = (from quotation in quotations
                                         where quotation.Enquiry.EnquiryLabel == enquiry.EnquiryLabel &&
                                            quotation.VendorID == vendorID
                                         select new Quotation
                                         {
                                             QuotationID = quotation.QuotationID,
                                             EnquiryStatus = new EnquiryStatus
                                             {
                                                 StatusID = 5
                                             }
                                         }).ToList();
                    var result1 = _enquiryManager.UpdateQuotationsStatus(tmpquotations, true);
                }
                else
                {
                    var result1 = _quotationManager.UpdateField(Tables.Quotation, "StatusID", "5", "QuotationID", quotationID.ToString());
                }


                if (result == DbMessage.Success)
                {
                    var vendor = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor }).FirstOrDefault(x => x.UserID == vendorID);
                    string body = "Hi " + vendor.UserDetails.FirstName + " " + vendor.UserDetails.LastName +
                        ",  <br/><br/> A Customer has shown interest for your quotation. EnquiryID: " + enquiry.EnquiryLabel;
                    Utilities.SendEmail(vendor.Email, "Enquiry: " + enquiry.EnquiryLabel + " - User has shown interest", body);
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Thanks for showing interest. Vendor is communicated and will get back shortly.", MessageType.Success);
                    BindQuotations();
                }
                else
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update Enquiry " + enquiry.EnquiryLabel + ". Please try agian later", MessageType.Error);
                }
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                var quotationID = long.Parse(dataKeyArray.Values["QuotationID"].ToString());
                var vendorID = int.Parse(dataKeyArray.Values["VendorID"].ToString());
                var enquiry = (Enquiry)dataKeyArray.Values["Enquiry"];
                var enquiryStatus = (EnquiryStatus)(dataKeyArray.Values["EnquiryStatus"]);

                #region Show Interest button logic

                var lbtnShowInterest = (LinkButton)e.Row.FindControl("lbtnShowInterest");
                //indicates user  has already shown interest in vendor. disable button
                if (enquiryStatus != null)
                {
                    if (enquiryStatus.StatusID == 5)
                    {
                        lbtnShowInterest.Text = "Shown Interest";
                        lbtnShowInterest.Enabled = false;
                        lbtnShowInterest.CssClass = "std_noul";
                    }
                    //indicates enquiry is closed
                    else if (enquiryStatus.StatusID > 10)
                    {
                        lbtnShowInterest.Visible = false;
                    }
                }

                #endregion

                #region Total Cost, Unit Cost & Discount Logic
                
                var lnkTotalCost = (HtmlAnchor)e.Row.FindControl("lnkTotalCost");
                var lblUnitCost = (Label)e.Row.FindControl("lblUnitCost");
                var lblDiscount = (Label)e.Row.FindControl("lblDiscount");

                if (enquiry.IsMultiProduct)
                {
                    var quotations = (List<Quotation>)ViewState["UnalteredList"];
                    if (ddlProduct.SelectedIndex > 0)
                    {
                        var quote = quotations.FirstOrDefault(x => x.VendorID == vendorID &&
                        x.Enquiry.EnquiryStatus.StatusID > 2 && x.Enquiry.ProductID == long.Parse(ddlProduct.SelectedValue));

                        lnkTotalCost.InnerText = FormatPrice(quote.TotalCost);
                        lblUnitCost.Text = FormatPrice(quote.UnitCost);
                        lblDiscount.Text = FormatPrice(quote.Discount);
                    }
                    else
                    {
                        var quote = quotations.Where(x => x.VendorID == vendorID && x.Enquiry.EnquiryStatus.StatusID > 2);
                        lnkTotalCost.InnerText = FormatPrice(quote.Sum(x => x.TotalCost));
                        lblUnitCost.Text = FormatPrice(quote.Sum(x => x.UnitCost));
                        lblDiscount.Text = FormatPrice(quote.Sum(x => x.Discount));
                    }
                    lnkTotalCost.HRef = "#";
                }
                else
                {
                    lnkTotalCost.HRef = ((_redirectPage.ViewQuotationHistory.Key + "?T=P&ID=")) + Utilities.Encrypt(quotationID);
                }

                #endregion

                var dataListProducts = (DataList)e.Row.FindControl("dataListProducts");
                /*var quotations = (List<Quotation>)ViewState["UnalteredList"];
                dataListProducts.DataSource = quotations.Where(x => x.VendorID == vendorID && x.Enquiry.EnquiryStatus.StatusID > 2).ToList();
                dataListProducts.DataBind();*/

                //Hide DL as per client requirement.
                dataListProducts.Visible = false;
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Quotation>(gridview, ((LinkButton)sender).CommandArgument);
    }

    #endregion

    #region Private Methods

    private void BindQuotations()
    {
        string enquiryLabel = "";
        if (!string.IsNullOrEmpty(Request.QueryString["ID"]))
            enquiryLabel = Request.QueryString["ID"].ToString();
        else
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid request.", CLB.Enums.MessageType.Info);
            return;
        }

        var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor });

        var quotations = _quotationManager.GetQuotations(enquiryLabel: enquiryLabel);
        //check if user is authorized to view this enquiry -- only vendor has access to this screen       
        if (quotations.Count > 0 && quotations.FirstOrDefault().CustomerID != CurrentUser.UserID)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("You are not authorized to view this enquiry.", CLB.Enums.MessageType.Info);
            return;
        }

        if (quotations.Count == 0)
        {
            gridview.DataSource = null;
            gridview.DataBind();
            return;
        }

        //User details are not fetched from db. Bind the details here
        quotations.ForEach(x => x.Vendor = users.FirstOrDefault(y => y.UserID == x.VendorID));

        ViewState["UnalteredList"] = quotations.ToList();

        var tmpQuotations = new List<Quotation>();

        //group enquiries for multi item view
        foreach (var items in quotations.GroupBy(x => new { x.Enquiry.EnquiryLabel, x.VendorID }))
        {
            //add only if vendor has replied to query
            if (items.FirstOrDefault().Enquiry.EnquiryStatus.StatusID > 2 && items.FirstOrDefault().TotalCost > 0)
            {
                var quotation = CloneEntity.Clone(items.FirstOrDefault());
                //quotation.UnitCost = 0;
                tmpQuotations.Add(quotation);
            }
        }

        ViewState["FilterList"] = ViewState["List"] = quotations.ToList();
        gridview.DataSource = tmpQuotations;
        gridview.DataBind();
        divMultiProduct.Visible = quotations.Select(x => x.Enquiry.EnquiryID).Distinct().Count() > 1;

        var products = GetCachedProducts();
        ddlProduct.DataSource = (from product in products
                                 where quotations.Any(x => x.Enquiry.ProductID == product.ProductID)
                                 select product).ToList();
        ddlProduct.DataTextField = "ProductName";
        ddlProduct.DataValueField = "ProductID";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("All", ""));
    }

    #endregion


}