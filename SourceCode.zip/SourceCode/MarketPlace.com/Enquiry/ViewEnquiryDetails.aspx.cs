﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewEnquiryDetails : BasePage
{
    #region Declarations

    private EnquiryManager _enquiryManager = new EnquiryManager();
    private QuotationManager _quotationManager = new QuotationManager();

    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        LoadEnquiryDetails();
    }

    #endregion

    #region PrivateMethods
    private void LoadEnquiryDetails()
    {
        string enquiryLabel = "";
        if (!string.IsNullOrEmpty(Request.QueryString["ID"]))
            enquiryLabel = Request.QueryString["ID"].ToString();
        else
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid request.", CLB.Enums.MessageType.Info);
            return;
        }

        var enquiry = _enquiryManager.GetEnquiries(enquiryLabel: enquiryLabel);

        //check if user is authorized to view this enquiry
        if (CurrentUser.Role.RoleID == (int)UserRole.Customer)
        {
            if (enquiry.FirstOrDefault().User.UserID != CurrentUser.UserID)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("You are not authorized to view this enquiry.", CLB.Enums.MessageType.Info);
                return;
            }
        }
        if (CurrentUser.Role.RoleID == (int)UserRole.Vendor)
        {
            var quotations = _quotationManager.GetQuotations(enquiryLabel: enquiryLabel, vendorID: CurrentUser.UserID);
            if (quotations == null || quotations.Count == 0)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("You are not authorized to view this enquiry.", CLB.Enums.MessageType.Info);
                return;
            }
        }

        if (enquiry.FirstOrDefault().IsMultiProduct)
        {
            foreach (var item in enquiry.Skip(1))
            {
                item.EnquiryLabel = "";
                item.EnquiryStatus = new EnquiryStatus();
            }
            dlEnquiryDetails.Visible = false;
            gridview.DataSource = enquiry;
            gridview.DataBind();
        }
        else
        {
            gridview.Visible = false;
            dlEnquiryDetails.DataSource = enquiry;
            dlEnquiryDetails.DataBind();
        }
    }

    #endregion
}