﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class SendEmail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {   
        SendMail("satyasai.kc@gmail.com", "Test mail", "Hi this is test mail");
    }
    public bool SendMail(string pTo, string pSubject, string pBody, string pCc = null, string pBCc = null, bool isHtmlBody = true)
    {
        try
        {
            string text = System.IO.File.ReadAllText(Server.MapPath("~/App_Data/email.html"));
            //when email is to be sent form tekkispace email server
            var smtpHost = "mail.tekkispace.com";
            var smtpPort = "25";
            var emailId = "support@tekkispace.com";
            var password = "xGbo072#";

            var smtpClient = new SmtpClient();
            var message = new MailMessage();
            var fromAddress = new MailAddress(emailId, "Tekkispace Support");
            var toAddress = new MailAddress(pTo, "Satya Sai");
            message.From = fromAddress;
            message.To.Add(toAddress);
            message.Subject = pSubject;
            message.Body = text.Replace("##SUBJECT", pSubject).Replace("##CONTENT", pBody).Replace("##SITELINK", "http://" + smtpHost.Replace("mail.", ""));
            message.IsBodyHtml = isHtmlBody;

            if (!string.IsNullOrEmpty(pBCc))
            {
                foreach (
                    var bcc in
                        pBCc.Split(',').Where(x => !string.IsNullOrEmpty(x)).Select(x => new MailAddress(x))
                    )
                    message.Bcc.Add(bcc);                
            }
            
            if (!string.IsNullOrEmpty(pCc))
            {
                var ccAddress = new MailAddress(pCc);
                message.CC.Add(ccAddress);
            }

            smtpClient.Host = smtpHost;
            smtpClient.Port = Convert.ToInt32(smtpPort);
            smtpClient.Credentials = new NetworkCredential(emailId, password);
            //smtpClient.EnableSsl = true;
            smtpClient.Send(message);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}