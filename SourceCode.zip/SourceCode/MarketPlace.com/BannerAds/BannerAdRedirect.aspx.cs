﻿using CLB.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BannerAdRedirect : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(Request.QueryString["Key"]) || Request.QueryString["Key"].Split('-').Length != 3)
            {
                Response.Redirect(_redirectPage.Home.Key, false);
                return;
            }
            var key = Request.QueryString["Key"].Split('-');
            var productName = GetCachedProducts().FirstOrDefault(x => x.ProductID == long.Parse(key[1])).ProductName;

            var param = new SearchParams
            {
                ProductName = productName,
                VendorInventoryID = long.Parse(key[2])
            };

            Session[CLB.Util.SessionVariables.SearchParams] = param;
            Response.Redirect(_redirectPage.SearchResults.Key + "?P=" + param.ProductName, false);
        }
        catch (Exception ex)
        {
            TrackException(ex);
            Response.Redirect(_redirectPage.Home.Key, false);
        }
    }
}
