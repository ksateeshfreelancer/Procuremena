﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.BL;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using System.Data;
using System.IO;

public partial class ManageBannerAd : BasePage
{
    #region Global Variables

    BannerAdManager _bannerAdManager = new BannerAdManager();
    DirectoryInfo dir;
    VendorInventoryManager _inventoryManager = new VendorInventoryManager();
    public string UserNames { get; set; }
    private UserManager _userManager = new UserManager();
    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindUsers();
        LoadControls();

        int id;
        if (Request.QueryString["ID"] != null && int.TryParse(Utilities.Decrypt(Request.QueryString["ID"]), out id))
            LoadBannerAdDetails(id);
        else
            hdnID.Value = "0";
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            var bannerAds = new List<BannerAd>();
            var bannerAd = new BannerAd
            {
                BannerAdID = int.Parse(hdnID.Value),
                User = new User
                {
                    UserID = Convert.ToInt32(ViewState["UserId"].ToString())
                },
                Inventory = new VendorInventory
                {
                    InventoryID = Convert.ToInt32(ddlInventory.SelectedValue.ToString())
                },
                ExpiryDate = GetFormattedDate(txtExpiryDate.Value),
                BannerPosition = (BannerPosition)int.Parse(ddlBannerPosition.SelectedValue.ToString()),
                Status = (Status)int.Parse(rblStatus.SelectedValue.ToString())

            };

            bannerAds.Add(bannerAd);
            if (int.Parse(hdnID.Value) == 0)
            {
                if (ViewState["Upload"] != null)
                {
                    lblStatusMessage.InnerHtml = _bannerAdManager.SaveBannerAds(bannerAds, out _status);
                }
                else
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("Please upload file", MessageType.Error);
                }
            }
            else
            {
                lblStatusMessage.InnerHtml = _bannerAdManager.UpdateBannerAds(bannerAds, out _status);
            }
            if (_status)
            {
                CreatedDate.Text = ModifiedDate.Text = "";
                ClearControls(this);
                rblStatus.Items[0].Selected = true;
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void btnSearchInventory_Click(object sender, EventArgs e)
    {
        string[] sear = new string[] { " " };
        var users = GetCachedUsers();
        users = (from user in users
                 let search = txtNameSearch.Value.Trim()
                 where (search.Split(sear, StringSplitOptions.None).Any(y => user.UserDetails.FirstName.Contains(y)) ||
                        search.Split(sear, StringSplitOptions.None).Any(y => user.UserDetails.LastName.Contains(y)) ||
                     user.Email.Contains(search) || user.Mobile.Contains(search) || user.Role.RoleName.Contains(search))
                 select user).ToList();

        if (users == null || users.Count == 0)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Please select a valid user from the list", MessageType.Error);
            return;
        }

        var userId = users.FirstOrDefault().UserID;
        BindInventories(userId);
    }
    protected void Upload_File(object sender, EventArgs e)
    {
        try
        {
            if ((fileUpload.PostedFile != null) && (fileUpload.PostedFile.ContentLength > 0))
            {
                var user = (User)Session[SessionVariables.CurrentUser];
                //Value is referred instead of Text as text might change in future
                string dirUrl = "Uploads/BannerAds/Position-" + ddlBannerPosition.SelectedItem.Value.Trim() + "/";

                string dirPath = Server.MapPath(dirUrl);
                string filename = fileUpload.FileName;

                var productID = ((List<VendorInventory>)ViewState["VendorInventory"]).FirstOrDefault(x => x.InventoryID == long.Parse(ddlInventory.SelectedValue)).Product.ProductID;

                filename = ViewState["UserId"].ToString() + "-" + productID + "-" + ddlInventory.SelectedValue + "." + fileUpload.FileName.Split('.')[fileUpload.FileName.Split('.').Length - 1];
                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                    fileUpload.PostedFile.SaveAs(dirPath + "\\" + filename);
                    ViewState["Upload"] = 1;
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("File Successfully Uploaded", MessageType.Success);
                }
                else
                {
                    FileInfo f1 = new FileInfo(dirPath + ViewState["UserId"].ToString() + ".jpg");
                    FileInfo f2 = new FileInfo(dirPath + ViewState["UserId"].ToString() + ".jpeg");
                    FileInfo f3 = new FileInfo(dirPath + ViewState["UserId"].ToString() + ".gif");
                    FileInfo f4 = new FileInfo(dirPath + ViewState["UserId"].ToString() + ".bmp");
                    FileInfo f5 = new FileInfo(dirPath + ViewState["UserId"].ToString() + ".png");
                    if (f1.Exists) f1.Delete();
                    if (f2.Exists) f2.Delete();
                    if (f3.Exists) f3.Delete();
                    if (f4.Exists) f4.Delete();
                    if (f5.Exists) f5.Delete();

                    fileUpload.PostedFile.SaveAs(dirPath + "\\" + filename);
                    ViewState["Upload"] = 1;
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("File Successfully Uploaded", MessageType.Success);
                }
            }
            else
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Please select the file", MessageType.Error);
            }
        }
        catch (Exception ex)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Error while uploading file", MessageType.Error);
        }
    }

    #endregion

    #region Private Methods
    private void LoadBannerAdDetails(int bannerAdId)
    {
        var bannerAdDetails = _bannerAdManager.GetBannerAds(null, bannerAdId).FirstOrDefault();
        if (bannerAdDetails == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load banner details. Please try later.", CLB.Enums.MessageType.Info);
            return;
        }
        hdnID.Value = bannerAdDetails.BannerAdID.ToString();
        // hdnID.Value = user.UserID.ToString();
        txtNameSearch.Value = bannerAdDetails.User.UserDetails.FirstName + " " + bannerAdDetails.User.UserDetails.LastName + "(" + bannerAdDetails.User.Email + ", " + bannerAdDetails.User.Mobile + ")";
        BindInventories(int.Parse(bannerAdDetails.User.UserID.ToString()));
        ddlInventory.SelectedValue = bannerAdDetails.Inventory.InventoryID.ToString();

        //ddlBannerPosition.SelectedValue = bannerAdDetails.BannerPosition.ToString();
        ddlBannerPosition.Items.FindByText(bannerAdDetails.BannerPosition.ToString()).Selected = true;
        txtExpiryDate.Value = bannerAdDetails.ExpiryDate.ToString("dd-MM-yyyy");
        string dirUrl = Server.MapPath("~/Uploads/BannerAds/Position-" + ((int)bannerAdDetails.BannerPosition).ToString() + "/");
        //hdBannerPosition = hdBannerPosition + "/";
        dir = new DirectoryInfo(dirUrl);
        if (dir.Exists)
        {
            FileInfo[] imageFiles = dir.GetFiles(bannerAdDetails.User.UserID + ".*");
            foreach (FileInfo file in imageFiles)
            {
                if (file.Extension.ToLower() == ".jpg" || file.Extension.ToLower() == ".jpeg" ||
                        file.Extension.ToLower() == ".gif" || file.Extension.ToLower() == ".bmp" ||
                        file.Extension.ToLower() == ".png")
                    imgUpload.ImageUrl = "~/Uploads/BannerAds/Position-" + ((int)bannerAdDetails.BannerPosition).ToString() + "/" + file.Name;
            }
        }
        rblStatus.Items.FindByText(bannerAdDetails.Status.ToString()).Selected = true;
        CreatedDate.Text = FormatDateTime(bannerAdDetails.CreatedDate);
        ModifiedDate.Text = FormatDateTime(bannerAdDetails.ModifiedDate);
    }
    private void BindUsers()
    {
        var users = GetCachedUsers();
        // ViewState["FilterList"] = ViewState["List"] = users;
        var userNames = (from item in users select ValidAutoCompleteString(item.UserDetails.FirstName + " " + item.UserDetails.LastName + "(" + item.Email + ", " + item.Mobile + ")")).ToList();
        UserNames = JsonConvert.SerializeObject(userNames.ToArray());
    }
    private void BindInventories(int userId)
    {
        ViewState["UserId"] = userId;
        var inventoryDetails = _inventoryManager.GetVendorInventory(null, int.Parse(userId.ToString()), null, null, null);
        ViewState["VendorInventory"] = inventoryDetails;
        Utilities.BindControl(inventoryDetails, "Product.ProductName", "InventoryID", ddlInventory);
    }
    private void LoadControls()
    {
        Utilities.BindControl<BannerPosition>(ddlBannerPosition);
        rblStatus.Items.Add(new ListItem(Status.Active.ToString(), ((int)Status.Active).ToString()));
        rblStatus.Items.Add(new ListItem(Status.InActive.ToString(), ((int)Status.InActive).ToString()));
        rblStatus.SelectedIndex = 0;
    }

    #endregion
}