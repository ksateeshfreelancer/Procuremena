﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.BL;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using System.Data;
using System.Configuration;

public partial class BannerAds_ViewBannerAds : BasePage
{
    #region Global Variables

    private BannerAdManager _bannerManager = new BannerAdManager();
    public string UserNames { get; set; }
    private UserManager _userManager = new UserManager();
    string path = "~/Uploads/";
    DirectoryInfo dir;
    //string url = "~/Page_Image/";
    //FileInfo[] imageFiles = dir.GetFiles("*.jpg");


    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindUsers();
        BindBanners();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtNameSearch.Value = txtFromDateSearch.Value = txtToDateSearch.Value = "";
        BindUsers();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string[] sear = new string[] { " " };
        var bannerAds = ((List<BannerAd>)ViewState["List"]);
        if (bannerAds == null) return;
        var control = ((Control)sender).NamingContainer;
        bannerAds = (from item in bannerAds
                     let fromdate = txtFromDateSearch.Value.Trim()
                     let todate = txtToDateSearch.Value.Trim()
                     let search = txtNameSearch.Value.Trim()
                     where
                        (search.Split(sear, StringSplitOptions.None).Any(y => item.User.UserDetails.FirstName.Contains(y)) ||
                        search.Split(sear, StringSplitOptions.None).Any(y => item.User.UserDetails.LastName.Contains(y)) ||
                     item.User.Email.Contains(search) || item.User.Mobile.Contains(search))
                        && (string.IsNullOrEmpty(fromdate) || item.ExpiryDate.Date >= GetFormattedDate(fromdate).Date ||
                              item.ExpiryDate.Date >= GetFormattedDate(fromdate).Date)
                        && (string.IsNullOrEmpty(todate) || item.ExpiryDate.Date <= GetFormattedDate(todate).Date ||
                              item.ExpiryDate.Date <= GetFormattedDate(todate).Date)
                     select item).ToList();


        gridview.DataSource = ViewState["FilterList"] = bannerAds;
        gridview.DataBind();
    }

    #region Grid Events
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _bannerManager.DeleteBannerAd(int.Parse(gridview.DataKeys[e.RowIndex].Values["BannerAdId"].ToString()), out _status);
        BindUsers();
        BindBanners();
    }
    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var dataKeyArray = gridview.DataKeys[e.Row.RowIndex];
                var bannerAdId = int.Parse(((HiddenField)e.Row.FindControl("hdnBannerAdId")).Value);
                string hdBannerPosition = ((HiddenField)e.Row.FindControl("hdBannerPosition")).Value.ToString();
                var userId = ((HiddenField)e.Row.FindControl("hdUserId")).Value.ToString();
                var inventoryID = ((HiddenField)e.Row.FindControl("hdnInventoryID")).Value.ToString();
                var productID = ((HiddenField)e.Row.FindControl("hdnProductID")).Value.ToString();

                ((HtmlAnchor)e.Row.FindControl("lnkEdit")).HRef = "~/" + _redirectPage.ManageBannerAd.Key + "?T=P&ID=" + Utilities.Encrypt(bannerAdId);
                Image img = (Image)e.Row.FindControl("image");
                //store users images by banner position folder structure. It would be easy access in UI to load from jquery
                string dirUrl = Server.MapPath("~/Uploads/BannerAds/Position-" + (int)Enum.Parse(typeof(BannerPosition), hdBannerPosition) + "/");

                dir = new DirectoryInfo(dirUrl);
                if (dir.Exists)
                {
                    //<UserID>-<ProductID>-<VendorInventoryID>
                    FileInfo[] imageFiles = dir.GetFiles(userId + "-" + productID + "-" + inventoryID + ".*");
                    foreach (FileInfo file in imageFiles)
                    {
                        if (file.Extension.ToLower() == ".jpg" || file.Extension.ToLower() == ".jpeg" ||
                                file.Extension.ToLower() == ".gif" || file.Extension.ToLower() == ".bmp" ||
                                file.Extension.ToLower() == ".png")
                            img.ImageUrl = "~/Uploads/BannerAds/Position-" + (int)Enum.Parse(typeof(BannerPosition), hdBannerPosition) + "/" + file.Name;
                        else
                            img.ImageUrl = "~/Images/No_image_available.bmp";
                    }
                }
                else
                    img.ImageUrl = "~/Images/No_image_available.bmp";
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<BannerAd>(gridview, ((LinkButton)sender).CommandArgument);
    }
    protected void cboxStatus_CheckedChanged(object sender, EventArgs e)
    {
        var row = (CheckBox)sender;
        var cboxStatus = (CheckBox)row.FindControl("cboxStatus");
        var hdnBannerAdID = (HiddenField)row.FindControl("hdnBannerAdID");
        var status = (cboxStatus.Checked) ? 1 : 0;
        var dbMessage = _bannerManager.UpdateField(Tables.BannerAd, "Status", status.ToString(), "BannerAdId", hdnBannerAdID.Value);

        if (dbMessage == DbMessage.Success)
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Status is changed to " + ((Status)status).ToString() + " successfully", MessageType.Success);
        else
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to update status. Please try again later.", MessageType.Error);
        BindBanners();
    }
    #endregion

    #endregion

    #region Private Methods

    private void BindUsers()
    {
        var users = _userManager.GetUsers();
        // ViewState["FilterList"] = ViewState["List"] = users;
        var userNames = (from item in users select ValidAutoCompleteString(item.UserDetails.FirstName + " " + item.UserDetails.LastName + "(" + item.Email + ", " + item.Mobile + ")")).ToList();
        UserNames = JsonConvert.SerializeObject(userNames.ToArray());
    }

    private void BindBanners()
    {
        var bannerAds = _bannerManager.GetBannerAds();
        ViewState["FilterList"] = ViewState["List"] = bannerAds;
        gridview.DataSource = bannerAds;
        gridview.DataBind();
    }
    #endregion


}