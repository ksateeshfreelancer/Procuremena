﻿using CLB.BL;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Profile_ChangePassword : BasePage
{
    #region Global Variables

    AccountManager _accountManager;
    DbMessage _dbMessage;

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnChangePwd_Click(object sender, EventArgs e)
    {
        var changePassword = new CLB.DTO.ChangePassword
        {
            Email = CurrentUser.Email,
            OldPassword = Utilities.GetEncryptedPassword(Utilities.SharedSecret, txtOldPwd.Value),
            NewPassword = Utilities.GetEncryptedPassword(Utilities.SharedSecret, txtNewPwd.Value),
        };

        _accountManager = new AccountManager();
        _dbMessage = _accountManager.ChangePassword(changePassword);
        lblStatusMessage.InnerHtml = (_dbMessage == DbMessage.NotFound
                                         ? DbConstants.OutMessage(_dbMessage, "User")
                                         : DbConstants.OutMessage(_dbMessage)).Replace("Password", "Login Password");

        if (_dbMessage == DbMessage.PasswordChanged)
        {
            Utilities.SendEmail(CurrentUser.Email, "Credentials Updated", "Password changed<br/><br/><br/>New Password: " + txtNewPwd.Value);
        }
        ClearControls(this);
    }
}