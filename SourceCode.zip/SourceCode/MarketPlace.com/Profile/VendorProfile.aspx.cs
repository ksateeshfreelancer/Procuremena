﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class VendorProfile : BasePage
{
    #region Declarations

    UserManager _userManager = new UserManager();
    CityManager _cityManager = new CityManager();
    BusinessDetailsManager _businessDetailsManager = new BusinessDetailsManager();

    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindVendorDetails();
        BindVendorBusinessDetails();
    }

    #endregion

    #region ControlEvents
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            var user = new User
            {
                UserDetails = new UserDetails
                {
                    FirstName = txtFirstName.Text.Trim(),
                    LastName = txtLastName.Text.Trim(),
                    DOB = GetFormattedDate(txtDOB.Value),
                    Gender = (Gender)int.Parse(rblGender.SelectedValue),
                    Country = new Country
                    {
                        CountryID = Convert.ToInt32(Session[SessionVariables.CountryId])
                    },
                    RegisteredIP = Utilities.IPAddress,
                    UserID = CurrentUser.UserID
                },
                UserID = CurrentUser.UserID
            };

            var cities = GetCachedCities(false, Convert.ToInt32(Session[SessionVariables.CountryId]));

            var cityDetails = cities.FirstOrDefault(x => (x.CityName.ToLower().Equals(txtCity.Text.ToLower().Trim())
                    || x.AliasNames.Split(',').Any(y => y.ToLower().Trim().Equals(txtCity.Text.ToLower().Trim()))));

            int cityID = 0;

            #region Validate and create new City

            if (cityDetails == null)
            {
                _cityManager.SaveCity(
                    new City
                    {
                        CityID = 0,
                        CityName = txtCity.Text.Trim(),
                        Status = Status.Active,
                        Country = new Country
                        {
                            CountryID = int.Parse(Session[SessionVariables.CountryId].ToString())
                        }
                    }, out cityID, out _status);
                //clear cache after new city is inserted
                GetCachedCities(true);
            }
            else
            {
                _status = true;
                cityID = cityDetails.CityID;
            }

            if (!_status)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Vendor registration failed. Please try again later.", MessageType.Error);
                return;
            }
            #endregion

            var businessDetails = new BusinessDetails
            {
                Address = txtAddress.Text.Trim(),
                BusinessName = txtBusinessName.Text.Trim(),
                BusinessType = (BusinessType)int.Parse(ddlBusinessType.SelectedValue),
                Emails = txtEmails.Text,
                PAN = txtPAN.Text.Trim(),
                Phones = txtPhoneNos.Text.Trim(),
                Pincode = txtPincode.Text.Trim(),
                PrimaryPhone = txtPrimaryPhone.Text.Trim(),
                State = txtState.Text.Trim(),
                UserID = CurrentUser.UserID,
                CityID = cityID,
                WebsiteURL = txtWebsiteURL.Text.Trim()
            };

            lblStatusMessage.InnerHtml = _userManager.SaveUserDetails(user, false, out _status);
            lblStatusMessage.InnerHtml = _businessDetailsManager.SaveBusinessDetails(businessDetails, false, out _status);

            if (_status)
            {
                GetCachedUsers(clearCache: true);
                ClearControls(this);
            }
            BindVendorDetails();
            BindVendorBusinessDetails();
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    #endregion

    #region PrivateMethods
    private void BindVendorDetails()
    {
        var user = _userManager.GetUsers(userID: CurrentUser.UserID).FirstOrDefault();

        if (user == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load user details. Please try again.", MessageType.Error);
            return;
        }

        txtFirstName.Text = user.UserDetails.FirstName;
        txtLastName.Text = user.UserDetails.LastName;
        txtDOB.Value = user.UserDetails.DOB.ToString("dd-MM-yyyy");
        rblGender.SelectedValue = ((int)user.UserDetails.Gender).ToString();
        txtEmail.Text = user.Email;
        txtMobile.Text = user.Mobile;
    }
    private void BindVendorBusinessDetails()
    {
        var businessDetails = _businessDetailsManager.GetBusinessDetails(userID: CurrentUser.UserID).FirstOrDefault();

        if (businessDetails == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load vendor details. Please try again.", MessageType.Error);
            return;
        }

        txtBusinessName.Text = businessDetails.BusinessName;
        Utilities.BindControl<BusinessType>(ddlBusinessType);
        ddlBusinessType.SelectedValue = ((int)businessDetails.BusinessType).ToString();
        txtPAN.Text = businessDetails.PAN;
        txtPrimaryPhone.Text = businessDetails.PrimaryPhone;
        txtPhoneNos.Text = businessDetails.Phones;
        txtEmails.Text = businessDetails.Emails;
        txtCity.Text = businessDetails.CityName;
        txtState.Text = businessDetails.State;
        txtPincode.Text = businessDetails.Pincode;
        txtWebsiteURL.Text = businessDetails.WebsiteURL;
        txtAddress.Text = businessDetails.Address;
    }

    #endregion
}