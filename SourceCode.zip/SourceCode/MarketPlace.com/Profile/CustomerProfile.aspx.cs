﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CustomerProfile : BasePage
{
    #region Declarations

    UserManager _userManager = new UserManager();    

    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindUserDetails();
    }

    #endregion

    #region ControlEvents
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        var user = new User
        {
            UserDetails = new UserDetails
            {
                FirstName = txtFirstName.Text.Trim(),
                LastName = txtLastName.Text.Trim(),
                Gender = (Gender)int.Parse(rblGender.SelectedValue),
                DOB = GetFormattedDate(txtDOB.Value),
                Country = new Country
                {
                    CountryID = Convert.ToInt32(Session[SessionVariables.CountryId])
                },
                RegisteredIP = Utilities.IPAddress,
                UserID = CurrentUser.UserID
            },
            UserID = CurrentUser.UserID
        };

        lblStatusMessage.InnerHtml = _userManager.SaveUserDetails(user, false, out _status);
        if (_status)
        {
            GetCachedUsers(clearCache: true);
            /*DO NOT CLEAR CONTROLS*/
            //ClearControls(this);
        }
        BindUserDetails();
    }

    #endregion

    #region PrivateMethods
    private void BindUserDetails()
    {
        var user = _userManager.GetUsers(userID: CurrentUser.UserID).FirstOrDefault();

        if (user == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load user details. Please try again.", MessageType.Error);
            return;
        }

        txtFirstName.Text = user.UserDetails.FirstName;
        txtLastName.Text = user.UserDetails.LastName;
        txtEmail.Text = user.Email;
        txtMobile.Text = user.Mobile;
        rblGender.SelectedValue = ((int)user.UserDetails.Gender).ToString();
        txtDOB.Value = user.UserDetails.DOB.ToString("dd-MM-yy");        
    }

    #endregion
}