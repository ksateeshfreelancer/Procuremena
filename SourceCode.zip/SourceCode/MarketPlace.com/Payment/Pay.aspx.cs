﻿
using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using CLB.DTO;

public partial class Pay : System.Web.UI.Page
{
    /*
    #region Global Variables


    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Request.QueryString["T"] == null)
                Response.Redirect("~/MyDeposits", false);

            var ticks = Request.QueryString["T"];

            if (Page.Request.QueryString["PG"] != null && Session[SessionVariables.CurrentUser] != null && HttpContext.Current.Cache[Utilities.Encrypt("B2BPaymentGatewayConfiguration") + ticks] != null)
            {
                var currentUser = (User)Session[SessionVariables.CurrentUser];
                var b2BPaymentGatewayConfiguration = HttpContext.Current.Cache[Utilities.Encrypt("B2BPaymentGatewayConfiguration") + ticks] as B2BPaymentGatewayConfiguration;
                var values = Page.Request.QueryString["PG"].Split('~');
                EBSPaymentGateway(currentUser, b2BPaymentGatewayConfiguration, values[0].Split('=')[1],
                                  values[1].Split('=')[1], ticks);
            }
            else
                Response.Redirect("~/MyDeposits", false);
        }
        catch (Exception ex)
        {
            var basePage = new BasePage();
            basePage.TrackException(ex);
            Response.Redirect("~/Login", false);
        }
    }
    /// <summary>
    /// Ebs payment Gateway
    /// </summary>
    protected void EBSPaymentGateway(User user, B2BPaymentGatewayConfiguration paymentGateway, string refNumber, string amount, string ticks)
    {

        var accountid = Utilities.Decrypt(paymentGateway.MerchantId);
        var url = Utilities.LoadPaymentGatewayProviders().FirstOrDefault(x => x.Id == paymentGateway.PaymentGatewayProviderId).LiveUrl;
        var secretKey = Utilities.Decrypt(paymentGateway.SecretKey);

        const string formName = "form1";

        var returnUrl = (HttpContext.Current.Request.Url.ToString().ToLower().Contains("https://")
            ? "https://"
            : "http://") + Page.Request.Url.Authority +
                        (bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]) ? "/UI" : "") +
                        "/PGResp?T=" + ticks + "&DR={DR}";

        var input = secretKey + "|" + accountid + "|" + amount + "|" + refNumber + "|" + returnUrl + "|" + (accountid == "5880" ? "TEST" : "LIVE");
        var md5 = MD5.Create();
        var inputBytes = Encoding.ASCII.GetBytes(input);
        var hashBytes = md5.ComputeHash(inputBytes);
        var sb = new StringBuilder();

        for (var i = 0; i < hashBytes.Length; i++)
            sb.Append(hashBytes[i].ToString("X2"));

        var formFields = new NameValueCollection
            {
                {"account_id", accountid},
                {"reference_no", refNumber},
                {"amount", amount},
                {"description", (accountid == "5880" ? "TEST" : "LIVE")},
                {"name", user.FirstName + " " + user.LastName},
                {"address", user.Address},
                {"city", user.City},
                {"state", "AP"},
                {"postal_code", user.Pincode},
                {"country", "IND"},
                {"email", user.Email},
                {"phone", user.Mobile},
                {"ship_name", user.FirstName + " " + user.LastName},
                {"ship_address", user.Address},
                {"ship_city", user.City},
                {"ship_state", "AP"},
                {"ship_postal_code", user.Pincode},
                {"ship_country", "IND"},
                {"ship_phone", user.Mobile},
                {"return_url", returnUrl},
                {"mode", accountid == "5880" ? "TEST" : "LIVE"},
                {"secure_hash", sb.ToString()}
            };

        Response.Clear();
        Response.Write("<html><head>");
        Response.Write(string.Format("</head><body onload=\"document.{0}.submit()\">", formName));
        Response.Write(string.Format("<form name=\"{0}\" method=\"{1}\" action=\"{2}\" >", formName, "post", url));
        for (var i = 0; i < formFields.Keys.Count; i++)
        {
            Response.Write(string.Format("<input name=\"{0}\" type=\"hidden\" value=\"{1}\">", formFields.Keys[i], formFields[formFields.Keys[i]]));
        }
        Response.Write("</form>");
        Response.Write("</body></html>");
        //  Response.End();
    }

    protected void AxisBankPaymentGateway(string AccessCode, string accountid, string amount, string PaymentGatewayUrl, string domainName)
    {
        try
        {


            string Url = "AxisBank_Pay.aspx";
            string Method = "post";
            string FormName = "form1";

            NameValueCollection FormFields = new NameValueCollection();
            FormFields.Add("virtualPaymentClientURL", "https://" + PaymentGatewayUrl);

            FormFields.Add("vpc_Version", "1");
            FormFields.Add("vpc_Command", "pay");
            // FormFields.Add("vpc_AccessCode", "3F3E93DB");//test
            FormFields.Add("vpc_AccessCode", AccessCode);//live
            FormFields.Add("vpc_MerchTxnRef", "");
            // FormFields.Add("vpc_Merchant", "TESTBSKYTECHNLGS"); // test
            FormFields.Add("vpc_Merchant", accountid); // live
            FormFields.Add("vpc_OrderInfo", "VPC Example");
            FormFields.Add("vpc_Amount", amount);
            //  FormFields.Add("vpc_ReturnURL", "http://localhost:51567/UI/Response.aspx"); //test
            FormFields.Add("vpc_ReturnURL", domainName.Replace("www.", "").Replace("/default.aspx", "") + "/Response.aspx");// live
            FormFields.Add("vpc_Locale", "en");
            FormFields.Add("Title", "Payment Gateway");

            Response.Clear();
            Response.Write("<html><head>");
            Response.Write(string.Format("</head><body onload=\"document.{0}.submit()\">", FormName));
            Response.Write(string.Format("<form name=\"{0}\" method=\"{1}\" action=\"{2}\" >", FormName, Method, Url));
            for (int i = 0; i < FormFields.Keys.Count; i++)
            {
                Response.Write(string.Format("<input name=\"{0}\" type=\"hidden\" value=\"{1}\">", FormFields.Keys[i], FormFields[FormFields.Keys[i]]));
            }
            Response.Write("</form>");
            Response.Write("</body></html>");
            Response.End();

        }
        catch (Exception ex)
        {

        }
    }
    */
}