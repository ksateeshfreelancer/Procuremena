﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.DTO;
using CLB.Enums;
using CLB.Util;

using CLB.BL.Administration;
using CLB.Enums.Database;
using System.Web.UI.HtmlControls;
using System.IO;
using CLB.BL;
public partial class MasterPage : System.Web.UI.MasterPage
{
    #region Declarations

    ProductCatalogManager _productCatalogManager = new ProductCatalogManager();
    RedirectPage _redirectPage = new RedirectPage();
    BasePage _ = new BasePage();

    public User CurrentUser
    {
        get { return (User)Session[SessionVariables.CurrentUser]; }
    }

    string[] pagestoSkip = new[] { "productdetails", "cart", "wishlist", "home" };

    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        #region Hide export buttons as there is not requirement

        var ibtnExcelExport = (ImageButton)ContentPlaceHolder1.FindControl("ibtnExcelExport");
        if (ibtnExcelExport != null) ibtnExcelExport.Visible = false;

        var ibtnPDFExport = (ImageButton)ContentPlaceHolder1.FindControl("ibtnPDFExport");
        if (ibtnPDFExport != null) ibtnPDFExport.Visible = false;

        var ibtnWordExport = (ImageButton)ContentPlaceHolder1.FindControl("ibtnWordExport");
        if (ibtnWordExport != null) ibtnWordExport.Visible = false;

        #endregion

        //set default button for content page
        if (ContentPlaceHolder1.FindControl("btnSearch") != null)
            form1.DefaultButton = ContentPlaceHolder1.FindControl("btnSearch").UniqueID;
        else if (ContentPlaceHolder1.FindControl("btnSubmit") != null)
            form1.DefaultButton = ContentPlaceHolder1.FindControl("btnSubmit").UniqueID;

        Page.MaintainScrollPositionOnPostBack = false;
        //Avoid redirection to previous page on back button click
        Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Page.Response.Cache.SetAllowResponseInBrowserHistory(false);

        if (IsPostBack) return;

        bool showMenu = false;
        if (CurrentUser == null || CurrentUser.Role.RoleID == (int)UserRole.Customer || CurrentUser.Role.RoleID == (int)UserRole.NotSet)
        {
            showMenu = true;
        }
        if (showMenu)
        {
            //Code to highlight selected menu item
            foreach (MenuItem tn in MenuCategories.Items)
            {
                if (tn.Text == Session["SearchParam"])
                    tn.Selected = true;
                else
                    tn.Selected = false;
            }
        }
    }
    #endregion

    #region Control Events
    protected void MenuCategories_MenuItemClick(object sender, MenuEventArgs e)
    {
        ListItem lstitem = new ListItem(MenuCategories.SelectedItem.Text, MenuCategories.SelectedItem.Value);

        Session["SearchParams"] = MenuCategories.SelectedItem.Text;
        //BindProductFeatures(int.Parse(MenuCategories.SelectedItem.Value));
        //NEED NOT DIFFERENTIATE CATEGORY AND SUB CATEGORY.. SEARCH HAPPENS ON BOTH 
        Response.Redirect(_redirectPage.Home.Key + "?search=" + _.EncodeUrl(Utilities.Encrypt("category")));
    }
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    #endregion

    #region Public Methods
    public string LoadCategoriesTopMenu()
    {
        if (CurrentUser != null && CurrentUser.Role.RoleID != (int)UserRole.Customer) return string.Empty;

        if (ViewState["CategoriesTopMenu"] != null && !string.IsNullOrEmpty(ViewState["CategoriesTopMenu"].ToString()))
            return ViewState["CategoriesTopMenu"].ToString();

        var sbMenu = new StringBuilder();

        //sbMenu.AppendLine("<ul class='dropdown dropdown-horizontal' id='nav' style='z-index: 2; width: 100%;'>");
        sbMenu.AppendLine("<ul class='nav navbar-nav'>");

        sbMenu.AppendLine("<li><a href='Index'>Home</a></li>");

        var categories = _.GetCachedCategories();
        var subcategories = _.GetCachedSubCategories();

        if (categories != null && categories.Count > 0)
        {
            double catcount = 1;
            foreach (var category in categories.Where(x => x.DisplayOrder > 0 && x.Status == Status.Active).OrderBy(x => x.DisplayOrder))
            {
                if (catcount > 4) continue;
                sbMenu.AppendLine("<li><a style='cursor: pointer;' onclick='fnSearch(this, \"c\");'>" + category.CategoryName + "<span class='caret'></span></a>");
                if (subcategories.Any(x => x.DisplayOrder >= 0 && x.Status == Status.Active && x.Category.CategoryID == category.CategoryID))
                {
                    double subcatcount = 1;
                    var closeul = 0;
                    //load sub categories
                    sbMenu.AppendLine("<ul class='dropdown-menu'>");
                    
                    foreach (var subcategory in subcategories.Where(x => x.DisplayOrder > 0 && x.Status == Status.Active && x.Category.CategoryID == category.CategoryID).OrderBy(x => x.DisplayOrder))
                    {
                        if (subcatcount % 5 != 0)
                        {
                            sbMenu.AppendLine("<li><a style='cursor: pointer;' onclick='fnSearch(this, \"sc\");'>" + subcategory.SubCategoryName + "</a></li>");
                        }
                        else
                        {
                            if (subcatcount != 5)
                                closeul++;
                            sbMenu.AppendLine("<li><a style='cursor: pointer;' href='#'>And more.. <span class='caret'></span></a>");
                            sbMenu.AppendLine("<ul class='dropdown-menu'>");
                            sbMenu.AppendLine("<li><a style='cursor: pointer;' onclick='fnSearch(this, \"sc\");'>" + subcategory.SubCategoryName + "</a></li>");
                        }
                        subcatcount++;
                    }
                    for (int i = 0; i < closeul; i++)
                    {
                        sbMenu.AppendLine("</ul></li>");
                    }

                    if (subcatcount > 5)
                        sbMenu.AppendLine("</ul></li>");

                    sbMenu.AppendLine("</ul>");
                }
                sbMenu.AppendLine("</li>");
                catcount++;
            }
            if (catcount > 4)
                sbMenu.AppendLine("<li><a href='" + _redirectPage.ViewMoreProducts.Key + "'>View More</a></li>");

        }
        sbMenu.AppendLine("</ul>");
        ViewState["CategoriesTopMenu"] = sbMenu.ToString();
        return ViewState["CategoriesTopMenu"].ToString();
    }
    public string LoadDynamicMenu()
    {
        //return "";
        var sbMenu = new StringBuilder();
        //sbMenu.AppendLine("<ul class='dropdown dropdown-horizontal' id='nav' style='z-index: 1; width: 100%;'>");
        sbMenu.AppendLine("<ul class='nav navbar-nav'>");

        if (CurrentUser == null)
            return string.Empty;

        var screenName = Page.Request.Url.AbsolutePath.Trim();
        if (bool.Parse(ConfigurationManager.AppSettings["IsDevEnvironment"]))
            screenName = screenName.ToLower().Replace("ui", string.Empty);
        screenName = screenName.ToLower().TrimStart('/');

        if (ViewState["Menu"] != null && !string.IsNullOrEmpty(ViewState["Menu"].ToString()))
            return ViewState["Menu"].ToString();

        switch (CurrentUser.Role.RoleID)
        {
            case (int)UserRole.Administrator:
                sbMenu.AppendLine("<li><a href='" + _redirectPage.AdminDashboard.Key + "'>Dashboard</a></li>");
                break;
            case (int)UserRole.Customer:
                sbMenu.AppendLine("<li><a href='" + _redirectPage.ViewCustomerEnquiries.Key + "'>Dashboard</a></li>");
                break;
            case (int)UserRole.Vendor:
                sbMenu.AppendLine("<li><a href='" + _redirectPage.VendorDashboard.Key + "'>Dashboard</a></li>");
                break;
            default:
                break;
        }

        foreach (var screens in CurrentUser.Role.Screens.Where(x => x.Status != Status.InActive)
                           .OrderBy(x => x.Category).GroupBy(x => x.Category))
        {
            //check if atleast one screen in category can be shown
            if (!screens.Any(x => x.ShowInMenu)) continue;

            var firstScreen = screens.FirstOrDefault();

            //check if group has atleast one screen
            if (firstScreen == null) continue;
            //sbMenu.AppendLine("<li><span class='dir'>" + firstScreen.Category + "</span>");
            sbMenu.AppendLine("<li><a href='#'>" + firstScreen.Category + "<span class='caret'></span></a>");
            //sbMenu.AppendLine("<ul>");
            sbMenu.AppendLine("<ul class='dropdown-menu'>");
            foreach (var screen in screens.OrderBy(x => x.Order))
            {
                if (!screen.ShowInMenu) continue;
                sbMenu.AppendLine("<li onclick='jsFns.ClearAuditCookie();'><a href='" + Page.ResolveUrl("~/") + screen.ScreenName + "'>" +
                    screen.DisplayName + "</a></li>");
            }
            sbMenu.AppendLine("</ul>");
            sbMenu.AppendLine("</li>");
        }

        sbMenu.AppendLine("<li><a href='" + _redirectPage.ChangePassword.Key + "'>Change Password</a></li>");
        sbMenu.AppendLine("<li><a href='" + _redirectPage.Logout.Key + "'>Logout</a></li>");
        sbMenu.AppendLine("</ul>");
        ViewState["Menu"] = sbMenu.ToString();
        return ViewState["Menu"].ToString();
    }

    #endregion
}
