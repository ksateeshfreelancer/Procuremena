﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EmailQueries_EmailContent : BasePage
{
    #region Global Variables

    private QueryManager _queryManager = new QueryManager();

    #endregion

    #region Page Methods

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        LoadQuery();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtBody.Text.Length > _maxLength)
        {
            Utilities.CustomMessage("Body cannot exceed " + _maxLength + " characters (" + txtBody.Text.Length + ")", MessageType.Warning);
            return;
        }
        var queryDetails = (Query)ViewState["Query"];
        var query = new Query
        {
            Body = txtBody.Text.Trim(),
            IsRead = false,
            QueryCategory = queryDetails.QueryCategory,
            Subject = null,
            IsParent = false, //since existing thread is being commented upon
            ThreadID = queryDetails.ThreadID,
            User = CurrentUser,
            CreatedDate = DateTime.Now
        };
        lblStatusMessage.InnerHtml = _queryManager.SaveQuery(query, out _status);

        if (_status)
        {
            CreatedDate.Text = "";
            ClearControls(this);
            LoadQuery();
        }
    }

    #endregion

    #region Private Methods

    private void LoadQuery()
    {
        Int64 id;
        if (Request.QueryString["ID"] == null || !Int64.TryParse(Request.QueryString["ID"], out id))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Query", MessageType.Error);
            return;
        }

        var queriesonThread = new List<Query>();

        //do not pass userid if admin login. Bcoz admin should see email queries from all users
        //if(CurrentUser.Role.RoleID == (int)UserRole.Administrator)
        queriesonThread = _queryManager.GetQueries(threadID: id).OrderBy(x => x.CreatedDate).ToList();
        //else
        //queriesonThread = _queryManager.GetQueries(id, CurrentUser.UserID).OrderBy(x => x.CreatedDate).ToList();

        var query = queriesonThread.FirstOrDefault(x => x.IsParent);
        if (query == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load Query. Please try later.", CLB.Enums.MessageType.Info);
            return;
        }
        if (CurrentUser.Role.RoleID != (int)UserRole.Administrator && query.User.UserID != CurrentUser.UserID)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Query.", CLB.Enums.MessageType.Info);
            return;
        }

        //mark queries as read
        var result = _queryManager.MarkAsRead(queriesonThread.Where(x => x.User.UserID != CurrentUser.UserID && !x.IsRead));
        
        ViewState["Query"] = query;
        lblSubject.Text = query.Subject;
        lblCategory.Text = query.QueryCategory.ToString();
        CreatedDate.Text = FormatDateTime(query.CreatedDate);

        repeater.DataSource = queriesonThread.Where(x => !x.IsParent);
        repeater.DataBind();
    }

    #endregion
}