﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EmailQueries_ViewEmailQueries : BasePage
{
    #region Global Variables

    QueryManager _queryManager = new QueryManager();
    public string QuerySubject { get; set; }

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        Utilities.BindControl<QueryCategory>(ddlQueryCategory);
        BindQueries();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtSubjectSearch.Value = txtFromDateSearch.Value = txtToDateSearch.Value = ""; ddlQueryCategory.SelectedIndex = 0;
        BindQueries();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        var queries = ((List<Query>)ViewState["List"]);
        if (queries == null) return;
        var control = ((Control)sender).NamingContainer;
        queries = (from query in queries
                   let fromdate = txtFromDateSearch.Value.Trim()
                   let todate = txtToDateSearch.Value.Trim()
                   where
                       query.Subject.ToLower().Contains(txtSubjectSearch.Value.ToLower().Trim())
                       && (ddlQueryCategory.SelectedIndex == 0 || query.QueryCategory == (CLB.Enums.QueryCategory)int.Parse(ddlQueryCategory.SelectedValue))
                       && (string.IsNullOrEmpty(fromdate) || query.CreatedDate.Date >= GetFormattedDate(fromdate).Date)
                       && (string.IsNullOrEmpty(todate) || query.CreatedDate.Date <= GetFormattedDate(todate).Date)
                   select query).ToList();

        gridview.DataSource = ViewState["FilterList"] = queries;
        gridview.DataBind();
    }

    #region Grid Events

    protected void gridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            GridViewRow emptyRow = null;
            if (e.CommandName.Equals("AddNewFromHeader"))
                emptyRow = gridview.HeaderRow;
            if (e.CommandName.Equals("AddNewFromEmpty"))
                emptyRow = gridview.Controls[0].Controls[0] as GridViewRow;

            if (emptyRow != null)
            {
                var ddlAddQueryCategory = (DropDownList)emptyRow.FindControl("ddlAddQueryCategory");
                var txtAddSubject = (TextBox)emptyRow.FindControl("txtAddSubject");
                var txtAddBody = (TextBox)emptyRow.FindControl("txtAddBody");

                var query = new Query
                {
                    IsRead = false,
                    QueryCategory = (QueryCategory)int.Parse(ddlAddQueryCategory.SelectedValue),
                    Subject = txtAddSubject.Text.Trim(),
                    Body = txtAddBody.Text.Trim(),
                    IsParent = true, //since new thread is being created
                    ThreadID = DateTime.Now.Ticks,
                    User = CurrentUser,
                    CreatedDate = DateTime.Now
                };
                lblStatusMessage.InnerHtml = _queryManager.SaveQuery(query, out _status);
                BindQueries();
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header || e.Row.RowType == DataControlRowType.EmptyDataRow)
            {
                if (CurrentUser.Role.RoleID == (int)UserRole.Administrator)
                    ((System.Web.UI.HtmlControls.HtmlTable)e.Row.FindControl("tblnewQuery")).Visible = false;

                Utilities.BindControl<QueryCategory>((DropDownList)e.Row.FindControl("ddlAddQueryCategory"));
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }

    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Query>(gridview, ((LinkButton)sender).CommandArgument);
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindQueries()
    {
        //load queries form all users for admins
        var queries = _queryManager.GetQueries();
        
        //if there are any conversations in the thread that are not read, change parent read status to unread. 
        foreach (var group in queries.GroupBy(x=> x.ThreadID))
        {
            if (group.Any(x => !x.IsParent && x.User.UserID != CurrentUser.UserID && !x.IsRead))
            {
                queries.FirstOrDefault(x => x.ThreadID == group.Key && x.IsParent).IsRead = false;
            }
        }
        
        queries = queries.Where(x => x.IsParent).ToList();
        if (CurrentUser.Role.RoleID == (int)UserRole.Customer || CurrentUser.Role.RoleID == (int)UserRole.Vendor)
        {
            queries = queries.Where(x => x.User.UserID == CurrentUser.UserID).ToList();
        }

        if (queries != null)
        {
            gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = queries;
            gridview.DataBind();
            QuerySubject = Newtonsoft.Json.JsonConvert.SerializeObject((from item in queries select ValidAutoCompleteString(item.Subject)).ToArray());
        }
        else
        {
            gridview.EditIndex = 0;
            gridview.ShowFooter = false;
            gridview.AllowSorting = false;
            gridview.DataSource = null;
            gridview.DataBind();
        }
    }

    #endregion
}