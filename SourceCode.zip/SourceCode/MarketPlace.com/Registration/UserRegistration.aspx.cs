﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserRegistration : BasePage
{
    #region Declarations

    public delegate List<User> Users_Delegate(int? userID = null, int?[] userRole = null, bool clearViewState = false);
    UserManager _userManager = new UserManager();
    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session[SessionVariables.UserId] != null)
            Response.Redirect(_redirectPage.Home.Key, false);
        if (IsPostBack) return;
        imgCaptcha.ImageUrl = Page.ResolveUrl("~/captcha/Image.aspx?id=" + Guid.NewGuid() + "");
        Session[SessionVariables.CaptchaImageText] = GenerateRandomCode();
        //use delegates to store uses list to view state...
        Users_Delegate d = new Users_Delegate(GetCachedUsers);
        IAsyncResult R = d.BeginInvoke(null, new int?[] { (int)UserRole.Customer }, false, null, null); //invoking the method

        //Check if registration type is user registration or vendor registration
        if (Request.QueryString["RT"] != null && !string.IsNullOrEmpty(Request.QueryString["RT"].ToString()))
        {
            //possible cases
            //RT = User > User registration
            //RT = Vendor > Vendor registration
            Session["RT"] = Request.QueryString["RT"].ToString();
        }
    }
    #endregion

    #region Control Events
    protected void lbtnRefreshCaptcha_Click(object sender, EventArgs e)
    {
        try
        {
            txtCaptcha.Text = "";
            imgCaptcha.ImageUrl = Page.ResolveUrl("~/captcha/Image.aspx?id=" + Guid.NewGuid() + "");
            Session[SessionVariables.CaptchaImageText] = GenerateRandomCode();
        }
        catch (Exception ex)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load captcha. Please try again.", MessageType.Error);
            TrackException(ex);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (GetCachedUsers().Any(x => x.Email.ToLower() == txtEmail.Text.Trim().ToLower() || x.Mobile == txtMobile.Text.Trim()))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("User with this email/mobile is already registered.", MessageType.Warning);
            return;
        }

        if (string.IsNullOrEmpty(txtPassword.Value.Trim()) || string.IsNullOrEmpty(txtConfirmPassword.Value.Trim()))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Password fields cannot be left empty.", MessageType.Warning);
            return;
        }

        #region Save User

        var password = txtPassword.Value;

        var user = new User
        {
            Email = txtEmail.Text.Trim(),
            InvalidLoginAttempts = 0,
            IsNewPassword = true,
            Mobile = txtMobile.Text.Trim(),
            Password = Utilities.GetEncryptedPassword(Utilities.SharedSecret, password),
            Role = new CLB.DTO.Role { RoleID = (int)UserRole.Customer },
            Status = Status.AdminApproval,
            UserDetails = new UserDetails
            {
                FirstName = txtFirstName.Text.Trim(),
                LastName = txtLastName.Text.Trim(),
                RegisteredIP = Utilities.IPAddress == null ? "1.0.0.0" : Utilities.IPAddress,
                UserID = 0,
                Gender = Gender.Male,
                Country = new Country
                {
                    CountryID = Convert.ToInt32(Session[SessionVariables.CountryId])
                },
                CreatedBy = "0",
                ModifiedBy = "0"
            },
            UserID = 0
        };
        int userid = 0;
        lblStatusMessage.InnerHtml = DbConstants.OutMessage(_userManager.SaveUser(user, out userid, out _status), "User");

        #endregion

        if (_status && userid > 0)
        {
            Session["RegisteredEmail"] = txtEmail.Text;
            Session["RegisteredPhone"] = txtMobile.Text;
            Session["Password"] = Utilities.Encrypt(password);
            ClearControls(this);

            if (Session["RT"] != null && !string.IsNullOrEmpty(Session["RT"].ToString()) && Session["RT"].ToString().ToUpper() == "VENDOR")
                Response.Redirect(_redirectPage.VendorRegistration.Key + "?UID=" + Utilities.Encrypt(userid));
            else
                Response.Redirect(_redirectPage.UserRegistrationSuccess.Key);
        }
    }
    #endregion

    #region PrivateMethods
    private string GenerateRandomCode()
    {
        var random = new Random();
        string s = "";
        for (int i = 0; i < 6; i++)
            s = String.Concat(s, random.Next(10).ToString());
        return s;
    }
    #endregion
}