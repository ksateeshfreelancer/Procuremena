﻿using CLB.BL;
using CLB.Enums.Database;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration_RegistrationSuccess : BasePage
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        if (string.IsNullOrEmpty(Request.QueryString["UID"]))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid activation link", CLB.Enums.MessageType.Error);
            return;
        }
        int userID = 0;
        int.TryParse(Utilities.Decrypt(Request.QueryString["UID"]), out userID);
        if (userID == 0)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid activation link", CLB.Enums.MessageType.Error);
            return;
        }
        ViewState["UserID"] = userID;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {/*
        if (IsEmpty(txtVerificationCode))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid verification code", CLB.Enums.MessageType.Error);
            return;
        }
        if (ViewState["UserID"] == null || string.IsNullOrEmpty(ViewState["UserID"].ToString()))
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid activation link", CLB.Enums.MessageType.Error);
            return;
        }
        var referralManager = new ReferralManager();
        var referral = referralManager.GetReferrals(int.Parse(ViewState["UserID"].ToString())).FirstOrDefault();

        if (referral == null)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load user details", CLB.Enums.MessageType.Error);
            return;
        }
        if (referral.IsVerified)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Account is already verified", CLB.Enums.MessageType.Info);
            return;
        }
        if (referral.VerificationCode == txtVerificationCode.Text)
        {
            var result= referralManager.UpdateField(Tables.Referrals, "IsVerified", "1", "UserID", ViewState["UserID"].ToString());
            if (result == DbMessage.Success)
            {
                lblStatusMessage.InnerHtml = "";
                divSuccess.Visible = true;
                if (CurrentUser != null)
                {
                    LogoutUser();
                }
            }
            else
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Activation failed. Please try again later", CLB.Enums.MessageType.Error);
        }
        else
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Invalid Activation code", CLB.Enums.MessageType.Error);
        }*/
    }
}