﻿using CLB.BL;
using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.Util;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class VendorRegistration : BasePage
{
    #region Declarations

    BusinessDetailsManager _businessDetailsManager = new BusinessDetailsManager();
    CityManager _cityManager = new CityManager();
    public string Cities { get; set; }

    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        int userid = 0;
        if (CurrentUser != null)
        {
            userid = CurrentUser.UserID;
        }

        //invalid redirect request.
        if (userid == 0)
        {
            Response.Redirect(_redirectPage.Home.Key, false);
        }
        Utilities.BindControl<BusinessType>(ddlBusinessType);
        LoadCities();
    }

    #endregion

    #region Control Events
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            var businessDetails = new BusinessDetails
            {
                Address = txtAddress.Text.Trim(),
                BusinessName = txtBusinessName.Text.Trim(),
                BusinessType = (BusinessType)int.Parse(ddlBusinessType.SelectedValue),
                Emails = txtEmails.Text,
                PAN = txtPAN.Text.Trim(),
                Phones = txtPhoneNos.Text.Trim(),
                Pincode = txtPincode.Text.Trim(),
                PrimaryPhone = txtPrimaryPhone.Text.Trim(),
                State = txtState.Text.Trim(),
                UserID = CurrentUser.UserID,
                CityID = GetCityID(txtCity.Text),
                WebsiteURL = txtWebsiteURL.Text.Trim()
            };

            lblStatusMessage.InnerHtml = _businessDetailsManager.SaveBusinessDetails(businessDetails, true, out _status);

            if (_status)
            {
                //change role to vendor
                var dbMessage = _businessDetailsManager.UpdateField(Tables.Users, "RoleID", ((int)UserRole.Vendor).ToString(), "UserID", CurrentUser.UserID.ToString());
            }

            if (_status)
            {
                ClearControls(this);
                Response.Redirect(_redirectPage.VendorRegistrationSuccess.Key, false);
            }
        }
        catch (Exception ex)
        {
            lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to process. Please try again.", MessageType.Error);
            TrackException(ex);
        }
    }

    #endregion

    #region PrivateMethods

    private void LoadCities()
    {
        var cities = GetCachedCities(false, Convert.ToInt32(Session[SessionVariables.CountryId]));

        var aliasNames = from item in cities
                         from name in item.AliasNames.Split(',')
                         select ValidAutoCompleteString(name);

        Cities = JsonConvert.SerializeObject((from item in cities select ValidAutoCompleteString(item.CityName))
            .Concat(aliasNames));
    }

    #endregion
}