﻿using CLB.Util;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration_RegistrationSuccess : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {   
        if (Session["RegisteredEmail"] != null && Session["RegisteredPhone"] != null && Session["Password"] != null)
        {
            litEmail.Text = Session["RegisteredEmail"].ToString();

            Utilities.SendEmail(Session["RegisteredEmail"].ToString(), "Account Registered",
                "<br/><br/>Email: " + Session["RegisteredEmail"].ToString() +
                "<br/><br/>Mobile: " + Session["RegisteredPhone"].ToString()  +
                "<br/><br/>Password: " + Utilities.Decrypt(Session["Password"].ToString()));

            Utilities.SendEmail(ConfigurationManager.AppSettings["AdminEmail"], "Account pending for Activation",
                            "Hi Admin,<br/><br/> A new User has registered and activation is pending. Please review and activate.<br/><br/>" +
                            "<br/><br/>Email: " + Session["RegisteredEmail"].ToString() +
                            "<br/><br/>Mobile: " + Session["RegisteredPhone"].ToString() + "<br/><br/>" +
                            GetDomainUrl + "/" + _redirectPage.ViewCustomers.Key);
            //reset user details
            GetCachedUsers(clearCache: true);
            Session["RegisteredEmail"] = null;
            Session["RegisteredPhone"] = null;
        }
        else
        {
            Response.Redirect(_redirectPage.Home.Key);
        }
    }
}