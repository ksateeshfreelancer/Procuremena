﻿using CLB.Util;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration_RegistrationSuccess : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (CurrentUser == null)
        {
            Response.Redirect(_redirectPage.Home.Key, true);
            return;
        }

        Utilities.SendEmail(CurrentUser.Email, "Business details saved successfully",
            "<br/>Code: " + ConfigurationManager.AppSettings["AgentCodeSuffix"] + CurrentUser.UserID);
        //logout user as user login and login back with agent login
        LogoutUser();
    }
}