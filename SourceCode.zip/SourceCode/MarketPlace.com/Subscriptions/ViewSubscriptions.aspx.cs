﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Enums.Database;
using CLB.Util;
using CLB.Enums;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CLB.BL;
using Newtonsoft.Json;

public partial class ViewSubscriptions : BasePage
{
    #region Global Variables

    SubscriptionManager _subscriptionManager = new SubscriptionManager();
    PricePlanManager _pricePlanManager = new PricePlanManager();
    public string UserNames { get; set; }

    #endregion

    #region Page Methods

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindSubscriptions();
        var pricePlans = _pricePlanManager.GetPricePlans();
        Utilities.BindControl(pricePlans, "PlanName", "PlanID", ddlPricePlanSearch);
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblStatusMessage.InnerHtml = "";
        txtNameSearch.Value = txtFromDateSearch.Value = txtToDateSearch.Value = "";
        ddlPricePlanSearch.SelectedIndex = 0;
        BindSubscriptions();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string[] sear = new string[] { " " };
        var subscriptions = ((List<Subscription>)ViewState["List"]);
        if (subscriptions == null) return;
        var control = ((Control)sender).NamingContainer;
        subscriptions = (from subscription in subscriptions
                         let fromdate = txtFromDateSearch.Value.Trim()
                         let todate = txtToDateSearch.Value.Trim()
                         let search = txtNameSearch.Value.Trim()
                         where (search.Split(sear, StringSplitOptions.None).Any(y => subscription.User.UserDetails.FirstName.Contains(y)) ||
                                search.Split(sear, StringSplitOptions.None).Any(y => subscription.User.UserDetails.LastName.Contains(y)) ||
                             subscription.User.Email.Contains(search) || subscription.User.Mobile.Contains(search) || subscription.User.Role.RoleName.Contains(search))
                             && (string.IsNullOrEmpty(fromdate) || subscription.EndDate.Date >= GetFormattedDate(fromdate).Date)
                              && (string.IsNullOrEmpty(todate) || subscription.EndDate.Date <= GetFormattedDate(todate).Date)
                              && (ddlPricePlanSearch.SelectedIndex == 0 || subscription.PricePlan.PlanID == int.Parse(ddlPricePlanSearch.SelectedValue))
                         select subscription).ToList();

        gridview.DataSource = ViewState["FilterList"] = subscriptions;
        gridview.DataBind();
    }

    #region Grid Events
    protected void gridview_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void gridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblStatusMessage.InnerHtml = _subscriptionManager.DeleteSubscription(int.Parse(gridview.DataKeys[e.RowIndex].Values["SubscriptionID"].ToString()), out _status);
        BindSubscriptions();
    }

    public void SortGrid(object sender, EventArgs e)
    {
        ViewState["FilterList"] = ViewState["List"];
        SortList<Subscription>(gridview, ((LinkButton)sender).CommandArgument);
    }

    #endregion

    #endregion

    #region Private Methods
    private void BindSubscriptions()
    {
        var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor });

        var subscriptions = _subscriptionManager.GetSubscriptions();
        
        //User details are not fetched from db. Bind the details here
        subscriptions.ForEach(x => x.User = users.FirstOrDefault(y => y.UserID == x.User.UserID));

        gridview.DataSource = ViewState["FilterList"] = ViewState["List"] = subscriptions;
        gridview.DataBind();
                
        var userNames = (from item in users select ValidAutoCompleteString(item.UserDetails.FirstName + " " + item.UserDetails.LastName + "(" + item.Email + ", " + item.Mobile + ")")).ToList();
        UserNames = JsonConvert.SerializeObject(userNames.ToArray());
    }

    #endregion
}