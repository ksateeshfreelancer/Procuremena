﻿using CLB.BL.Administration;
using CLB.DTO;
using CLB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CLB.Enums;
using CLB.Enums.Database;
using CLB.BL;
using Newtonsoft.Json;

public partial class ManageSubscription : BasePage
{
    #region Global Variables

    SubscriptionManager _subscriptionManager = new SubscriptionManager();
    PricePlanManager _pricePlanManager = new PricePlanManager();
    private UserManager _userManager = new UserManager();
    public string UserNames { get; set; }

    #endregion

    #region Page Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (IsPostBack) return;

            LoadPricePlans();
            //Check if priceplans are created first. Subscriptions cannot be created without creating price plans
            if (ViewState["PricePlans"] == null || ((List<PricePlan>)ViewState["PricePlans"]).Count == 0)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("No Price plans are available to create subscription. Click <a href='" +
                    _redirectPage.ViewPricePlans.Key + "'> here</a> to create", MessageType.Info);
            }
            
            //Utilities.BindControl<State>(rblState, new[] { State.Deleted.ToString(), State.Pending.ToString(), State.Pending.ToString() });

            int id = 0;
            int.TryParse(Utilities.Decrypt(Request.QueryString["ID"]), out id);
            hdnID.Value = id.ToString();
            LoadSubscriptionDetails(id);
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string[] sear = new string[] { " " };
            var users = (from user in GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor })
                 let search = txtUserName.Value.Trim()
                 where (search.Split(sear, StringSplitOptions.None).Any(y => user.UserDetails.FirstName.Contains(y)) || 
                        search.Split(sear, StringSplitOptions.None).Any(y => user.UserDetails.LastName.Contains(y)) ||
                     user.Email.Contains(search) || user.Mobile.Contains(search) || user.Role.RoleName.Contains(search))
                 select user).ToList();
            //check if user is valid
            if (users == null || users.Count == 0)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Please select a valid user from the list.", CLB.Enums.MessageType.Info);
                return;
            }
            if (users.Count > 1)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Multiple users found with given name. Please select a valid user from the list.", CLB.Enums.MessageType.Info);
                return;
            }

            var subscriptions = ViewState["Subscriptions"] == null ? null :
                ((List<Subscription>)ViewState["Subscriptions"]).Where(x => x.User.UserID == users.FirstOrDefault().UserID && x.SubscriptionID != int.Parse(hdnID.Value)).ToList();

            //check if user do not have any subscriptions. no validations required
            if (subscriptions != null && subscriptions.Count() > 0)
            {
                if (subscriptions.Any(x => !x.IsExpired))
                {
                    lblStatusMessage.InnerHtml = Utilities.CustomMessage("One or more subscriptions are currently active for selected user.", CLB.Enums.MessageType.Info);
                    return;
                }
            }

            //check if start date and end date has valid data
            if (string.IsNullOrEmpty(txtStartDate.Value.Trim()) || string.IsNullOrEmpty(txtEndDate.Value.Trim()))
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Start date/End date are required.", CLB.Enums.MessageType.Info);
                return;
            }

            var subscription = new Subscription
            {
                SubscriptionID = int.Parse(hdnID.Value),
                User = new CLB.DTO.User
                {
                    UserID = users.FirstOrDefault().UserID
                },
                PricePlan = new PricePlan
                {
                    PlanID = int.Parse(ddlPricePlan.SelectedValue)
                },
                StartDate = GetFormattedDate(txtStartDate.Value.Trim()),
                EndDate = GetFormattedDate(txtEndDate.Value.Trim()),
                IsExpired = false
            };
                      
            lblStatusMessage.InnerHtml = _subscriptionManager.SaveSubscription(subscription, out _status);

            if (_status)
            {
                CreatedDate.Text = ModifiedDate.Text = "";
                ClearControls(this);
            }
        }
        catch (Exception ex)
        {
            TrackException(ex);
            lblStatusMessage.InnerHtml = DbConstants.OutMessage(DbMessage.Failed);
        }
    }    
    protected void ddlPricePlan_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPricePlan.SelectedIndex > 0)
        {
            DateTime startDate = GetFormattedDate(txtStartDate.Value);
            DateTime endDate = startDate;
            if (string.IsNullOrEmpty(txtStartDate.Value.Trim()) || startDate.Year == 1900)
            {
                ddlPricePlan.SelectedIndex = 0;
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Please select start date before selecting a price plan.", CLB.Enums.MessageType.Info);
                return;
            }
            var selectedPricePlan = ((List<PricePlan>)ViewState["PricePlans"]).FirstOrDefault(x=> x.PlanID == int.Parse(ddlPricePlan.SelectedValue));
            txtEndDate.Value = GetEndDate(startDate, selectedPricePlan.PlanSubscription).ToString("dd-MM-yyyy");
        }
        else
        {
            txtEndDate.Value = "";
        }
    }

    #endregion

    #region Private Methods
    private void LoadPricePlans()
    {
        var pricePlans = _pricePlanManager.GetPricePlans();
        ViewState["PricePlans"] = pricePlans;
        foreach (var plan in pricePlans)
        {
            ddlPricePlan.Items.Add(new ListItem(plan.PlanName + " (Rs. " + plan.PlanPrice + " /-) " + plan.PlanSubscription.ToString(), plan.PlanID.ToString()));
        }
        ddlPricePlan.Items.Insert(0, new ListItem("Please Select", ""));
    }
    private void LoadSubscriptionDetails(int id)
    {
        var users = GetCachedUsers(userRole: new int?[] { (int)UserRole.Vendor });
        var subscriptions = _subscriptionManager.GetSubscriptions();
        ViewState["Subscriptions"] = subscriptions;

        if (id > 0)
        {
            var subscription = subscriptions.FirstOrDefault(x => x.SubscriptionID == id);
            if (subscription == null)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load subscription details. Please try later.", CLB.Enums.MessageType.Info);
                return;
            }
            var user = users.FirstOrDefault(x => x.UserID == subscription.User.UserID);
            if (user == null)
            {
                lblStatusMessage.InnerHtml = Utilities.CustomMessage("Failed to load user details. Please try later.", CLB.Enums.MessageType.Info);
                return;
            }

            //ViewState["Subscriptions"] = subscription;
            hdnID.Value = subscription.SubscriptionID.ToString();
            txtUserName.Value = user.UserDetails.FirstName + " " + user.UserDetails.LastName + "(" + user.Email + ", " + user.Mobile + ")";
            txtStartDate.Value = subscription.StartDate.ToString("dd-MM-yyyy");
            ddlPricePlan.SelectedValue = subscription.PricePlan.PlanID.ToString();
            txtEndDate.Value = subscription.EndDate.ToString("dd-MM-yyyy");
            CreatedDate.Text = FormatDateTime(subscription.CreatedDate);
            ModifiedDate.Text = FormatDateTime(subscription.ModifiedDate);
        }        
        var userNames = (from item in users select ValidAutoCompleteString(item.UserDetails.FirstName + " " + item.UserDetails.LastName + "(" + item.Email + ", " + item.Mobile + ")")).ToList();
        UserNames = JsonConvert.SerializeObject(userNames.ToArray());
    }
    private DateTime GetEndDate(DateTime startDate, Frequency frequency)
    {
        switch (frequency)
        {
            case Frequency.Daily:
                return startDate.AddDays(1);
            case Frequency.Weekly:
                return startDate.AddDays(7);
            case Frequency.Monthly:
                return startDate.AddMonths(1);
            case Frequency.Quarterly:
                return startDate.AddMonths(3);
            case Frequency.Halfyearly:
                return startDate.AddMonths(6);
            case Frequency.Yearly:
                return startDate.AddYears(1);
            default:
                throw new NotImplementedException();
        }
    }
    #endregion        
}