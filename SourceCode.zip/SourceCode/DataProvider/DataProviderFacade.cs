﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace CLB.DP
{
    public class DataProviderFacade
    {
        private IDataProvider _iDataProvider;
        public DataProviderFacade(string dbType, string connectionString)
        {
            switch (dbType)
            {
                case "MSSQL":
                    _iDataProvider = new MSSqlDataProvider() { ConnectionString = connectionString } as IDataProvider;
                    break;
                default:
                    throw new ArgumentException("Invalid DB Type");
            }
        }

        public string ConnectionString { get; set; }

        public DataSet ExecuteDataSet(string sql, object[,] par, CommandType commandType)
        {
            return this._iDataProvider.ExecuteDataSet(sql, par, commandType);
        }

        public DataTable ExecuteDataTable(string sql, object[,] par, CommandType commandType)
        {
            return this._iDataProvider.ExecuteDataTable(sql, par, commandType);
        }

        public object ExecuteScalar(string sql, object[,] par, CommandType commandType)
        {
            return this._iDataProvider.ExecuteScalar(sql, par, commandType);
        }

        public int ExecuteNonQuery(string sql, object[,] par, CommandType commandType)
        {
            return this._iDataProvider.ExecuteNonQuery(sql, par, commandType);
        }

        public DataTable ExecuteReader(string sql, object[,] par, CommandType commandType)
        {
            return this._iDataProvider.ExecuteReader(sql, par, commandType);
        }
    }
}
