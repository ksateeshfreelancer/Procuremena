﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 8-May-2014
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

#endregion

namespace CLB.DP
{
    public interface IDataProvider
    {
        DataSet ExecuteDataSet(string sql, object[,] par, CommandType commandType);

        DataTable ExecuteDataTable(string sql, object[,] par, CommandType commandType);

        object ExecuteScalar(string sql, object[,] par, CommandType commandType);

        int ExecuteNonQuery(string sql, object[,] par, CommandType commandType);

        DataTable ExecuteReader(string sql, object[,] par, CommandType commandType);

    }
}
