﻿#region Developer Note
/*
 * Created by       : Satya
 * Created Date     : 8-May-2014
 * Version          : 1.0
 */
#endregion

#region Imports

using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Text;

#endregion

namespace CLB.DP
{
    /// <summary>
    /// DPBaseClass Class is responsible for executing queries against database and retrieve resultsets
    /// </summary>
    internal sealed class MSSqlDataProvider : IDataProvider
    {
        #region Private variables
        
        SqlConnection _myConnection;
        SqlCommand _myCommand;
        SqlDataAdapter _myDataAdaptor;
        SqlDataReader _myDataReader;
        DataSet _myDataSet;
        DataTable _myDataTable;
        Int32 _effectedRows;

        #endregion

        #region Public Properties

        public string ConnectionString { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Method to execute query against database and return dataset
        /// </summary>        
        /// <returns></returns>
        public DataSet ExecuteDataSet(string sql, object[,] par, CommandType commandType)
        {
            CreateConn();
            try
            {
                _myCommand = GenerateSQLCommand(sql, commandType, par);
                _myCommand.Connection = _myConnection;
                OpenConn(_myConnection);
                _myDataAdaptor = new SqlDataAdapter(_myCommand);
                _myDataSet = new DataSet();
                _myDataAdaptor.Fill(_myDataSet);
                _myDataAdaptor.Dispose();
                FillOutputParameters(par, _myCommand);
                return _myDataSet;
            }
            finally
            {
                CloseConn(_myConnection);
            }
        }

        /// <summary>
        /// Method to execute query against database and return datatable
        /// </summary>        
        /// <returns>DataTable</returns>
        public DataTable ExecuteDataTable(string sql, object[,] par, CommandType commandType)
        {
            CreateConn();
            try
            {
                _myCommand = GenerateSQLCommand(sql, commandType, par);
                _myCommand.Connection = _myConnection;
                OpenConn(_myConnection);
                _myDataAdaptor = new SqlDataAdapter(_myCommand);
                _myDataTable = new DataTable();
                _myDataAdaptor.Fill(_myDataTable);
                _myDataAdaptor.Dispose();
                FillOutputParameters(par, _myCommand);
                return _myDataTable;
            }
            finally
            {
                CloseConn(_myConnection);
            }
        }

        /// <summary>
        /// Method to execute query against database and return object
        /// </summary>        
        /// <returns>object</returns>
        public object ExecuteScalar(string sql, object[,] par, CommandType commandType)
        {
            CreateConn();
            try
            {
                _myCommand = GenerateSQLCommand(sql, commandType, par);
                _myCommand.Connection = _myConnection;
                OpenConn(_myConnection);
                var result = _myCommand.ExecuteScalar();
                FillOutputParameters(par, _myCommand);
                return result;
            }
            finally
            {
                CloseConn(_myConnection);
            }
        }

        /// <summary>
        /// Method to execute query against database and return number of rows effected
        /// </summary>        
        public int ExecuteNonQuery(string sql, object[,] par, CommandType commandType)
        {
            CreateConn();
            try
            {
                _myCommand = GenerateSQLCommand(sql, commandType, par);
                _myCommand.Connection = _myConnection;
                OpenConn(_myConnection);
                _effectedRows = _myCommand.ExecuteNonQuery();
                FillOutputParameters(par, _myCommand);
                return _effectedRows;
            }
            finally
            {
                CloseConn(_myConnection);
            }
        }

        /// <summary>
        /// Method to execute query against database and return datareader
        /// </summary>
        public DataTable ExecuteReader(string sql, object[,] par, CommandType commandType)
        {
            CreateConn();
            try
            {
                _myDataTable = new DataTable();
                _myCommand = GenerateSQLCommand(sql, commandType, par);
                _myCommand.Connection = _myConnection;
                OpenConn(_myConnection);
                _myDataReader = _myCommand.ExecuteReader();
                FillOutputParameters(par, _myCommand);
                if (_myDataReader.HasRows)
                    _myDataTable.Load(_myDataReader);
                return _myDataTable;
            }
            finally
            {
                CloseConn(_myConnection);
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Method to accept paramaters andcreate sql command
        /// </summary>        
        private SqlCommand GenerateSQLCommand(string sql, CommandType cmdType, object[,] sqlParams)
        {
            _myCommand = new SqlCommand(sql, _myConnection) { CommandType = cmdType };
            if (sqlParams != null)
            {
                //sqlParams - [Rowscount,ColumnsCount] Loop rows. So, sqlParams.GetLength(0)
                for (var i = 0; i < sqlParams.GetLength(0); ++i)
                {
                    /*
                     * sqlParams[i, 0] - parameter name
                     * sqlParams[i, 1] - parameter value
                     * sqlParams[i, 2] - parameter type - input or output
                     */
                    //skip if sqlparameter is declared and null value is passed as value to sqlparameter

                    //check if output parameter or input parameter
                    //indicates input parameter if condition is true
                    if (sqlParams[i, 2] == null)
                    {
                        if (sqlParams[i, 1] == null)
                            continue;
                        var pr = sqlParams[i, 1];

                        if (sqlParams[i, 1] is string)
                            pr = (string)sqlParams[i, 1] == "" ? DBNull.Value : sqlParams[i, 1];

                        _myCommand.Parameters.AddWithValue((string)sqlParams[i, 0], pr);
                    }
                    else
                    {
                        _myCommand.Parameters.Add((string)sqlParams[i, 0], SqlDbType.NVarChar, 30);
                        _myCommand.Parameters[(string)sqlParams[i, 0]].Direction = ParameterDirection.Output;
                    }
                }
            }
            return _myCommand;
        }

        /// <summary>
        /// Method to open existing sql connection
        /// </summary>
        private void OpenConn(SqlConnection myConnection)
        {
            if (myConnection.State == ConnectionState.Closed)
                myConnection.Open();
        }

        /// <summary>
        /// Method to create new sql connection
        /// </summary>
        private void CreateConn()
        {
            //check if ConnectionString property is set. If so, skip default connection string(in webconfig)
            if (ConnectionString == null || ConnectionString.Trim().Equals(string.Empty))
                throw new Exception("ConnectionString is missing. Cannot open the connection");
            _myConnection = new SqlConnection(ConnectionString);
        }

        /// <summary>
        /// Method to close existing sql connection
        /// </summary>
        private void CloseConn(SqlConnection myConnection)
        {
            using (myConnection)
            {
                if (myConnection.State != ConnectionState.Open) return;
                myConnection.Close();
                myConnection.Dispose();
            }
        }

        /// <summary>
        /// Method to check if any outparameters are set and fill values to par object
        /// </summary>
        /// <param name="par"></param>
        /// <param name="myCommand"></param>
        private void FillOutputParameters(object[,] par, SqlCommand myCommand)
        {
            //check if par is not null
            if (par != null)
            {
                //set the output parameter(if any) to par
                for (var i = 0; i < par.GetLength(0); ++i)
                {
                    if (par[i, 2] != null)
                        par[i, 1] = myCommand.Parameters[(string)par[i, 0]].Value;
                }
            }
        }

        #endregion
    }
}
